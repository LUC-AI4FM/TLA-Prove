---- MODULE IdempotencyKey ----
(***************************************************************************)
(*  Idempotency key.  Each client request carries a key.  The server     *)
(*  stores key -> result; on retry, the server returns the cached       *)
(*  result instead of re-executing the side-effect.                     *)
(*                                                                         *)
(*  Strong invariant: for every key, all observed results agree, and    *)
(*  the side-effect counter equals the number of distinct keys served.  *)
(***************************************************************************)
EXTENDS TLAPS, Naturals, FiniteSets, FiniteSetTheorems

CONSTANTS Keys

NONE == 0

VARIABLES cache, sideEffects, observed

vars == << cache, sideEffects, observed >>

Init == /\ cache       = [k \in Keys |-> NONE]
        /\ sideEffects = 0
        /\ observed    = [k \in Keys |-> NONE]

\* First time we see this key: run the side-effect, generate a result.
FirstCall(k) == /\ cache[k] = NONE
                /\ cache'       = [cache       EXCEPT ![k] = sideEffects + 1]
                /\ sideEffects' = sideEffects + 1
                /\ observed'    = [observed    EXCEPT ![k] = sideEffects + 1]

\* Retry: same key, return cached result, no new side effect.
Retry(k) == /\ cache[k] # NONE
            /\ observed' = [observed EXCEPT ![k] = cache[k]]
            /\ UNCHANGED << cache, sideEffects >>

Next == \/ \E k \in Keys : FirstCall(k)
        \/ \E k \in Keys : Retry(k)

Spec == Init /\ [][Next]_vars /\ WF_vars(Next)

\* Strong invariant: observed[k] is always the cached result, side-effect
\* count = number of cached keys.
ServedKeys == {k \in Keys : cache[k] # NONE}

TypeOK == /\ cache       \in [Keys -> 0..Cardinality(Keys)]
          /\ sideEffects \in 0..Cardinality(Keys)
          /\ observed    \in [Keys -> 0..Cardinality(Keys)]
          /\ sideEffects = Cardinality(ServedKeys)
          /\ \A k \in Keys :
                observed[k] # NONE => observed[k] = cache[k]

THEOREM ChatTLA_TypeOKSafety ==
ASSUME Keys # {},
       IsFiniteSet(Keys)
PROVE Spec => []TypeOK
PROOF
<1>1. Init => TypeOK
  <2>1. Init => ServedKeys = {}
    BY DEF Init, ServedKeys, NONE
  <2>2. Init => Cardinality(ServedKeys) = 0
    BY <2>1, FS_EmptySet
  <2>3. Cardinality(Keys) \in Nat
    BY FS_CardinalityType
  <2>4. 0 \in 0..Cardinality(Keys)
    BY <2>3
  <2> QED
    BY <2>1, <2>2, <2>4 DEF Init, TypeOK, NONE, vars, ServedKeys
<1>2. TypeOK /\ [Next]_vars => TypeOK'
  <2>1. TypeOK /\ (\E k \in Keys : FirstCall(k)) => TypeOK'
    <3>. SUFFICES ASSUME TypeOK,
                         NEW k \in Keys,
                         FirstCall(k)
                  PROVE TypeOK'
      OBVIOUS
    <3>1. k \notin ServedKeys
      BY DEF TypeOK, FirstCall, ServedKeys, NONE
    <3>2. IsFiniteSet(ServedKeys)
      BY FS_Subset DEF ServedKeys
    <3>3. ServedKeys' \subseteq ServedKeys \cup {k}
      BY <3>1 DEF ServedKeys, FirstCall, NONE
    <3>4. sideEffects \in Nat
      BY DEF TypeOK
    <3>5. sideEffects + 1 # NONE
      BY <3>4 DEF NONE
    <3>6. cache \in [Keys -> 0..Cardinality(Keys)]
      BY DEF TypeOK
    <3>7. k \in DOMAIN cache
      BY <3>6
    <3>8. cache'[k] = sideEffects + 1
      BY <3>7 DEF FirstCall
    <3>9. cache'[k] # NONE
      BY <3>5, <3>8
    <3>10. k \in ServedKeys'
      BY <3>9 DEF ServedKeys
    <3>11. ServedKeys \subseteq ServedKeys'
      BY <3>1 DEF ServedKeys, FirstCall, NONE
    <3>12. ServedKeys \cup {k} \subseteq ServedKeys'
      BY <3>10, <3>11
    <3>13. ServedKeys' = ServedKeys \cup {k}
      BY <3>3, <3>12
    <3>14. Cardinality(ServedKeys') = Cardinality(ServedKeys) + 1
      BY <3>1, <3>2, <3>13, FS_AddElement
    <3>15. Cardinality(ServedKeys') = sideEffects + 1
      BY <3>14 DEF TypeOK
    <3>16. ServedKeys' \subseteq Keys
      BY DEF ServedKeys
    <3>17. Cardinality(ServedKeys') <= Cardinality(Keys)
      BY <3>16, FS_Subset
    <3>18. IsFiniteSet(ServedKeys')
      BY <3>16, FS_Subset
    <3>19. Cardinality(ServedKeys') \in Nat
      BY <3>18, FS_CardinalityType
    <3>20. sideEffects + 1 \in Nat
      BY <3>15, <3>19
    <3>21. sideEffects + 1 <= Cardinality(Keys)
      BY <3>15, <3>17
    <3>22. sideEffects + 1 \in 0..Cardinality(Keys)
      BY <3>20, <3>21
    <3>23. cache' \in [Keys -> 0..Cardinality(Keys)]
      BY <3>22 DEF TypeOK, FirstCall
    <3>24. observed' \in [Keys -> 0..Cardinality(Keys)]
      BY <3>22 DEF TypeOK, FirstCall
    <3>25. sideEffects' \in 0..Cardinality(Keys)
      BY <3>22 DEF FirstCall
    <3>26. sideEffects' = Cardinality(ServedKeys')
      BY <3>15 DEF FirstCall
    <3>27. \A j \in Keys : observed'[j] # NONE => observed'[j] = cache'[j]
      BY DEF TypeOK, FirstCall, NONE
    <3> QED
      BY <3>23, <3>24, <3>25, <3>26, <3>27 DEF TypeOK
  <2>2. TypeOK /\ (\E k \in Keys : Retry(k)) => TypeOK'
    BY DEF TypeOK, Retry, ServedKeys, NONE, vars
  <2>3. TypeOK /\ UNCHANGED vars => TypeOK'
    BY DEF TypeOK, vars, ServedKeys
  <2> QED
    BY <2>1, <2>2, <2>3 DEF Next, vars
<1> QED
  BY <1>1, <1>2, PTL DEF Spec
====
