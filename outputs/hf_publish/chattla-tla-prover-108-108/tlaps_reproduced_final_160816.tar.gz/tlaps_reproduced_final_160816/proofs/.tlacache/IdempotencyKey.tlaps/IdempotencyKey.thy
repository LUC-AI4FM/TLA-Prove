(* automatically generated -- do not edit manually *)
theory IdempotencyKey imports Constant Zenon begin
ML_command {* writeln ("*** TLAPS PARSED\n"); *}
consts
  "isReal" :: c
  "isa_slas_a" :: "[c,c] => c"
  "isa_bksl_diva" :: "[c,c] => c"
  "isa_perc_a" :: "[c,c] => c"
  "isa_peri_peri_a" :: "[c,c] => c"
  "isInfinity" :: c
  "isa_lbrk_rbrk_a" :: "[c] => c"
  "isa_less_more_a" :: "[c] => c"

lemma ob'54:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
(* usable definition CONSTANT_IsFiniteSet_ suppressed *)
(* usable definition CONSTANT_Cardinality_ suppressed *)
(* usable definition CONSTANT_Restrict_ suppressed *)
(* usable definition CONSTANT_Range_ suppressed *)
(* usable definition CONSTANT_Inverse_ suppressed *)
(* usable definition CONSTANT_IsInjective_ suppressed *)
(* usable definition CONSTANT_Injection_ suppressed *)
(* usable definition CONSTANT_Surjection_ suppressed *)
(* usable definition CONSTANT_Bijection_ suppressed *)
(* usable definition CONSTANT_ExistsInjection_ suppressed *)
(* usable definition CONSTANT_ExistsSurjection_ suppressed *)
(* usable definition CONSTANT_ExistsBijection_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_IsTransitivelyClosedOn_ suppressed *)
(* usable definition CONSTANT_IsWellFoundedOn_ suppressed *)
(* usable definition CONSTANT_SetLessThan_ suppressed *)
(* usable definition CONSTANT_WFDefOn_ suppressed *)
(* usable definition CONSTANT_OpDefinesFcn_ suppressed *)
(* usable definition CONSTANT_WFInductiveDefines_ suppressed *)
(* usable definition CONSTANT_WFInductiveUnique_ suppressed *)
(* usable definition CONSTANT_TransitiveClosureOn_ suppressed *)
(* usable definition CONSTANT_OpToRel_ suppressed *)
(* usable definition CONSTANT_PreImage_ suppressed *)
(* usable definition CONSTANT_LexPairOrdering_ suppressed *)
(* usable definition CONSTANT_LexProductOrdering_ suppressed *)
(* usable definition CONSTANT_FiniteSubsetsOf_ suppressed *)
(* usable definition CONSTANT_StrictSubsetOrdering_ suppressed *)
fixes a_CONSTANTunde_Keysunde_a
(* usable definition CONSTANT_NONE_ suppressed *)
fixes a_VARIABLEunde_cacheunde_a a_VARIABLEunde_cacheunde_a'
fixes a_VARIABLEunde_sideEffectsunde_a a_VARIABLEunde_sideEffectsunde_a'
fixes a_VARIABLEunde_observedunde_a a_VARIABLEunde_observedunde_a'
(* usable definition STATE_vars_ suppressed *)
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_FirstCall_ suppressed *)
(* usable definition ACTION_Retry_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
(* usable definition STATE_ServedKeys_ suppressed *)
(* usable definition STATE_TypeOK_ suppressed *)
assumes v'115: "(((a_CONSTANTunde_Keysunde_a) \<noteq> ({})))"
assumes v'116: "((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Keysunde_a))))"
assumes v'122: "(a_STATEunde_TypeOKunde_a)"
fixes a_CONSTANTunde_kunde_a
assumes a_CONSTANTunde_kunde_a_in : "(a_CONSTANTunde_kunde_a \<in> (a_CONSTANTunde_Keysunde_a))"
assumes v'124: "((a_ACTIONunde_FirstCallunde_a ((a_CONSTANTunde_kunde_a))))"
assumes v'142: "(((a_CONSTANTunde_kunde_a) \<notin> (a_STATEunde_ServedKeysunde_a)))"
assumes v'143: "((a_CONSTANTunde_IsFiniteSetunde_a ((a_STATEunde_ServedKeysunde_a))))"
assumes v'144: "((((a_h8b0e4a :: c)) = (((a_STATEunde_ServedKeysunde_a) \<union> ({(a_CONSTANTunde_kunde_a)})))))"
assumes v'145: "((\<And> a_CONSTANTunde_Sunde_a :: c. (\<And> a_CONSTANTunde_xunde_a :: c. (((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Sunde_a)))) \<Longrightarrow> (((a_CONSTANTunde_IsFiniteSetunde_a ((((a_CONSTANTunde_Sunde_a) \<union> ({(a_CONSTANTunde_xunde_a)})))))) & ((((a_CONSTANTunde_Cardinalityunde_a ((((a_CONSTANTunde_Sunde_a) \<union> ({(a_CONSTANTunde_xunde_a)})))))) = (cond((((a_CONSTANTunde_xunde_a) \<in> (a_CONSTANTunde_Sunde_a))), ((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Sunde_a)))), ((arith_add (((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Sunde_a)))), ((Succ[0]))))))))))))))"
shows "((((a_CONSTANTunde_Cardinalityunde_a (((a_h8b0e4a :: c))))) = ((arith_add (((a_CONSTANTunde_Cardinalityunde_a ((a_STATEunde_ServedKeysunde_a)))), ((Succ[0])))))))"(is "PROP ?ob'54")
proof -
ML_command {* writeln "*** TLAPS ENTER 54"; *}
show "PROP ?ob'54"

(* BEGIN ZENON INPUT
;; file=.tlacache/IdempotencyKey.tlaps/tlapm_18dcbe.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/IdempotencyKey.tlaps/tlapm_18dcbe.znn.out
;; obligation #54
$hyp "v'115" (-. (= a_CONSTANTunde_Keysunde_a
TLA.emptyset))
$hyp "v'116" (a_CONSTANTunde_IsFiniteSetunde_a a_CONSTANTunde_Keysunde_a)
$hyp "v'122" a_STATEunde_TypeOKunde_a
$hyp "a_CONSTANTunde_kunde_a_in" (TLA.in a_CONSTANTunde_kunde_a a_CONSTANTunde_Keysunde_a)
$hyp "v'124" (a_ACTIONunde_FirstCallunde_a a_CONSTANTunde_kunde_a)
$hyp "v'142" (-. (TLA.in a_CONSTANTunde_kunde_a
a_STATEunde_ServedKeysunde_a))
$hyp "v'143" (a_CONSTANTunde_IsFiniteSetunde_a a_STATEunde_ServedKeysunde_a)
$hyp "v'144" (= a_h8b0e4a (TLA.cup a_STATEunde_ServedKeysunde_a
(TLA.set a_CONSTANTunde_kunde_a)))
$hyp "v'145" (A. ((a_CONSTANTunde_Sunde_a) (A. ((a_CONSTANTunde_xunde_a) (=> (a_CONSTANTunde_IsFiniteSetunde_a a_CONSTANTunde_Sunde_a) (/\ (a_CONSTANTunde_IsFiniteSetunde_a (TLA.cup a_CONSTANTunde_Sunde_a
(TLA.set a_CONSTANTunde_xunde_a)))
(= (a_CONSTANTunde_Cardinalityunde_a (TLA.cup a_CONSTANTunde_Sunde_a
(TLA.set a_CONSTANTunde_xunde_a))) (TLA.cond (TLA.in a_CONSTANTunde_xunde_a
a_CONSTANTunde_Sunde_a) (a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Sunde_a) (arith.add (a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Sunde_a)
(TLA.fapply TLA.Succ 0))))))))))
$goal (= (a_CONSTANTunde_Cardinalityunde_a a_h8b0e4a)
(arith.add (a_CONSTANTunde_Cardinalityunde_a a_STATEunde_ServedKeysunde_a)
(TLA.fapply TLA.Succ 0)))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have z_Hh:"(a_h8b0e4a=(a_STATEunde_ServedKeysunde_a \\cup {a_CONSTANTunde_kunde_a}))" (is "_=?z_hl")
 using v'144 by blast
 have z_Hi:"(\\A a_CONSTANTunde_Sunde_a:(\\A a_CONSTANTunde_xunde_a:(a_CONSTANTunde_IsFiniteSetunde_a(a_CONSTANTunde_Sunde_a)=>(a_CONSTANTunde_IsFiniteSetunde_a((a_CONSTANTunde_Sunde_a \\cup {a_CONSTANTunde_xunde_a}))&(a_CONSTANTunde_Cardinalityunde_a((a_CONSTANTunde_Sunde_a \\cup {a_CONSTANTunde_xunde_a}))=cond((a_CONSTANTunde_xunde_a \\in a_CONSTANTunde_Sunde_a), a_CONSTANTunde_Cardinalityunde_a(a_CONSTANTunde_Sunde_a), (a_CONSTANTunde_Cardinalityunde_a(a_CONSTANTunde_Sunde_a) + 1)))))))" (is "\\A x : ?z_hbf(x)")
 using v'145 by blast
 have z_Hf:"(~(a_CONSTANTunde_kunde_a \\in a_STATEunde_ServedKeysunde_a))" (is "~?z_hbg")
 using v'142 by blast
 have z_Hg:"a_CONSTANTunde_IsFiniteSetunde_a(a_STATEunde_ServedKeysunde_a)" (is "?z_hg")
 using v'143 by blast
 assume z_Hj:"(a_CONSTANTunde_Cardinalityunde_a(a_h8b0e4a)~=(a_CONSTANTunde_Cardinalityunde_a(a_STATEunde_ServedKeysunde_a) + 1))" (is "?z_hbh~=?z_hbi")
 have z_Hbk: "(a_CONSTANTunde_Cardinalityunde_a(?z_hl)~=?z_hbi)" (is "?z_hbl~=_")
 by (rule subst [where P="(\<lambda>zenon_Vf. (a_CONSTANTunde_Cardinalityunde_a(zenon_Vf)~=?z_hbi))", OF z_Hh z_Hj])
 have z_Hbq: "?z_hbf(a_STATEunde_ServedKeysunde_a)" (is "\\A x : ?z_hbr(x)")
 by (rule zenon_all_0 [of "?z_hbf" "a_STATEunde_ServedKeysunde_a", OF z_Hi])
 have z_Hbs: "?z_hbr(a_CONSTANTunde_kunde_a)" (is "_=>?z_hbt")
 by (rule zenon_all_0 [of "?z_hbr" "a_CONSTANTunde_kunde_a", OF z_Hbq])
 show FALSE
 proof (rule zenon_imply [OF z_Hbs])
  assume z_Hbu:"(~?z_hg)"
  show FALSE
  by (rule notE [OF z_Hbu z_Hg])
 next
  assume z_Hbt:"?z_hbt" (is "?z_hbv&?z_hbw")
  have z_Hbw: "?z_hbw" (is "_=?z_hbx")
  by (rule zenon_and_1 [OF z_Hbt])
  show FALSE
  proof (rule zenon_ifthenelse [of "(\<lambda>zenon_Vlb. (?z_hbl=zenon_Vlb))" "?z_hbg" "a_CONSTANTunde_Cardinalityunde_a(a_STATEunde_ServedKeysunde_a)" "?z_hbi", OF z_Hbw])
   assume z_Hbg:"?z_hbg"
   assume z_Hcb:"(?z_hbl=a_CONSTANTunde_Cardinalityunde_a(a_STATEunde_ServedKeysunde_a))" (is "_=?z_hbj")
   show FALSE
   by (rule notE [OF z_Hf z_Hbg])
  next
   assume z_Hf:"(~?z_hbg)"
   assume z_Hcc:"(?z_hbl=?z_hbi)"
   show FALSE
   by (rule notE [OF z_Hbk z_Hcc])
  qed
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 54"; *} qed
end
