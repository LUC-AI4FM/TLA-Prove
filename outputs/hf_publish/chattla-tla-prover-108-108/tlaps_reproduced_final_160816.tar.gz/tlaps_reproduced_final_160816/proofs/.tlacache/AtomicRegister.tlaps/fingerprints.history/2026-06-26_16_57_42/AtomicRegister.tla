---- MODULE AtomicRegister ----
(***************************************************************************)
(* ABD-style read/write register replicated on N=3 nodes with majority    *)
(* quorums.  Each node stores a tagged value (timestamp, value).  A write *)
(* picks a fresh timestamp and is acknowledged by a majority; a read      *)
(* gathers from a majority and re-imposes the largest tag.                *)
(* Strong safety: replica timestamps are monotone non-decreasing and the  *)
(* "committed" value (max-tag in any majority) never regresses.           *)
(***************************************************************************)
EXTENDS TLAPS, Naturals, Integers, FiniteSets, FiniteSetTheorems

Nodes  == {"n1", "n2", "n3"}
Vals   == {0, 1}
MaxTs  == 2

Majority(S) == Cardinality(S) * 2 > Cardinality(Nodes)

VARIABLES store, writeTs

vars == << store, writeTs >>

TagSet(Q) == {store[m][1] : m \in Q}

MaxTag(Q) == CHOOSE t \in TagSet(Q) : \A m \in Q : store[m][1] <= t

Winner(Q) == CHOOSE m \in Q : store[m][1] = MaxTag(Q)

LEMMA NodesCard == Cardinality(Nodes) = 3
PROOF
<1>1. IsFiniteSet({"n1"}) /\ Cardinality({"n1"}) = 1
  BY FS_Singleton
<1>2. "n2" \notin {"n1"}
  OBVIOUS
<1>3. IsFiniteSet({"n1"} \cup {"n2"}) /\ Cardinality({"n1"} \cup {"n2"}) = 2
  BY <1>1, <1>2, FS_AddElement
<1>4. "n3" \notin ({"n1"} \cup {"n2"})
  OBVIOUS
<1>5. Cardinality(({"n1"} \cup {"n2"}) \cup {"n3"}) = 3
  BY <1>3, <1>4, FS_AddElement
<1>6. Nodes = ({"n1"} \cup {"n2"}) \cup {"n3"}
  BY DEF Nodes
<1> QED
  BY <1>5, <1>6

LEMMA MajorityNonEmpty ==
  \A Q \in SUBSET Nodes : Majority(Q) => Q # {}
PROOF
<1> SUFFICES ASSUME NEW Q \in SUBSET Nodes, Majority(Q)
             PROVE Q # {}
  OBVIOUS
<1>1. Cardinality({}) = 0
  BY FS_EmptySet
<1>2. Q = {} => ~ Majority(Q)
  BY <1>1, NodesCard DEF Majority
<1> QED
  BY <1>2

\* store[n] = <<ts, val>> currently held by node n.
\* writeTs  = highest timestamp ever issued by a writer (monotone).
Init ==
    /\ store = [n \in Nodes |-> <<0, 0>>]
    /\ writeTs = 0

\* Writer issues a new write with the next timestamp and a chosen value.
StartWrite ==
    /\ writeTs < MaxTs
    /\ writeTs' = writeTs + 1
    /\ UNCHANGED store

\* A node accepts the new write if its tag is fresher.
AcceptWrite(n, v) ==
    /\ writeTs > 0
    /\ store[n][1] < writeTs
    /\ store' = [store EXCEPT ![n] = <<writeTs, v>>]
    /\ UNCHANGED writeTs

\* Read-impose: a read picks any majority Q, takes the max tag value, and
\* writes it back to nodes in Q whose tag is older.
ReadImpose(n, Q) ==
    /\ Q \subseteq Nodes
    /\ Majority(Q)
    /\ store[n][1] < MaxTag(Q)
    /\ store' = [store EXCEPT ![n] = store[Winner(Q)]]
    /\ UNCHANGED writeTs

Done == UNCHANGED vars

Next ==
    \/ StartWrite
    \/ \E n \in Nodes, v \in Vals : AcceptWrite(n, v)
    \/ \E n \in Nodes, Q \in SUBSET Nodes : ReadImpose(n, Q)
    \/ Done

Spec == Init /\ [][Next]_vars

\* Strong safety conjoined into TypeOK: stored timestamp never exceeds the
\* writer's high-water-mark, and value-with-tag-0 is the initial 0.
TypeOK ==
    /\ store \in [Nodes -> (0 .. MaxTs) \X Vals]
    /\ writeTs \in 0 .. MaxTs
    /\ \A n \in Nodes : store[n][1] <= writeTs
    /\ \A n \in Nodes : (store[n][1] = 0) => (store[n][2] = 0)

LEMMA FiniteSetHasMax ==
  \A S \in SUBSET Int :
    IsFiniteSet(S) /\ (S # {}) => \E max \in S : \A x \in S : max >= x
<1>. DEFINE P(S) == S \subseteq Int /\ S # {} =>
                    \E max \in S : \A x \in S : max >= x
<1>1. P({})
  OBVIOUS
<1>2. ASSUME NEW T, NEW x, P(T)
      PROVE  P(T \cup {x})
  BY <1>2
<1>3. \A S : IsFiniteSet(S) => P(S)
  <2>. HIDE DEF P
  <2>. QED  BY <1>1, <1>2, FS_Induction, IsaM("blast")
<1>. QED  BY <1>3, Zenon

LEMMA MaxTagProp ==
  ASSUME TypeOK, NEW Q \in SUBSET Nodes, Majority(Q)
  PROVE  /\ MaxTag(Q) \in TagSet(Q)
         /\ \A m \in Q : store[m][1] <= MaxTag(Q)
PROOF
<1>1. Q # {}
  BY MajorityNonEmpty
<1>2. TagSet(Q) # {}
  BY <1>1 DEF TagSet
<1>3. TagSet(Q) \subseteq Int
  BY DEF TypeOK, TagSet, Nodes, MaxTs
<1>4. TagSet(Q) \subseteq 0..MaxTs
  BY DEF TypeOK, TagSet, Nodes, MaxTs
<1>5. IsFiniteSet(0..MaxTs)
  BY FS_Interval DEF MaxTs
<1>6. IsFiniteSet(TagSet(Q))
  BY <1>4, <1>5, FS_Subset
<1>7. \E max \in TagSet(Q) : \A x \in TagSet(Q) : max >= x
  BY <1>2, <1>3, <1>6, FiniteSetHasMax
<1>8. \E max \in TagSet(Q) : \A m \in Q : store[m][1] <= max
  BY <1>7 DEF TagSet
<1> QED
  BY <1>8 DEF MaxTag, TagSet

LEMMA WinnerProp ==
  ASSUME TypeOK, NEW Q \in SUBSET Nodes, Majority(Q)
  PROVE  /\ Winner(Q) \in Q
         /\ store[Winner(Q)][1] = MaxTag(Q)
PROOF
<1>1. MaxTag(Q) \in TagSet(Q)
  BY MaxTagProp
<1>2. \E m \in Q : store[m][1] = MaxTag(Q)
  BY <1>1 DEF TagSet
<1> QED
  BY <1>2 DEF Winner

THEOREM ChatTLA_TypeOKSafety == Spec => []TypeOK
PROOF
<1>1. Init => TypeOK
  BY DEF Init, TypeOK, Nodes, Vals, MaxTs, Majority, vars
<1>2. TypeOK /\ [Next]_vars => TypeOK'
  <2>1. TypeOK /\ StartWrite => TypeOK'
    BY DEF TypeOK, Nodes, Vals, MaxTs, vars, StartWrite
  <2>2. TypeOK /\ (\E n \in Nodes, v \in Vals : AcceptWrite(n, v)) => TypeOK'
    BY DEF TypeOK, Nodes, Vals, MaxTs, vars, AcceptWrite
  <2>3. TypeOK /\ (\E n \in Nodes, Q \in SUBSET Nodes : ReadImpose(n, Q)) => TypeOK'
    <3>. SUFFICES ASSUME TypeOK,
                         NEW n \in Nodes,
                         NEW Q \in SUBSET Nodes,
                         ReadImpose(n, Q)
                  PROVE TypeOK'
      OBVIOUS
    <3>1. /\ MaxTag(Q) \in TagSet(Q)
          /\ \A m \in Q : store[m][1] <= MaxTag(Q)
      BY MaxTagProp DEF ReadImpose
    <3>2. /\ Winner(Q) \in Q
          /\ store[Winner(Q)][1] = MaxTag(Q)
      BY WinnerProp DEF ReadImpose
    <3> QED
      BY <3>1, <3>2 DEF TypeOK, Nodes, Vals, MaxTs, Majority, vars, ReadImpose, TagSet, MaxTag, Winner
  <2>4. TypeOK /\ Done => TypeOK'
    BY DEF TypeOK, vars, Done
  <2>5. TypeOK /\ UNCHANGED vars => TypeOK'
    BY DEF TypeOK, vars
  <2> QED
    BY <2>1, <2>2, <2>3, <2>4, <2>5 DEF Next, vars
<1> QED
  BY <1>1, <1>2, PTL DEF Spec
====
