(* automatically generated -- do not edit manually *)
theory AtomicRegister imports Constant Zenon begin
ML_command {* writeln ("*** TLAPS PARSED\n"); *}
consts
  "isReal" :: c
  "isa_slas_a" :: "[c,c] => c"
  "isa_bksl_diva" :: "[c,c] => c"
  "isa_perc_a" :: "[c,c] => c"
  "isa_peri_peri_a" :: "[c,c] => c"
  "isInfinity" :: c
  "isa_lbrk_rbrk_a" :: "[c] => c"
  "isa_less_more_a" :: "[c] => c"

lemma ob'25:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
(* usable definition CONSTANT_IsFiniteSet_ suppressed *)
(* usable definition CONSTANT_Cardinality_ suppressed *)
(* usable definition CONSTANT_Restrict_ suppressed *)
(* usable definition CONSTANT_Range_ suppressed *)
(* usable definition CONSTANT_Inverse_ suppressed *)
(* usable definition CONSTANT_IsInjective_ suppressed *)
(* usable definition CONSTANT_Injection_ suppressed *)
(* usable definition CONSTANT_Surjection_ suppressed *)
(* usable definition CONSTANT_Bijection_ suppressed *)
(* usable definition CONSTANT_ExistsInjection_ suppressed *)
(* usable definition CONSTANT_ExistsSurjection_ suppressed *)
(* usable definition CONSTANT_ExistsBijection_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_IsTransitivelyClosedOn_ suppressed *)
(* usable definition CONSTANT_IsWellFoundedOn_ suppressed *)
(* usable definition CONSTANT_SetLessThan_ suppressed *)
(* usable definition CONSTANT_WFDefOn_ suppressed *)
(* usable definition CONSTANT_OpDefinesFcn_ suppressed *)
(* usable definition CONSTANT_WFInductiveDefines_ suppressed *)
(* usable definition CONSTANT_WFInductiveUnique_ suppressed *)
(* usable definition CONSTANT_TransitiveClosureOn_ suppressed *)
(* usable definition CONSTANT_OpToRel_ suppressed *)
(* usable definition CONSTANT_PreImage_ suppressed *)
(* usable definition CONSTANT_LexPairOrdering_ suppressed *)
(* usable definition CONSTANT_LexProductOrdering_ suppressed *)
(* usable definition CONSTANT_FiniteSubsetsOf_ suppressed *)
(* usable definition CONSTANT_StrictSubsetOrdering_ suppressed *)
(* usable definition CONSTANT_Nodes_ suppressed *)
(* usable definition CONSTANT_Vals_ suppressed *)
(* usable definition CONSTANT_MaxTs_ suppressed *)
(* usable definition CONSTANT_Majority_ suppressed *)
fixes a_VARIABLEunde_storeunde_a a_VARIABLEunde_storeunde_a'
fixes a_VARIABLEunde_writeTsunde_a a_VARIABLEunde_writeTsunde_a'
(* usable definition STATE_vars_ suppressed *)
(* usable definition STATE_TagSet_ suppressed *)
(* usable definition STATE_MaxTag_ suppressed *)
(* usable definition STATE_Winner_ suppressed *)
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_StartWrite_ suppressed *)
(* usable definition ACTION_AcceptWrite_ suppressed *)
(* usable definition ACTION_ReadImpose_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
(* usable definition STATE_TypeOK_ suppressed *)
assumes v'125: "(\<forall>a_CONSTANTunde_Sunde_a : ((((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Sunde_a)))) \<Rightarrow> (((((((a_CONSTANTunde_Sunde_a) \<subseteq> (Int))) \<and> (((a_CONSTANTunde_Sunde_a) \<noteq> ({}))))) \<Rightarrow> (\<exists> a_CONSTANTunde_maxunde_a \<in> (a_CONSTANTunde_Sunde_a) : (\<forall> a_CONSTANTunde_xunde_a \<in> (a_CONSTANTunde_Sunde_a) : ((geq ((a_CONSTANTunde_maxunde_a), (a_CONSTANTunde_xunde_a)))))))))))"
shows "(\<forall> a_CONSTANTunde_Sunde_a \<in> ((SUBSET (Int))) : ((((((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Sunde_a)))) \<and> (((a_CONSTANTunde_Sunde_a) \<noteq> ({}))))) \<Rightarrow> (\<exists> a_CONSTANTunde_maxunde_a \<in> (a_CONSTANTunde_Sunde_a) : (\<forall> a_CONSTANTunde_xunde_a \<in> (a_CONSTANTunde_Sunde_a) : ((geq ((a_CONSTANTunde_maxunde_a), (a_CONSTANTunde_xunde_a)))))))))"(is "PROP ?ob'25")
proof -
ML_command {* writeln "*** TLAPS ENTER 25"; *}
show "PROP ?ob'25"

(* BEGIN ZENON INPUT
;; file=.tlacache/AtomicRegister.tlaps/tlapm_b7c17e.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/AtomicRegister.tlaps/tlapm_b7c17e.znn.out
;; obligation #25
$hyp "v'125" (A. ((a_CONSTANTunde_Sunde_a) (=> (a_CONSTANTunde_IsFiniteSetunde_a a_CONSTANTunde_Sunde_a)
(=> (/\ (TLA.subseteq a_CONSTANTunde_Sunde_a arith.Z)
(-. (= a_CONSTANTunde_Sunde_a TLA.emptyset)))
(TLA.bEx a_CONSTANTunde_Sunde_a ((a_CONSTANTunde_maxunde_a) (TLA.bAll a_CONSTANTunde_Sunde_a ((a_CONSTANTunde_xunde_a) (arith.le a_CONSTANTunde_xunde_a
a_CONSTANTunde_maxunde_a)))))))))
$goal (TLA.bAll (TLA.SUBSET arith.Z) ((a_CONSTANTunde_Sunde_a) (=> (/\ (a_CONSTANTunde_IsFiniteSetunde_a a_CONSTANTunde_Sunde_a)
(-. (= a_CONSTANTunde_Sunde_a TLA.emptyset)))
(TLA.bEx a_CONSTANTunde_Sunde_a ((a_CONSTANTunde_maxunde_a) (TLA.bAll a_CONSTANTunde_Sunde_a ((a_CONSTANTunde_xunde_a) (arith.le a_CONSTANTunde_xunde_a
a_CONSTANTunde_maxunde_a))))))))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have z_Ha:"(\\A a_CONSTANTunde_Sunde_a:(a_CONSTANTunde_IsFiniteSetunde_a(a_CONSTANTunde_Sunde_a)=>(((a_CONSTANTunde_Sunde_a \\subseteq Int)&(a_CONSTANTunde_Sunde_a~={}))=>bEx(a_CONSTANTunde_Sunde_a, (\<lambda>a_CONSTANTunde_maxunde_a. bAll(a_CONSTANTunde_Sunde_a, (\<lambda>a_CONSTANTunde_xunde_a. (a_CONSTANTunde_xunde_a <= a_CONSTANTunde_maxunde_a))))))))" (is "\\A x : ?z_hs(x)")
 using v'125 by blast
 assume z_Hb:"(~bAll(SUBSET(Int), (\<lambda>a_CONSTANTunde_Sunde_a. ((a_CONSTANTunde_IsFiniteSetunde_a(a_CONSTANTunde_Sunde_a)&(a_CONSTANTunde_Sunde_a~={}))=>bEx(a_CONSTANTunde_Sunde_a, (\<lambda>a_CONSTANTunde_maxunde_a. bAll(a_CONSTANTunde_Sunde_a, (\<lambda>a_CONSTANTunde_xunde_a. (a_CONSTANTunde_xunde_a <= a_CONSTANTunde_maxunde_a)))))))))" (is "~?z_ht")
 have z_Hy_z_Hb: "(~(\\A x:((x \\in SUBSET(Int))=>((a_CONSTANTunde_IsFiniteSetunde_a(x)&(x~={}))=>bEx(x, (\<lambda>a_CONSTANTunde_maxunde_a. bAll(x, (\<lambda>a_CONSTANTunde_xunde_a. (a_CONSTANTunde_xunde_a <= a_CONSTANTunde_maxunde_a))))))))) == (~?z_ht)" (is "?z_hy == ?z_hb")
 by (unfold bAll_def)
 have z_Hy: "?z_hy" (is "~(\\A x : ?z_hbk(x))")
 by (unfold z_Hy_z_Hb, fact z_Hb)
 have z_Hbl: "(\\E x:(~((x \\in SUBSET(Int))=>((a_CONSTANTunde_IsFiniteSetunde_a(x)&(x~={}))=>bEx(x, (\<lambda>a_CONSTANTunde_maxunde_a. bAll(x, (\<lambda>a_CONSTANTunde_xunde_a. (a_CONSTANTunde_xunde_a <= a_CONSTANTunde_maxunde_a)))))))))" (is "\\E x : ?z_hbn(x)")
 by (rule zenon_notallex_0 [of "?z_hbk", OF z_Hy])
 have z_Hbo: "?z_hbn((CHOOSE x:(~((x \\in SUBSET(Int))=>((a_CONSTANTunde_IsFiniteSetunde_a(x)&(x~={}))=>bEx(x, (\<lambda>a_CONSTANTunde_maxunde_a. bAll(x, (\<lambda>a_CONSTANTunde_xunde_a. (a_CONSTANTunde_xunde_a <= a_CONSTANTunde_maxunde_a))))))))))" (is "~(?z_hbq=>?z_hbr)")
 by (rule zenon_ex_choose_0 [of "?z_hbn", OF z_Hbl])
 have z_Hbq: "?z_hbq"
 by (rule zenon_notimply_0 [OF z_Hbo])
 have z_Hbs: "(~?z_hbr)" (is "~(?z_hbt=>?z_hbu)")
 by (rule zenon_notimply_1 [OF z_Hbo])
 have z_Hbt: "?z_hbt" (is "?z_hbv&?z_hbw")
 by (rule zenon_notimply_0 [OF z_Hbs])
 have z_Hbx: "(~?z_hbu)"
 by (rule zenon_notimply_1 [OF z_Hbs])
 have z_Hbv: "?z_hbv"
 by (rule zenon_and_0 [OF z_Hbt])
 have z_Hbw: "?z_hbw" (is "?z_hbp~=_")
 by (rule zenon_and_1 [OF z_Hbt])
 have z_Hby: "(?z_hbp \\subseteq Int)" (is "?z_hby")
 by (rule zenon_in_SUBSET_0 [of "?z_hbp" "Int", OF z_Hbq])
 have z_Hbz: "?z_hs(?z_hbp)" (is "_=>?z_hca")
 by (rule zenon_all_0 [of "?z_hs" "?z_hbp", OF z_Ha])
 show FALSE
 proof (rule zenon_imply [OF z_Hbz])
  assume z_Hcb:"(~?z_hbv)"
  show FALSE
  by (rule notE [OF z_Hcb z_Hbv])
 next
  assume z_Hca:"?z_hca" (is "?z_hcc=>_")
  show FALSE
  proof (rule zenon_imply [OF z_Hca])
   assume z_Hcd:"(~?z_hcc)"
   show FALSE
   proof (rule zenon_notand [OF z_Hcd])
    assume z_Hce:"(~?z_hby)"
    show FALSE
    by (rule notE [OF z_Hce z_Hby])
   next
    assume z_Hcf:"(~?z_hbw)" (is "~~?z_hcg")
    show FALSE
    by (rule notE [OF z_Hcf z_Hbw])
   qed
  next
   assume z_Hbu:"?z_hbu"
   show FALSE
   by (rule notE [OF z_Hbx z_Hbu])
  qed
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 25"; *} qed
lemma ob'31:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
(* usable definition CONSTANT_IsFiniteSet_ suppressed *)
(* usable definition CONSTANT_Cardinality_ suppressed *)
(* usable definition CONSTANT_Restrict_ suppressed *)
(* usable definition CONSTANT_Range_ suppressed *)
(* usable definition CONSTANT_Inverse_ suppressed *)
(* usable definition CONSTANT_IsInjective_ suppressed *)
(* usable definition CONSTANT_Injection_ suppressed *)
(* usable definition CONSTANT_Surjection_ suppressed *)
(* usable definition CONSTANT_Bijection_ suppressed *)
(* usable definition CONSTANT_ExistsInjection_ suppressed *)
(* usable definition CONSTANT_ExistsSurjection_ suppressed *)
(* usable definition CONSTANT_ExistsBijection_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_IsTransitivelyClosedOn_ suppressed *)
(* usable definition CONSTANT_IsWellFoundedOn_ suppressed *)
(* usable definition CONSTANT_SetLessThan_ suppressed *)
(* usable definition CONSTANT_WFDefOn_ suppressed *)
(* usable definition CONSTANT_OpDefinesFcn_ suppressed *)
(* usable definition CONSTANT_WFInductiveDefines_ suppressed *)
(* usable definition CONSTANT_WFInductiveUnique_ suppressed *)
(* usable definition CONSTANT_TransitiveClosureOn_ suppressed *)
(* usable definition CONSTANT_OpToRel_ suppressed *)
(* usable definition CONSTANT_PreImage_ suppressed *)
(* usable definition CONSTANT_LexPairOrdering_ suppressed *)
(* usable definition CONSTANT_LexProductOrdering_ suppressed *)
(* usable definition CONSTANT_FiniteSubsetsOf_ suppressed *)
(* usable definition CONSTANT_StrictSubsetOrdering_ suppressed *)
(* usable definition CONSTANT_Nodes_ suppressed *)
(* usable definition CONSTANT_Vals_ suppressed *)
(* usable definition CONSTANT_MaxTs_ suppressed *)
(* usable definition CONSTANT_Majority_ suppressed *)
fixes a_VARIABLEunde_storeunde_a a_VARIABLEunde_storeunde_a'
fixes a_VARIABLEunde_writeTsunde_a a_VARIABLEunde_writeTsunde_a'
(* usable definition STATE_vars_ suppressed *)
(* usable definition STATE_TagSet_ suppressed *)
(* usable definition STATE_MaxTag_ suppressed *)
(* usable definition STATE_Winner_ suppressed *)
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_StartWrite_ suppressed *)
(* usable definition ACTION_AcceptWrite_ suppressed *)
(* usable definition ACTION_ReadImpose_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
(* usable definition STATE_TypeOK_ suppressed *)
(* usable definition CONSTANT_P_ suppressed *)
assumes v'127: "((a_CONSTANTunde_Punde_a (({}))))"
assumes v'128: "((\<And> a_CONSTANTunde_Tunde_a :: c. (\<And> a_CONSTANTunde_xunde_a :: c. (((a_CONSTANTunde_Punde_a ((a_CONSTANTunde_Tunde_a)))) \<Longrightarrow> ((a_CONSTANTunde_Punde_a ((((a_CONSTANTunde_Tunde_a) \<union> ({(a_CONSTANTunde_xunde_a)}))))))))))"
assumes v'129: "((\<And> a_CONSTANTunde_Sunde_a :: c. (((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Sunde_a)))) \<Longrightarrow> (\<And> a_CONSTANTunde_Punde_a_1 :: c => c. (((a_CONSTANTunde_Punde_a_1 (({})))) \<Longrightarrow> (((\<And> a_CONSTANTunde_Tunde_a :: c. (\<And> a_CONSTANTunde_xunde_a :: c. (((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Tunde_a)))) \<Longrightarrow> (((a_CONSTANTunde_Punde_a_1 ((a_CONSTANTunde_Tunde_a)))) \<Longrightarrow> ((((a_CONSTANTunde_xunde_a) \<notin> (a_CONSTANTunde_Tunde_a))) \<Longrightarrow> ((a_CONSTANTunde_Punde_a_1 ((((a_CONSTANTunde_Tunde_a) \<union> ({(a_CONSTANTunde_xunde_a)})))))))))))) \<Longrightarrow> ((a_CONSTANTunde_Punde_a_1 ((a_CONSTANTunde_Sunde_a))))))))))"
shows "(\<forall>a_CONSTANTunde_Sunde_a : ((((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Sunde_a)))) \<Rightarrow> ((a_CONSTANTunde_Punde_a ((a_CONSTANTunde_Sunde_a)))))))"(is "PROP ?ob'31")
proof -
ML_command {* writeln "*** TLAPS ENTER 31"; *}
show "PROP ?ob'31"
using assms by blast
ML_command {* writeln "*** TLAPS EXIT 31"; *} qed
lemma ob'44:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
(* usable definition CONSTANT_IsFiniteSet_ suppressed *)
(* usable definition CONSTANT_Cardinality_ suppressed *)
(* usable definition CONSTANT_Restrict_ suppressed *)
(* usable definition CONSTANT_Range_ suppressed *)
(* usable definition CONSTANT_Inverse_ suppressed *)
(* usable definition CONSTANT_IsInjective_ suppressed *)
(* usable definition CONSTANT_Injection_ suppressed *)
(* usable definition CONSTANT_Surjection_ suppressed *)
(* usable definition CONSTANT_Bijection_ suppressed *)
(* usable definition CONSTANT_ExistsInjection_ suppressed *)
(* usable definition CONSTANT_ExistsSurjection_ suppressed *)
(* usable definition CONSTANT_ExistsBijection_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_IsTransitivelyClosedOn_ suppressed *)
(* usable definition CONSTANT_IsWellFoundedOn_ suppressed *)
(* usable definition CONSTANT_SetLessThan_ suppressed *)
(* usable definition CONSTANT_WFDefOn_ suppressed *)
(* usable definition CONSTANT_OpDefinesFcn_ suppressed *)
(* usable definition CONSTANT_WFInductiveDefines_ suppressed *)
(* usable definition CONSTANT_WFInductiveUnique_ suppressed *)
(* usable definition CONSTANT_TransitiveClosureOn_ suppressed *)
(* usable definition CONSTANT_OpToRel_ suppressed *)
(* usable definition CONSTANT_PreImage_ suppressed *)
(* usable definition CONSTANT_LexPairOrdering_ suppressed *)
(* usable definition CONSTANT_LexProductOrdering_ suppressed *)
(* usable definition CONSTANT_FiniteSubsetsOf_ suppressed *)
(* usable definition CONSTANT_StrictSubsetOrdering_ suppressed *)
(* usable definition CONSTANT_Nodes_ suppressed *)
(* usable definition CONSTANT_Vals_ suppressed *)
(* usable definition CONSTANT_Majority_ suppressed *)
fixes a_VARIABLEunde_storeunde_a a_VARIABLEunde_storeunde_a'
fixes a_VARIABLEunde_writeTsunde_a a_VARIABLEunde_writeTsunde_a'
(* usable definition STATE_vars_ suppressed *)
(* usable definition STATE_TagSet_ suppressed *)
(* usable definition STATE_MaxTag_ suppressed *)
(* usable definition STATE_Winner_ suppressed *)
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_StartWrite_ suppressed *)
(* usable definition ACTION_AcceptWrite_ suppressed *)
(* usable definition ACTION_ReadImpose_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
(* usable definition STATE_TypeOK_ suppressed *)
assumes v'122: "(a_STATEunde_TypeOKunde_a)"
fixes a_CONSTANTunde_Qunde_a
assumes a_CONSTANTunde_Qunde_a_in : "(a_CONSTANTunde_Qunde_a \<in> ((SUBSET (a_CONSTANTunde_Nodesunde_a))))"
assumes v'124: "((a_CONSTANTunde_Majorityunde_a ((a_CONSTANTunde_Qunde_a))))"
assumes v'131: "((\<And> a_CONSTANTunde_aunde_a :: c. a_CONSTANTunde_aunde_a \<in> (Int) \<Longrightarrow> (\<And> a_CONSTANTunde_bunde_a :: c. a_CONSTANTunde_bunde_a \<in> (Int) \<Longrightarrow> (((a_CONSTANTunde_IsFiniteSetunde_a (((isa_peri_peri_a ((a_CONSTANTunde_aunde_a), (a_CONSTANTunde_bunde_a))))))) & ((((a_CONSTANTunde_Cardinalityunde_a (((isa_peri_peri_a ((a_CONSTANTunde_aunde_a), (a_CONSTANTunde_bunde_a))))))) = (cond(((greater ((a_CONSTANTunde_aunde_a), (a_CONSTANTunde_bunde_a)))), ((0)), ((arith_add (((arith_add ((a_CONSTANTunde_bunde_a), ((minus ((a_CONSTANTunde_aunde_a))))))), ((Succ[0])))))))))))))"
shows "((a_CONSTANTunde_IsFiniteSetunde_a (((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))))"(is "PROP ?ob'44")
proof -
ML_command {* writeln "*** TLAPS ENTER 44"; *}
show "PROP ?ob'44"
using assms by auto
ML_command {* writeln "*** TLAPS EXIT 44"; *} qed
lemma ob'46:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
(* usable definition CONSTANT_IsFiniteSet_ suppressed *)
(* usable definition CONSTANT_Cardinality_ suppressed *)
(* usable definition CONSTANT_Restrict_ suppressed *)
(* usable definition CONSTANT_Range_ suppressed *)
(* usable definition CONSTANT_Inverse_ suppressed *)
(* usable definition CONSTANT_IsInjective_ suppressed *)
(* usable definition CONSTANT_Injection_ suppressed *)
(* usable definition CONSTANT_Surjection_ suppressed *)
(* usable definition CONSTANT_Bijection_ suppressed *)
(* usable definition CONSTANT_ExistsInjection_ suppressed *)
(* usable definition CONSTANT_ExistsSurjection_ suppressed *)
(* usable definition CONSTANT_ExistsBijection_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_IsTransitivelyClosedOn_ suppressed *)
(* usable definition CONSTANT_IsWellFoundedOn_ suppressed *)
(* usable definition CONSTANT_SetLessThan_ suppressed *)
(* usable definition CONSTANT_WFDefOn_ suppressed *)
(* usable definition CONSTANT_OpDefinesFcn_ suppressed *)
(* usable definition CONSTANT_WFInductiveDefines_ suppressed *)
(* usable definition CONSTANT_WFInductiveUnique_ suppressed *)
(* usable definition CONSTANT_TransitiveClosureOn_ suppressed *)
(* usable definition CONSTANT_OpToRel_ suppressed *)
(* usable definition CONSTANT_PreImage_ suppressed *)
(* usable definition CONSTANT_LexPairOrdering_ suppressed *)
(* usable definition CONSTANT_LexProductOrdering_ suppressed *)
(* usable definition CONSTANT_FiniteSubsetsOf_ suppressed *)
(* usable definition CONSTANT_StrictSubsetOrdering_ suppressed *)
(* usable definition CONSTANT_Nodes_ suppressed *)
(* usable definition CONSTANT_Vals_ suppressed *)
(* usable definition CONSTANT_MaxTs_ suppressed *)
(* usable definition CONSTANT_Majority_ suppressed *)
fixes a_VARIABLEunde_storeunde_a a_VARIABLEunde_storeunde_a'
fixes a_VARIABLEunde_writeTsunde_a a_VARIABLEunde_writeTsunde_a'
(* usable definition STATE_vars_ suppressed *)
(* usable definition STATE_TagSet_ suppressed *)
(* usable definition STATE_MaxTag_ suppressed *)
(* usable definition STATE_Winner_ suppressed *)
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_StartWrite_ suppressed *)
(* usable definition ACTION_AcceptWrite_ suppressed *)
(* usable definition ACTION_ReadImpose_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
(* usable definition STATE_TypeOK_ suppressed *)
assumes v'123: "(a_STATEunde_TypeOKunde_a)"
fixes a_CONSTANTunde_Qunde_a
assumes a_CONSTANTunde_Qunde_a_in : "(a_CONSTANTunde_Qunde_a \<in> ((SUBSET (a_CONSTANTunde_Nodesunde_a))))"
assumes v'125: "((a_CONSTANTunde_Majorityunde_a ((a_CONSTANTunde_Qunde_a))))"
assumes v'133: "((((a_STATEunde_TagSetunde_a ((a_CONSTANTunde_Qunde_a)))) \<subseteq> ((isa_peri_peri_a (((0)), (a_CONSTANTunde_MaxTsunde_a))))))"
assumes v'134: "((a_CONSTANTunde_IsFiniteSetunde_a (((isa_peri_peri_a (((0)), (a_CONSTANTunde_MaxTsunde_a)))))))"
assumes v'135: "((\<And> a_CONSTANTunde_Sunde_a :: c. (((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Sunde_a)))) \<Longrightarrow> (\<And> a_CONSTANTunde_Tunde_a :: c. a_CONSTANTunde_Tunde_a \<in> ((SUBSET (a_CONSTANTunde_Sunde_a))) \<Longrightarrow> (((a_CONSTANTunde_IsFiniteSetunde_a ((a_CONSTANTunde_Tunde_a)))) & ((leq (((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Tunde_a)))), ((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Sunde_a))))))) & ((((((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Sunde_a)))) = ((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Tunde_a)))))) \<Rightarrow> (((a_CONSTANTunde_Sunde_a) = (a_CONSTANTunde_Tunde_a))))))))))"
shows "((a_CONSTANTunde_IsFiniteSetunde_a (((a_STATEunde_TagSetunde_a ((a_CONSTANTunde_Qunde_a)))))))"(is "PROP ?ob'46")
proof -
ML_command {* writeln "*** TLAPS ENTER 46"; *}
show "PROP ?ob'46"

(* BEGIN ZENON INPUT
;; file=.tlacache/AtomicRegister.tlaps/tlapm_e7fb06.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/AtomicRegister.tlaps/tlapm_e7fb06.znn.out
;; obligation #46
$hyp "v'123" a_STATEunde_TypeOKunde_a
$hyp "a_CONSTANTunde_Qunde_a_in" (TLA.in a_CONSTANTunde_Qunde_a (TLA.SUBSET a_CONSTANTunde_Nodesunde_a))
$hyp "v'125" (a_CONSTANTunde_Majorityunde_a a_CONSTANTunde_Qunde_a)
$hyp "v'133" (TLA.subseteq (a_STATEunde_TagSetunde_a a_CONSTANTunde_Qunde_a)
(arith.intrange 0
a_CONSTANTunde_MaxTsunde_a))
$hyp "v'134" (a_CONSTANTunde_IsFiniteSetunde_a (arith.intrange 0
a_CONSTANTunde_MaxTsunde_a))
$hyp "v'135" (A. ((a_CONSTANTunde_Sunde_a) (=> (a_CONSTANTunde_IsFiniteSetunde_a a_CONSTANTunde_Sunde_a) (TLA.bAll (TLA.SUBSET a_CONSTANTunde_Sunde_a) ((a_CONSTANTunde_Tunde_a) (/\ (a_CONSTANTunde_IsFiniteSetunde_a a_CONSTANTunde_Tunde_a)
(arith.le (a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Tunde_a)
(a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Sunde_a))
(=> (= (a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Sunde_a)
(a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Tunde_a))
(= a_CONSTANTunde_Sunde_a
a_CONSTANTunde_Tunde_a))))))))
$goal (a_CONSTANTunde_IsFiniteSetunde_a (a_STATEunde_TagSetunde_a a_CONSTANTunde_Qunde_a))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have z_Hf:"(\\A a_CONSTANTunde_Sunde_a:(a_CONSTANTunde_IsFiniteSetunde_a(a_CONSTANTunde_Sunde_a)=>bAll(SUBSET(a_CONSTANTunde_Sunde_a), (\<lambda>a_CONSTANTunde_Tunde_a. (a_CONSTANTunde_IsFiniteSetunde_a(a_CONSTANTunde_Tunde_a)&((a_CONSTANTunde_Cardinalityunde_a(a_CONSTANTunde_Tunde_a) <= a_CONSTANTunde_Cardinalityunde_a(a_CONSTANTunde_Sunde_a))&((a_CONSTANTunde_Cardinalityunde_a(a_CONSTANTunde_Sunde_a)=a_CONSTANTunde_Cardinalityunde_a(a_CONSTANTunde_Tunde_a))=>(a_CONSTANTunde_Sunde_a=a_CONSTANTunde_Tunde_a))))))))" (is "\\A x : ?z_hx(x)")
 using v'135 by blast
 have z_He:"a_CONSTANTunde_IsFiniteSetunde_a(isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a))" (is "?z_he")
 using v'134 by blast
 have z_Hd:"(a_STATEunde_TagSetunde_a(a_CONSTANTunde_Qunde_a) \\subseteq isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a))" (is "?z_hd")
 using v'133 by blast
 assume z_Hg:"(~a_CONSTANTunde_IsFiniteSetunde_a(a_STATEunde_TagSetunde_a(a_CONSTANTunde_Qunde_a)))" (is "~?z_hbd")
 have z_Hbe: "?z_hx(isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a))" (is "_=>?z_hbf")
 by (rule zenon_all_0 [of "?z_hx" "isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a)", OF z_Hf])
 show FALSE
 proof (rule zenon_imply [OF z_Hbe])
  assume z_Hbg:"(~?z_he)"
  show FALSE
  by (rule notE [OF z_Hbg z_He])
 next
  assume z_Hbf:"?z_hbf"
  have z_Hbh_z_Hbf: "(\\A x:((x \\in SUBSET(isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a)))=>(a_CONSTANTunde_IsFiniteSetunde_a(x)&((a_CONSTANTunde_Cardinalityunde_a(x) <= a_CONSTANTunde_Cardinalityunde_a(isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a)))&((a_CONSTANTunde_Cardinalityunde_a(isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a))=a_CONSTANTunde_Cardinalityunde_a(x))=>(isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a)=x)))))) == ?z_hbf" (is "?z_hbh == _")
  by (unfold bAll_def)
  have z_Hbh: "?z_hbh" (is "\\A x : ?z_hbv(x)")
  by (unfold z_Hbh_z_Hbf, fact z_Hbf)
  have z_Hbw: "?z_hbv(a_STATEunde_TagSetunde_a(a_CONSTANTunde_Qunde_a))" (is "?z_hbx=>?z_hby")
  by (rule zenon_all_0 [of "?z_hbv" "a_STATEunde_TagSetunde_a(a_CONSTANTunde_Qunde_a)", OF z_Hbh])
  show FALSE
  proof (rule zenon_imply [OF z_Hbw])
   assume z_Hbz:"(~?z_hbx)"
   have z_Hca: "(~?z_hd)"
   by (rule zenon_notin_SUBSET_0 [of "a_STATEunde_TagSetunde_a(a_CONSTANTunde_Qunde_a)" "isa'dotdot(0, a_CONSTANTunde_MaxTsunde_a)", OF z_Hbz])
   show FALSE
   by (rule notE [OF z_Hca z_Hd])
  next
   assume z_Hby:"?z_hby" (is "_&?z_hcb")
   have z_Hbd: "?z_hbd"
   by (rule zenon_and_0 [OF z_Hby])
   show FALSE
   by (rule notE [OF z_Hg z_Hbd])
  qed
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 46"; *} qed
lemma ob'76:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
(* usable definition CONSTANT_IsFiniteSet_ suppressed *)
(* usable definition CONSTANT_Cardinality_ suppressed *)
(* usable definition CONSTANT_Restrict_ suppressed *)
(* usable definition CONSTANT_Range_ suppressed *)
(* usable definition CONSTANT_Inverse_ suppressed *)
(* usable definition CONSTANT_IsInjective_ suppressed *)
(* usable definition CONSTANT_Injection_ suppressed *)
(* usable definition CONSTANT_Surjection_ suppressed *)
(* usable definition CONSTANT_Bijection_ suppressed *)
(* usable definition CONSTANT_ExistsInjection_ suppressed *)
(* usable definition CONSTANT_ExistsSurjection_ suppressed *)
(* usable definition CONSTANT_ExistsBijection_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_NatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefHypothesis_ suppressed *)
(* usable definition CONSTANT_FiniteNatInductiveDefConclusion_ suppressed *)
(* usable definition CONSTANT_IsTransitivelyClosedOn_ suppressed *)
(* usable definition CONSTANT_IsWellFoundedOn_ suppressed *)
(* usable definition CONSTANT_SetLessThan_ suppressed *)
(* usable definition CONSTANT_WFDefOn_ suppressed *)
(* usable definition CONSTANT_OpDefinesFcn_ suppressed *)
(* usable definition CONSTANT_WFInductiveDefines_ suppressed *)
(* usable definition CONSTANT_WFInductiveUnique_ suppressed *)
(* usable definition CONSTANT_TransitiveClosureOn_ suppressed *)
(* usable definition CONSTANT_OpToRel_ suppressed *)
(* usable definition CONSTANT_PreImage_ suppressed *)
(* usable definition CONSTANT_LexPairOrdering_ suppressed *)
(* usable definition CONSTANT_LexProductOrdering_ suppressed *)
(* usable definition CONSTANT_FiniteSubsetsOf_ suppressed *)
(* usable definition CONSTANT_StrictSubsetOrdering_ suppressed *)
fixes a_VARIABLEunde_storeunde_a a_VARIABLEunde_storeunde_a'
fixes a_VARIABLEunde_writeTsunde_a a_VARIABLEunde_writeTsunde_a'
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_StartWrite_ suppressed *)
(* usable definition ACTION_AcceptWrite_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
assumes v'122: "((((a_VARIABLEunde_storeunde_a) \<in> ([({(''n1''), (''n2''), (''n3'')}) \<rightarrow> ((((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))) \<times> ({((0)), ((Succ[0]))})))]))) & (((a_VARIABLEunde_writeTsunde_a) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & (\<forall> a_CONSTANTunde_nunde_a \<in> ({(''n1''), (''n2''), (''n3'')}) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_nunde_a))), ((Succ[0])))), (a_VARIABLEunde_writeTsunde_a))))) & (\<forall> a_CONSTANTunde_nunde_a \<in> ({(''n1''), (''n2''), (''n3'')}) : (((((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_nunde_a))), ((Succ[0])))) = ((0)))) \<Rightarrow> (((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_nunde_a))), ((Succ[Succ[0]])))) = ((0))))))))"
fixes a_CONSTANTunde_nunde_a
assumes a_CONSTANTunde_nunde_a_in : "(a_CONSTANTunde_nunde_a \<in> ({(''n1''), (''n2''), (''n3'')}))"
fixes a_CONSTANTunde_Qunde_a
assumes a_CONSTANTunde_Qunde_a_in : "(a_CONSTANTunde_Qunde_a \<in> ((SUBSET ({(''n1''), (''n2''), (''n3'')}))))"
assumes v'125: "((((a_CONSTANTunde_Qunde_a) \<subseteq> ({(''n1''), (''n2''), (''n3'')}))) & ((greater (((mult (((a_CONSTANTunde_Cardinalityunde_a ((a_CONSTANTunde_Qunde_a)))), ((Succ[Succ[0]]))))), ((a_CONSTANTunde_Cardinalityunde_a (({(''n1''), (''n2''), (''n3'')}))))))) & ((less ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_nunde_a))), ((Succ[0])))), (bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))), (a_CONSTANTunde_tunde_a)))))))))))"
assumes v'126: "((((a_VARIABLEunde_storeunde_hash_primea :: c)) = ([(a_VARIABLEunde_storeunde_a) EXCEPT ![(a_CONSTANTunde_nunde_a)] = (fapply ((a_VARIABLEunde_storeunde_a), (bChoice((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))) = (bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a_1. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a_1 \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))), (a_CONSTANTunde_tunde_a)))))))))))))])))"
assumes v'127: "((((a_VARIABLEunde_writeTsunde_hash_primea :: c)) = (a_VARIABLEunde_writeTsunde_a)))"
assumes v'132: "((((bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))), (a_CONSTANTunde_tunde_a))))))) \<in> (setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))))))) & (\<forall> a_CONSTANTunde_munde_a \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))), (bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a_1. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a_1 \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))), (a_CONSTANTunde_tunde_a))))))))))))"
assumes v'133: "(((bChoice((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))) = (bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a_1. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a_1 \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))), (a_CONSTANTunde_tunde_a))))))))))) \<in> (a_CONSTANTunde_Qunde_a)))"
assumes v'134: "(((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (bChoice((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))) = (bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a_1. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a_1 \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a_1))), ((Succ[0])))), (a_CONSTANTunde_tunde_a))))))))))))), ((Succ[0])))) = (bChoice((setOfAll((a_CONSTANTunde_Qunde_a), %a_CONSTANTunde_munde_a. (fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))))), %a_CONSTANTunde_tunde_a. (\<forall> a_CONSTANTunde_munde_a \<in> (a_CONSTANTunde_Qunde_a) : ((leq ((fapply ((fapply ((a_VARIABLEunde_storeunde_a), (a_CONSTANTunde_munde_a))), ((Succ[0])))), (a_CONSTANTunde_tunde_a)))))))))"
shows "(((((a_VARIABLEunde_storeunde_hash_primea :: c)) \<in> ([({(''n1''), (''n2''), (''n3'')}) \<rightarrow> ((((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))) \<times> ({((0)), ((Succ[0]))})))]))) & ((((a_VARIABLEunde_writeTsunde_hash_primea :: c)) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & (\<forall> a_CONSTANTunde_nunde_a_1 \<in> ({(''n1''), (''n2''), (''n3'')}) : ((leq ((fapply ((fapply (((a_VARIABLEunde_storeunde_hash_primea :: c)), (a_CONSTANTunde_nunde_a_1))), ((Succ[0])))), ((a_VARIABLEunde_writeTsunde_hash_primea :: c)))))) & (\<forall> a_CONSTANTunde_nunde_a_1 \<in> ({(''n1''), (''n2''), (''n3'')}) : (((((fapply ((fapply (((a_VARIABLEunde_storeunde_hash_primea :: c)), (a_CONSTANTunde_nunde_a_1))), ((Succ[0])))) = ((0)))) \<Rightarrow> (((fapply ((fapply (((a_VARIABLEunde_storeunde_hash_primea :: c)), (a_CONSTANTunde_nunde_a_1))), ((Succ[Succ[0]])))) = ((0))))))))"(is "PROP ?ob'76")
proof -
ML_command {* writeln "*** TLAPS ENTER 76"; *}
show "PROP ?ob'76"

(* BEGIN ZENON INPUT
;; file=.tlacache/AtomicRegister.tlaps/tlapm_de3c3f.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/AtomicRegister.tlaps/tlapm_de3c3f.znn.out
;; obligation #76
$hyp "v'122" (/\ (TLA.in a_VARIABLEunde_storeunde_a
(TLA.FuncSet (TLA.set "n1" "n2" "n3") (TLA.prod (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))) (TLA.set 0 (TLA.fapply TLA.Succ 0)))))
(TLA.in a_VARIABLEunde_writeTsunde_a (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.bAll (TLA.set "n1" "n2" "n3") ((a_CONSTANTunde_nunde_a) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_nunde_a) (TLA.fapply TLA.Succ 0))
a_VARIABLEunde_writeTsunde_a)))
(TLA.bAll (TLA.set "n1" "n2" "n3") ((a_CONSTANTunde_nunde_a) (=> (= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_nunde_a) (TLA.fapply TLA.Succ 0))
0)
(= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_nunde_a) (TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0)))
0)))))
$hyp "a_CONSTANTunde_nunde_a_in" (TLA.in a_CONSTANTunde_nunde_a (TLA.set "n1" "n2" "n3"))
$hyp "a_CONSTANTunde_Qunde_a_in" (TLA.in a_CONSTANTunde_Qunde_a (TLA.SUBSET (TLA.set "n1" "n2" "n3")))
$hyp "v'125" (/\ (TLA.subseteq a_CONSTANTunde_Qunde_a
(TLA.set "n1" "n2" "n3"))
(arith.lt (a_CONSTANTunde_Cardinalityunde_a (TLA.set "n1" "n2" "n3"))
(arith.mul (a_CONSTANTunde_Cardinalityunde_a a_CONSTANTunde_Qunde_a)
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(arith.lt (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_nunde_a) (TLA.fapply TLA.Succ 0))
(TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a)))))))
$hyp "v'126" (= a_VARIABLEunde_storeunde_hash_primea
(TLA.except a_VARIABLEunde_storeunde_a a_CONSTANTunde_nunde_a (TLA.fapply a_VARIABLEunde_storeunde_a (TLA.bChoice a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
(TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a)))))))))))
$hyp "v'127" (= a_VARIABLEunde_writeTsunde_hash_primea
a_VARIABLEunde_writeTsunde_a)
$hyp "v'132" (/\ (TLA.in (TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a)))))
(TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0)))))
(TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
(TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a)))))))))
$hyp "v'133" (TLA.in (TLA.bChoice a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
(TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a))))))))
a_CONSTANTunde_Qunde_a)
$hyp "v'134" (= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a (TLA.bChoice a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
(TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a_1) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a_1) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a))))))))) (TLA.fapply TLA.Succ 0))
(TLA.bChoice (TLA.setOfAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0)))) ((a_CONSTANTunde_tunde_a) (TLA.bAll a_CONSTANTunde_Qunde_a ((a_CONSTANTunde_munde_a) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_a a_CONSTANTunde_munde_a) (TLA.fapply TLA.Succ 0))
a_CONSTANTunde_tunde_a))))))
$goal (/\ (TLA.in a_VARIABLEunde_storeunde_hash_primea
(TLA.FuncSet (TLA.set "n1" "n2" "n3") (TLA.prod (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))) (TLA.set 0 (TLA.fapply TLA.Succ 0)))))
(TLA.in a_VARIABLEunde_writeTsunde_hash_primea (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.bAll (TLA.set "n1" "n2" "n3") ((a_CONSTANTunde_nunde_a_1) (arith.le (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_hash_primea a_CONSTANTunde_nunde_a_1) (TLA.fapply TLA.Succ 0))
a_VARIABLEunde_writeTsunde_hash_primea)))
(TLA.bAll (TLA.set "n1" "n2" "n3") ((a_CONSTANTunde_nunde_a_1) (=> (= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_hash_primea a_CONSTANTunde_nunde_a_1) (TLA.fapply TLA.Succ 0))
0)
(= (TLA.fapply (TLA.fapply a_VARIABLEunde_storeunde_hash_primea a_CONSTANTunde_nunde_a_1) (TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0)))
0)))))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have z_Ha:"((a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ''n3''}, prod(isa'dotdot(0, 2), {0, 1})))&((a_VARIABLEunde_writeTsunde_a \\in isa'dotdot(0, 2))&(bAll({''n1'', ''n2'', ''n3''}, (\<lambda>a_CONSTANTunde_nunde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_nunde_a])[1]) <= a_VARIABLEunde_writeTsunde_a)))&bAll({''n1'', ''n2'', ''n3''}, (\<lambda>a_CONSTANTunde_nunde_a. ((((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_nunde_a])[1])=0)=>(((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_nunde_a])[2])=0)))))))" (is "?z_hk&?z_hx")
 using v'122 by blast
 have z_He:"(a_VARIABLEunde_storeunde_hash_primea=except(a_VARIABLEunde_storeunde_a, a_CONSTANTunde_nunde_a, (a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])))" (is "_=?z_hbo")
 using v'126 by blast
 have z_Hf:"(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a)"
 using v'127 by blast
 have z_Hc:"(a_CONSTANTunde_Qunde_a \\in SUBSET({''n1'', ''n2'', ''n3''}))" (is "?z_hc")
 using a_CONSTANTunde_Qunde_a_in by blast
 have z_Hh:"(bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))) \\in a_CONSTANTunde_Qunde_a)" (is "?z_hh")
 using v'133 by blast
 have zenon_L1_: "(~(''n3'' \\in {''n1'', ''n2'', ''n3''})) ==> FALSE" (is "?z_hch ==> FALSE")
 proof -
  assume z_Hch:"?z_hch" (is "~?z_hci")
  have z_Hcj: "(~(''n3'' \\in {''n2'', ''n3''}))" (is "~?z_hck")
  by (rule zenon_notin_addElt_1 [of "''n3''" "''n1''" "{''n2'', ''n3''}", OF z_Hch])
  have z_Hcm: "(~(''n3'' \\in {''n3''}))" (is "~?z_hcn")
  by (rule zenon_notin_addElt_1 [of "''n3''" "''n2''" "{''n3''}", OF z_Hcj])
  have z_Hcp: "(''n3''~=''n3'')" (is "?z_hq~=_")
  by (rule zenon_notin_addElt_0 [of "?z_hq" "?z_hq" "{}", OF z_Hcm])
  show FALSE
  by (rule zenon_noteq [OF z_Hcp])
 qed
 have zenon_L2_: "(~(''n2'' \\in {''n1'', ''n2'', ''n3''})) ==> FALSE" (is "?z_hcr ==> FALSE")
 proof -
  assume z_Hcr:"?z_hcr" (is "~?z_hcs")
  have z_Hct: "(~(''n2'' \\in {''n2'', ''n3''}))" (is "~?z_hcu")
  by (rule zenon_notin_addElt_1 [of "''n2''" "''n1''" "{''n2'', ''n3''}", OF z_Hcr])
  have z_Hcv: "(''n2''~=''n2'')" (is "?z_hp~=_")
  by (rule zenon_notin_addElt_0 [of "?z_hp" "?z_hp" "{''n3''}", OF z_Hct])
  show FALSE
  by (rule zenon_noteq [OF z_Hcv])
 qed
 have zenon_L3_: "(~(''n1'' \\in {''n1'', ''n2'', ''n3''})) ==> FALSE" (is "?z_hcw ==> FALSE")
 proof -
  assume z_Hcw:"?z_hcw" (is "~?z_hcx")
  have z_Hcy: "(''n1''~=''n1'')" (is "?z_ho~=_")
  by (rule zenon_notin_addElt_0 [of "?z_ho" "?z_ho" "{''n2'', ''n3''}", OF z_Hcw])
  show FALSE
  by (rule zenon_noteq [OF z_Hcy])
 qed
 have zenon_L4_: "bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> (''n1''~=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))) ==> (''n2''~=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))) ==> (''n3''~=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))) ==> FALSE" (is "?z_hcz ==> _ ==> ?z_hdd ==> ?z_hde ==> ?z_hdf ==> FALSE")
 proof -
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  assume z_Hdd:"?z_hdd" (is "?z_ho~=?z_hbq")
  assume z_Hde:"?z_hde" (is "?z_hp~=_")
  assume z_Hdf:"?z_hdf" (is "?z_hq~=_")
  have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
  by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
  show FALSE
  proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
   assume z_Hdh:"(?z_hbq=?z_ho)"
   show FALSE
   by (rule zenon_eqsym [OF z_Hdh z_Hdd])
  next
   assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
   show FALSE
   proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
    assume z_Hdj:"(?z_hbq=?z_hp)"
    show FALSE
    by (rule zenon_eqsym [OF z_Hdj z_Hde])
   next
    assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
    show FALSE
    proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
     assume z_Hdl:"(?z_hbq=?z_hq)"
     show FALSE
     by (rule zenon_eqsym [OF z_Hdl z_Hdf])
    next
     assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
     show FALSE
     by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
    qed
   qed
  qed
 qed
 have zenon_L5_: "(a_VARIABLEunde_storeunde_hash_primea=?z_hbo) ==> (~(a_VARIABLEunde_storeunde_hash_primea \\in FuncSet({''n1'', ''n2'', ''n3''}, prod(isa'dotdot(0, 2), {0, 1})))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> ?z_hk ==> FALSE" (is "?z_he ==> ?z_hdn ==> ?z_hcz ==> _ ==> _ ==> FALSE")
 proof -
  assume z_He:"?z_he"
  assume z_Hdn:"?z_hdn" (is "~?z_hdo")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  assume z_Hk:"?z_hk"
  have z_Hdp: "(~(?z_hbo \\in FuncSet({''n1'', ''n2'', ''n3''}, prod(isa'dotdot(0, 2), {0, 1}))))" (is "~?z_hdq")
  by (rule subst [where P="(\<lambda>zenon_Vhtd. (~(zenon_Vhtd \\in FuncSet({''n1'', ''n2'', ''n3''}, prod(isa'dotdot(0, 2), {0, 1})))))", OF z_He z_Hdn])
  show FALSE
  proof (rule zenon_except_notin_funcset [of "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "{''n1'', ''n2'', ''n3''}" "prod(isa'dotdot(0, 2), {0, 1})", OF z_Hdp])
   assume z_Hdv:"(~?z_hk)"
   show FALSE
   by (rule notE [OF z_Hdv z_Hk])
  next
   assume z_Hdw:"(~((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]) \\in prod(isa'dotdot(0, 2), {0, 1})))" (is "~?z_hdx")
   have z_Hdy: "(\\A zenon_Vw:((zenon_Vw \\in {''n1'', ''n2'', ''n3''})=>((a_VARIABLEunde_storeunde_a[zenon_Vw]) \\in prod(isa'dotdot(0, 2), {0, 1}))))" (is "\\A x : ?z_hee(x)")
   by (rule zenon_in_funcset_2 [of "a_VARIABLEunde_storeunde_a" "{''n1'', ''n2'', ''n3''}" "prod(isa'dotdot(0, 2), {0, 1})", OF z_Hk])
   have z_Hef: "?z_hee(''n3'')" (is "?z_hci=>?z_heg")
   by (rule zenon_all_0 [of "?z_hee" "''n3''", OF z_Hdy])
   show FALSE
   proof (rule zenon_imply [OF z_Hef])
    assume z_Hch:"(~?z_hci)"
    show FALSE
    by (rule zenon_L1_ [OF z_Hch])
   next
    assume z_Heg:"?z_heg"
    have z_Heh: "?z_hee(''n2'')" (is "?z_hcs=>?z_hei")
    by (rule zenon_all_0 [of "?z_hee" "''n2''", OF z_Hdy])
    show FALSE
    proof (rule zenon_imply [OF z_Heh])
     assume z_Hcr:"(~?z_hcs)"
     show FALSE
     by (rule zenon_L2_ [OF z_Hcr])
    next
     assume z_Hei:"?z_hei"
     have z_Hej: "?z_hee(''n1'')" (is "?z_hcx=>?z_hek")
     by (rule zenon_all_0 [of "?z_hee" "''n1''", OF z_Hdy])
     show FALSE
     proof (rule zenon_imply [OF z_Hej])
      assume z_Hcw:"(~?z_hcx)"
      show FALSE
      by (rule zenon_L3_ [OF z_Hcw])
     next
      assume z_Hek:"?z_hek"
      show FALSE
      proof (rule notE [OF z_Hdw])
       have z_Hel: "((a_VARIABLEunde_storeunde_a[''n1''])=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "?z_hem=?z_hbp")
       proof (rule zenon_nnpp [of "(?z_hem=?z_hbp)"])
        assume z_Hen:"(?z_hem~=?z_hbp)"
        show FALSE
        proof (rule zenon_noteq [of "?z_hbp"])
         have z_Heo: "(''n1''=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))))" (is "?z_ho=?z_hbq")
         proof (rule zenon_nnpp [of "(?z_ho=?z_hbq)"])
          assume z_Hdd:"(?z_ho~=?z_hbq)"
          show FALSE
          proof (rule notE [OF z_Hdw])
           have z_Hep: "((a_VARIABLEunde_storeunde_a[''n2''])=?z_hbp)" (is "?z_heq=_")
           proof (rule zenon_nnpp [of "(?z_heq=?z_hbp)"])
            assume z_Her:"(?z_heq~=?z_hbp)"
            show FALSE
            proof (rule zenon_noteq [of "?z_hbp"])
             have z_Hes: "(''n2''=?z_hbq)" (is "?z_hp=_")
             proof (rule zenon_nnpp [of "(?z_hp=?z_hbq)"])
              assume z_Hde:"(?z_hp~=?z_hbq)"
              show FALSE
              proof (rule notE [OF z_Hdw])
               have z_Het: "((a_VARIABLEunde_storeunde_a[''n3''])=?z_hbp)" (is "?z_heu=_")
               proof (rule zenon_nnpp [of "(?z_heu=?z_hbp)"])
               assume z_Hev:"(?z_heu~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Hew: "(''n3''=?z_hbq)" (is "?z_hq=_")
               proof (rule zenon_nnpp [of "(?z_hq=?z_hbq)"])
               assume z_Hdf:"(?z_hq~=?z_hbq)"
               show FALSE
               by (rule zenon_L4_ [OF z_Hcz z_Hh z_Hdd z_Hde z_Hdf])
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hew], fact z_Hev)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               qed
               have z_Hdx: "?z_hdx"
               by (rule subst [where P="(\<lambda>zenon_Vpud. (zenon_Vpud \\in prod(isa'dotdot(0, 2), {0, 1})))", OF z_Het], fact z_Heg)
               thus "?z_hdx" .
              qed
             qed
             have z_Hex: "(?z_hbp~=?z_hbp)"
             by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hes], fact z_Her)
             thus "(?z_hbp~=?z_hbp)" .
            qed
           qed
           have z_Hdx: "?z_hdx"
           by (rule subst [where P="(\<lambda>zenon_Vpud. (zenon_Vpud \\in prod(isa'dotdot(0, 2), {0, 1})))", OF z_Hep], fact z_Hei)
           thus "?z_hdx" .
          qed
         qed
         have z_Hex: "(?z_hbp~=?z_hbp)"
         by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Heo], fact z_Hen)
         thus "(?z_hbp~=?z_hbp)" .
        qed
       qed
       have z_Hdx: "?z_hdx"
       by (rule subst [where P="(\<lambda>zenon_Vpud. (zenon_Vpud \\in prod(isa'dotdot(0, 2), {0, 1})))", OF z_Hel], fact z_Hek)
       thus "?z_hdx" .
      qed
     qed
    qed
   qed
  qed
 qed
 have zenon_L6_: "(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a) ==> (~(a_VARIABLEunde_writeTsunde_hash_primea \\in isa'dotdot(0, 2))) ==> (a_VARIABLEunde_writeTsunde_a \\in isa'dotdot(0, 2)) ==> FALSE" (is "?z_hf ==> ?z_hff ==> ?z_hy ==> FALSE")
 proof -
  assume z_Hf:"?z_hf"
  assume z_Hff:"?z_hff" (is "~?z_hfg")
  assume z_Hy:"?z_hy"
  have z_Hfh: "(~?z_hy)"
  by (rule subst [where P="(\<lambda>zenon_Vftd. (~(zenon_Vftd \\in isa'dotdot(0, 2))))", OF z_Hf z_Hff])
  show FALSE
  by (rule notE [OF z_Hfh z_Hy])
 qed
 have zenon_L7_: "(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a) ==> (~(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)) ==> (((a_VARIABLEunde_storeunde_a[''n3''])[1]) <= a_VARIABLEunde_writeTsunde_a) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[1]) <= a_VARIABLEunde_writeTsunde_a) ==> ((CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))) \\in a_CONSTANTunde_Qunde_a) ==> (\\A x:((x \\in a_CONSTANTunde_Qunde_a)=>(x \\in {''n1'', ''n2'', ''n3''}))) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[1]) <= a_VARIABLEunde_writeTsunde_a) ==> FALSE" (is "?z_hf ==> ?z_hfm ==> ?z_hfp ==> ?z_hfr ==> ?z_hft ==> ?z_hgb ==> ?z_hge ==> FALSE")
 proof -
  assume z_Hf:"?z_hf"
  assume z_Hfm:"?z_hfm" (is "~?z_hfn")
  assume z_Hfp:"?z_hfp"
  assume z_Hfr:"?z_hfr"
  assume z_Hft:"?z_hft"
  assume z_Hgb:"?z_hgb" (is "\\A x : ?z_hgg(x)")
  assume z_Hge:"?z_hge"
  have z_Hgh_z_Hfm: "(~(((a_VARIABLEunde_storeunde_a[(CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)) == ?z_hfm" (is "?z_hgh == _")
  by (unfold bChoose_def)
  have z_Hgh: "?z_hgh" (is "~?z_hgi")
  by (unfold z_Hgh_z_Hfm, fact z_Hfm)
  have z_Hgl: "(~(((a_VARIABLEunde_storeunde_a[(CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= a_VARIABLEunde_writeTsunde_a))" (is "~?z_hgm")
  by (rule subst [where P="(\<lambda>zenon_Vrtd. (~(((a_VARIABLEunde_storeunde_a[(CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= zenon_Vrtd)))", OF z_Hf z_Hgh])
  show FALSE
  proof (rule notE [OF z_Hgl])
   have z_Hgr: "(((a_VARIABLEunde_storeunde_a[''n3''])[1])=((a_VARIABLEunde_storeunde_a[(CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]))" (is "?z_hfq=?z_hgj")
   proof (rule zenon_nnpp [of "(?z_hfq=?z_hgj)"])
    assume z_Hgs:"(?z_hfq~=?z_hgj)"
    show FALSE
    proof (rule zenon_noteq [of "?z_hgj"])
     have z_Hgt: "((a_VARIABLEunde_storeunde_a[''n3''])=(a_VARIABLEunde_storeunde_a[(CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "?z_heu=?z_hgk")
     proof (rule zenon_nnpp [of "(?z_heu=?z_hgk)"])
      assume z_Hgu:"(?z_heu~=?z_hgk)"
      show FALSE
      proof (rule zenon_noteq [of "?z_hgk"])
       have z_Hgv: "(''n3''=(CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))))" (is "?z_hq=?z_hfu")
       proof (rule zenon_nnpp [of "(?z_hq=?z_hfu)"])
        assume z_Hgw:"(?z_hq~=?z_hfu)"
        show FALSE
        proof (rule notE [OF z_Hgl])
         have z_Hgx: "(((a_VARIABLEunde_storeunde_a[''n2''])[1])=?z_hgj)" (is "?z_hgf=_")
         proof (rule zenon_nnpp [of "(?z_hgf=?z_hgj)"])
          assume z_Hgy:"(?z_hgf~=?z_hgj)"
          show FALSE
          proof (rule zenon_noteq [of "?z_hgj"])
           have z_Hgz: "((a_VARIABLEunde_storeunde_a[''n2''])=?z_hgk)" (is "?z_heq=_")
           proof (rule zenon_nnpp [of "(?z_heq=?z_hgk)"])
            assume z_Hha:"(?z_heq~=?z_hgk)"
            show FALSE
            proof (rule zenon_noteq [of "?z_hgk"])
             have z_Hhb: "(''n2''=?z_hfu)" (is "?z_hp=_")
             proof (rule zenon_nnpp [of "(?z_hp=?z_hfu)"])
              assume z_Hhc:"(?z_hp~=?z_hfu)"
              show FALSE
              proof (rule notE [OF z_Hgl])
               have z_Hhd: "(((a_VARIABLEunde_storeunde_a[''n1''])[1])=?z_hgj)" (is "?z_hfs=_")
               proof (rule zenon_nnpp [of "(?z_hfs=?z_hgj)"])
               assume z_Hhe:"(?z_hfs~=?z_hgj)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hgj"])
               have z_Hhf: "((a_VARIABLEunde_storeunde_a[''n1''])=?z_hgk)" (is "?z_hem=_")
               proof (rule zenon_nnpp [of "(?z_hem=?z_hgk)"])
               assume z_Hhg:"(?z_hem~=?z_hgk)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hgk"])
               have z_Hhh: "(''n1''=?z_hfu)" (is "?z_ho=_")
               proof (rule zenon_nnpp [of "(?z_ho=?z_hfu)"])
               assume z_Hhi:"(?z_ho~=?z_hfu)"
               have z_Hhj: "?z_hgg(?z_hfu)" (is "_=>?z_hhk")
               by (rule zenon_all_0 [of "?z_hgg" "?z_hfu", OF z_Hgb])
               show FALSE
               proof (rule zenon_imply [OF z_Hhj])
               assume z_Hhl:"(~?z_hft)"
               show FALSE
               by (rule notE [OF z_Hhl z_Hft])
               next
               assume z_Hhk:"?z_hhk"
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hfu" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hhk])
               assume z_Hhm:"(?z_hfu=?z_ho)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hhm z_Hhi])
               next
               assume z_Hhn:"(?z_hfu \\in {?z_hp, ?z_hq})" (is "?z_hhn")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hfu" "?z_hp" "{?z_hq}", OF z_Hhn])
               assume z_Hho:"(?z_hfu=?z_hp)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hho z_Hhc])
               next
               assume z_Hhp:"(?z_hfu \\in {?z_hq})" (is "?z_hhp")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hfu" "?z_hq" "{}", OF z_Hhp])
               assume z_Hhq:"(?z_hfu=?z_hq)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hhq z_Hgw])
               next
               assume z_Hhr:"(?z_hfu \\in {})" (is "?z_hhr")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hfu", OF z_Hhr])
               qed
               qed
               qed
               qed
               qed
               have z_Hhs: "(?z_hgk~=?z_hgk)"
               by (rule subst [where P="(\<lambda>zenon_Vuud. ((a_VARIABLEunde_storeunde_a[zenon_Vuud])~=?z_hgk))", OF z_Hhh], fact z_Hhg)
               thus "(?z_hgk~=?z_hgk)" .
               qed
               qed
               have z_Hhx: "(?z_hgj~=?z_hgj)"
               by (rule subst [where P="(\<lambda>zenon_Vvud. ((zenon_Vvud[1])~=?z_hgj))", OF z_Hhf], fact z_Hhe)
               thus "(?z_hgj~=?z_hgj)" .
               qed
               qed
               have z_Hgm: "?z_hgm"
               by (rule subst [where P="(\<lambda>zenon_Vwud. (zenon_Vwud <= a_VARIABLEunde_writeTsunde_a))", OF z_Hhd], fact z_Hfr)
               thus "?z_hgm" .
              qed
             qed
             have z_Hhs: "(?z_hgk~=?z_hgk)"
             by (rule subst [where P="(\<lambda>zenon_Vuud. ((a_VARIABLEunde_storeunde_a[zenon_Vuud])~=?z_hgk))", OF z_Hhb], fact z_Hha)
             thus "(?z_hgk~=?z_hgk)" .
            qed
           qed
           have z_Hhx: "(?z_hgj~=?z_hgj)"
           by (rule subst [where P="(\<lambda>zenon_Vvud. ((zenon_Vvud[1])~=?z_hgj))", OF z_Hgz], fact z_Hgy)
           thus "(?z_hgj~=?z_hgj)" .
          qed
         qed
         have z_Hgm: "?z_hgm"
         by (rule subst [where P="(\<lambda>zenon_Vwud. (zenon_Vwud <= a_VARIABLEunde_writeTsunde_a))", OF z_Hgx], fact z_Hge)
         thus "?z_hgm" .
        qed
       qed
       have z_Hhs: "(?z_hgk~=?z_hgk)"
       by (rule subst [where P="(\<lambda>zenon_Vuud. ((a_VARIABLEunde_storeunde_a[zenon_Vuud])~=?z_hgk))", OF z_Hgv], fact z_Hgu)
       thus "(?z_hgk~=?z_hgk)" .
      qed
     qed
     have z_Hhx: "(?z_hgj~=?z_hgj)"
     by (rule subst [where P="(\<lambda>zenon_Vvud. ((zenon_Vvud[1])~=?z_hgj))", OF z_Hgt], fact z_Hgs)
     thus "(?z_hgj~=?z_hgj)" .
    qed
   qed
   have z_Hgm: "?z_hgm"
   by (rule subst [where P="(\<lambda>zenon_Vwud. (zenon_Vwud <= a_VARIABLEunde_writeTsunde_a))", OF z_Hgr], fact z_Hfp)
   thus "?z_hgm" .
  qed
 qed
 have zenon_L8_: "(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a) ==> (~(((a_VARIABLEunde_storeunde_a[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[1]) <= a_VARIABLEunde_writeTsunde_a) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n1'') ==> FALSE" (is "?z_hf ==> ?z_hif ==> ?z_hfr ==> ?z_hip ==> FALSE")
 proof -
  assume z_Hf:"?z_hf"
  assume z_Hif:"?z_hif" (is "~?z_hig")
  assume z_Hfr:"?z_hfr"
  assume z_Hip:"?z_hip" (is "?z_hij=?z_ho")
  have z_Hiq: "(~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_a))" (is "~?z_hir")
  by (rule subst [where P="(\<lambda>zenon_Vrsd. (~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= zenon_Vrsd)))", OF z_Hf z_Hif])
  show FALSE
  proof (rule notE [OF z_Hiq])
   have z_Hiw: "(((a_VARIABLEunde_storeunde_a[?z_ho])[1])=((a_VARIABLEunde_storeunde_a[?z_hij])[1]))" (is "?z_hfs=?z_hih")
   proof (rule zenon_nnpp [of "(?z_hfs=?z_hih)"])
    assume z_Hix:"(?z_hfs~=?z_hih)"
    show FALSE
    proof (rule zenon_noteq [of "?z_hih"])
     have z_Hiy: "((a_VARIABLEunde_storeunde_a[?z_ho])=(a_VARIABLEunde_storeunde_a[?z_hij]))" (is "?z_hem=?z_hii")
     proof (rule zenon_nnpp [of "(?z_hem=?z_hii)"])
      assume z_Hiz:"(?z_hem~=?z_hii)"
      show FALSE
      proof (rule zenon_noteq [of "?z_hii"])
       have z_Hja: "(?z_ho=?z_hij)"
       by (rule sym [OF z_Hip])
       have z_Hjb: "(?z_hii~=?z_hii)"
       by (rule subst [where P="(\<lambda>zenon_Vdvd. ((a_VARIABLEunde_storeunde_a[zenon_Vdvd])~=?z_hii))", OF z_Hja], fact z_Hiz)
       thus "(?z_hii~=?z_hii)" .
      qed
     qed
     have z_Hjg: "(?z_hih~=?z_hih)"
     by (rule subst [where P="(\<lambda>zenon_Vevd. ((zenon_Vevd[1])~=?z_hih))", OF z_Hiy], fact z_Hix)
     thus "(?z_hih~=?z_hih)" .
    qed
   qed
   have z_Hir: "?z_hir"
   by (rule subst [where P="(\<lambda>zenon_Vwud. (zenon_Vwud <= a_VARIABLEunde_writeTsunde_a))", OF z_Hiw], fact z_Hfr)
   thus "?z_hir" .
  qed
 qed
 have zenon_L9_: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ''n3''}) ==> (~((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in DOMAIN(a_VARIABLEunde_storeunde_a))) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in {''n1'', ''n2'', ''n3''}) ==> FALSE" (is "?z_hjl ==> ?z_hjn ==> ?z_hjp ==> FALSE")
 proof -
  assume z_Hjl:"?z_hjl" (is "?z_hjm=?z_hn")
  assume z_Hjn:"?z_hjn" (is "~?z_hjo")
  assume z_Hjp:"?z_hjp"
  have z_Hjq: "(~?z_hjp)"
  by (rule subst [where P="(\<lambda>zenon_Vdsb. (~((CHOOSE x:(~((x \\in ?z_hn)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in zenon_Vdsb)))", OF z_Hjl z_Hjn])
  show FALSE
  by (rule notE [OF z_Hjq z_Hjp])
 qed
 have zenon_L10_: "(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a) ==> (~(((a_VARIABLEunde_storeunde_a[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[1]) <= a_VARIABLEunde_writeTsunde_a) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n2'') ==> FALSE" (is "?z_hf ==> ?z_hif ==> ?z_hge ==> ?z_hjv ==> FALSE")
 proof -
  assume z_Hf:"?z_hf"
  assume z_Hif:"?z_hif" (is "~?z_hig")
  assume z_Hge:"?z_hge"
  assume z_Hjv:"?z_hjv" (is "?z_hij=?z_hp")
  have z_Hiq: "(~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_a))" (is "~?z_hir")
  by (rule subst [where P="(\<lambda>zenon_Vrsd. (~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= zenon_Vrsd)))", OF z_Hf z_Hif])
  show FALSE
  proof (rule notE [OF z_Hiq])
   have z_Hjw: "(((a_VARIABLEunde_storeunde_a[?z_hp])[1])=((a_VARIABLEunde_storeunde_a[?z_hij])[1]))" (is "?z_hgf=?z_hih")
   proof (rule zenon_nnpp [of "(?z_hgf=?z_hih)"])
    assume z_Hjx:"(?z_hgf~=?z_hih)"
    show FALSE
    proof (rule zenon_noteq [of "?z_hih"])
     have z_Hjy: "((a_VARIABLEunde_storeunde_a[?z_hp])=(a_VARIABLEunde_storeunde_a[?z_hij]))" (is "?z_heq=?z_hii")
     proof (rule zenon_nnpp [of "(?z_heq=?z_hii)"])
      assume z_Hjz:"(?z_heq~=?z_hii)"
      show FALSE
      proof (rule zenon_noteq [of "?z_hii"])
       have z_Hka: "(?z_hp=?z_hij)"
       by (rule sym [OF z_Hjv])
       have z_Hjb: "(?z_hii~=?z_hii)"
       by (rule subst [where P="(\<lambda>zenon_Vdvd. ((a_VARIABLEunde_storeunde_a[zenon_Vdvd])~=?z_hii))", OF z_Hka], fact z_Hjz)
       thus "(?z_hii~=?z_hii)" .
      qed
     qed
     have z_Hjg: "(?z_hih~=?z_hih)"
     by (rule subst [where P="(\<lambda>zenon_Vevd. ((zenon_Vevd[1])~=?z_hih))", OF z_Hjy], fact z_Hjx)
     thus "(?z_hih~=?z_hih)" .
    qed
   qed
   have z_Hir: "?z_hir"
   by (rule subst [where P="(\<lambda>zenon_Vwud. (zenon_Vwud <= a_VARIABLEunde_writeTsunde_a))", OF z_Hjw], fact z_Hge)
   thus "?z_hir" .
  qed
 qed
 have zenon_L11_: "(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a) ==> (a_VARIABLEunde_storeunde_hash_primea=?z_hbo) ==> (~(((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)) ==> (\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_a[x])[1]) <= a_VARIABLEunde_writeTsunde_a))) ==> ?z_hk ==> ?z_hh ==> (\\A x:((x \\in a_CONSTANTunde_Qunde_a)=>(x \\in {''n1'', ''n2'', ''n3''}))) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n2'') ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in {''n1'', ''n2'', ''n3''}) ==> FALSE" (is "?z_hf ==> ?z_he ==> ?z_hkb ==> ?z_hkf ==> _ ==> _ ==> ?z_hgb ==> ?z_hjv ==> ?z_hjp ==> FALSE")
 proof -
  assume z_Hf:"?z_hf"
  assume z_He:"?z_he"
  assume z_Hkb:"?z_hkb" (is "~?z_hkc")
  assume z_Hkf:"?z_hkf" (is "\\A x : ?z_hki(x)")
  assume z_Hk:"?z_hk"
  assume z_Hh:"?z_hh"
  assume z_Hgb:"?z_hgb" (is "\\A x : ?z_hgg(x)")
  assume z_Hjv:"?z_hjv" (is "?z_hij=?z_hp")
  assume z_Hjp:"?z_hjp"
  have z_Hkj: "(~(((?z_hbo[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hkk")
  by (rule subst [where P="(\<lambda>zenon_Vnqd. (~(((zenon_Vnqd[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))", OF z_He z_Hkb])
  have z_Hkt: "?z_hki(''n3'')" (is "?z_hci=>?z_hfp")
  by (rule zenon_all_0 [of "?z_hki" "''n3''", OF z_Hkf])
  show FALSE
  proof (rule zenon_imply [OF z_Hkt])
   assume z_Hch:"(~?z_hci)"
   show FALSE
   by (rule zenon_L1_ [OF z_Hch])
  next
   assume z_Hfp:"?z_hfp"
   have z_Hku: "?z_hki(?z_hp)" (is "?z_hcs=>?z_hge")
   by (rule zenon_all_0 [of "?z_hki" "?z_hp", OF z_Hkf])
   show FALSE
   proof (rule zenon_imply [OF z_Hku])
    assume z_Hcr:"(~?z_hcs)"
    show FALSE
    by (rule zenon_L2_ [OF z_Hcr])
   next
    assume z_Hge:"?z_hge"
    have z_Hkv: "?z_hki(''n1'')" (is "?z_hcx=>?z_hfr")
    by (rule zenon_all_0 [of "?z_hki" "''n1''", OF z_Hkf])
    show FALSE
    proof (rule zenon_imply [OF z_Hkv])
     assume z_Hcw:"(~?z_hcx)"
     show FALSE
     by (rule zenon_L3_ [OF z_Hcw])
    next
     assume z_Hfr:"?z_hfr"
     have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
     by (unfold prod_def)
     have z_Hkw: "?z_hkw"
     by (unfold z_Hkw_z_Hk, fact z_Hk)
     have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
     by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
     have z_Hft_z_Hh: "((CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))) \\in a_CONSTANTunde_Qunde_a) == ?z_hh" (is "?z_hft == _")
     by (unfold bChoose_def)
     have z_Hft: "?z_hft"
     by (unfold z_Hft_z_Hh, fact z_Hh)
     show FALSE
     proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Veqb. (~((zenon_Veqb[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hij", OF z_Hkj])
      assume z_Hjo:"(?z_hij \\in ?z_hjm)" (is "?z_hjo")
      assume z_Hlf:"(a_CONSTANTunde_nunde_a=?z_hij)"
      assume z_Hfm:"(~(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hfn")
      show FALSE
      by (rule zenon_L7_ [OF z_Hf z_Hfm z_Hfp z_Hfr z_Hft z_Hgb z_Hge])
     next
      assume z_Hjo:"(?z_hij \\in ?z_hjm)" (is "?z_hjo")
      assume z_Hlg:"(a_CONSTANTunde_nunde_a~=?z_hij)"
      assume z_Hif:"(~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hig")
      show FALSE
      by (rule zenon_L10_ [OF z_Hf z_Hif z_Hge z_Hjv])
     next
      assume z_Hjn:"(~(?z_hij \\in ?z_hjm))" (is "~?z_hjo")
      show FALSE
      by (rule zenon_L9_ [OF z_Hjl z_Hjn z_Hjp])
     qed
    qed
   qed
  qed
 qed
 have zenon_L12_: "(a_VARIABLEunde_writeTsunde_hash_primea=a_VARIABLEunde_writeTsunde_a) ==> (a_VARIABLEunde_storeunde_hash_primea=?z_hbo) ==> (~(((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)) ==> (\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_a[x])[1]) <= a_VARIABLEunde_writeTsunde_a))) ==> ?z_hk ==> ?z_hh ==> (\\A x:((x \\in a_CONSTANTunde_Qunde_a)=>(x \\in {''n1'', ''n2'', ''n3''}))) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n3'') ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in {''n1'', ''n2'', ''n3''}) ==> FALSE" (is "?z_hf ==> ?z_he ==> ?z_hkb ==> ?z_hkf ==> _ ==> _ ==> ?z_hgb ==> ?z_hlh ==> ?z_hjp ==> FALSE")
 proof -
  assume z_Hf:"?z_hf"
  assume z_He:"?z_he"
  assume z_Hkb:"?z_hkb" (is "~?z_hkc")
  assume z_Hkf:"?z_hkf" (is "\\A x : ?z_hki(x)")
  assume z_Hk:"?z_hk"
  assume z_Hh:"?z_hh"
  assume z_Hgb:"?z_hgb" (is "\\A x : ?z_hgg(x)")
  assume z_Hlh:"?z_hlh" (is "?z_hij=?z_hq")
  assume z_Hjp:"?z_hjp"
  have z_Hkj: "(~(((?z_hbo[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hkk")
  by (rule subst [where P="(\<lambda>zenon_Vnqd. (~(((zenon_Vnqd[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))", OF z_He z_Hkb])
  have z_Hkt: "?z_hki(?z_hq)" (is "?z_hci=>?z_hfp")
  by (rule zenon_all_0 [of "?z_hki" "?z_hq", OF z_Hkf])
  show FALSE
  proof (rule zenon_imply [OF z_Hkt])
   assume z_Hch:"(~?z_hci)"
   show FALSE
   by (rule zenon_L1_ [OF z_Hch])
  next
   assume z_Hfp:"?z_hfp"
   have z_Hku: "?z_hki(''n2'')" (is "?z_hcs=>?z_hge")
   by (rule zenon_all_0 [of "?z_hki" "''n2''", OF z_Hkf])
   show FALSE
   proof (rule zenon_imply [OF z_Hku])
    assume z_Hcr:"(~?z_hcs)"
    show FALSE
    by (rule zenon_L2_ [OF z_Hcr])
   next
    assume z_Hge:"?z_hge"
    have z_Hkv: "?z_hki(''n1'')" (is "?z_hcx=>?z_hfr")
    by (rule zenon_all_0 [of "?z_hki" "''n1''", OF z_Hkf])
    show FALSE
    proof (rule zenon_imply [OF z_Hkv])
     assume z_Hcw:"(~?z_hcx)"
     show FALSE
     by (rule zenon_L3_ [OF z_Hcw])
    next
     assume z_Hfr:"?z_hfr"
     have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
     by (unfold prod_def)
     have z_Hkw: "?z_hkw"
     by (unfold z_Hkw_z_Hk, fact z_Hk)
     have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
     by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
     have z_Hft_z_Hh: "((CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))) \\in a_CONSTANTunde_Qunde_a) == ?z_hh" (is "?z_hft == _")
     by (unfold bChoose_def)
     have z_Hft: "?z_hft"
     by (unfold z_Hft_z_Hh, fact z_Hh)
     show FALSE
     proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Veqb. (~((zenon_Veqb[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hij", OF z_Hkj])
      assume z_Hjo:"(?z_hij \\in ?z_hjm)" (is "?z_hjo")
      assume z_Hlf:"(a_CONSTANTunde_nunde_a=?z_hij)"
      assume z_Hfm:"(~(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hfn")
      show FALSE
      by (rule zenon_L7_ [OF z_Hf z_Hfm z_Hfp z_Hfr z_Hft z_Hgb z_Hge])
     next
      assume z_Hjo:"(?z_hij \\in ?z_hjm)" (is "?z_hjo")
      assume z_Hlg:"(a_CONSTANTunde_nunde_a~=?z_hij)"
      assume z_Hif:"(~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hig")
      have z_Hiq: "(~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_a))" (is "~?z_hir")
      by (rule subst [where P="(\<lambda>zenon_Vrsd. (~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= zenon_Vrsd)))", OF z_Hf z_Hif])
      show FALSE
      proof (rule notE [OF z_Hiq])
       have z_Hli: "(((a_VARIABLEunde_storeunde_a[?z_hq])[1])=((a_VARIABLEunde_storeunde_a[?z_hij])[1]))" (is "?z_hfq=?z_hih")
       proof (rule zenon_nnpp [of "(?z_hfq=?z_hih)"])
        assume z_Hlj:"(?z_hfq~=?z_hih)"
        show FALSE
        proof (rule zenon_noteq [of "?z_hih"])
         have z_Hlk: "((a_VARIABLEunde_storeunde_a[?z_hq])=(a_VARIABLEunde_storeunde_a[?z_hij]))" (is "?z_heu=?z_hii")
         proof (rule zenon_nnpp [of "(?z_heu=?z_hii)"])
          assume z_Hll:"(?z_heu~=?z_hii)"
          show FALSE
          proof (rule zenon_noteq [of "?z_hii"])
           have z_Hlm: "(?z_hq=?z_hij)"
           by (rule sym [OF z_Hlh])
           have z_Hjb: "(?z_hii~=?z_hii)"
           by (rule subst [where P="(\<lambda>zenon_Vdvd. ((a_VARIABLEunde_storeunde_a[zenon_Vdvd])~=?z_hii))", OF z_Hlm], fact z_Hll)
           thus "(?z_hii~=?z_hii)" .
          qed
         qed
         have z_Hjg: "(?z_hih~=?z_hih)"
         by (rule subst [where P="(\<lambda>zenon_Vevd. ((zenon_Vevd[1])~=?z_hih))", OF z_Hlk], fact z_Hlj)
         thus "(?z_hih~=?z_hih)" .
        qed
       qed
       have z_Hir: "?z_hir"
       by (rule subst [where P="(\<lambda>zenon_Vwud. (zenon_Vwud <= a_VARIABLEunde_writeTsunde_a))", OF z_Hli], fact z_Hfp)
       thus "?z_hir" .
      qed
     next
      assume z_Hjn:"(~(?z_hij \\in ?z_hjm))" (is "~?z_hjo")
      show FALSE
      by (rule zenon_L9_ [OF z_Hjl z_Hjn z_Hjp])
     qed
    qed
   qed
  qed
 qed
 have zenon_L13_: "(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hln ==> ?z_hlo ==> ?z_hlp ==> ?z_hlq ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hln:"?z_hln" (is "?z_hfq~=_")
  assume z_Hlo:"?z_hlo" (is "?z_hgf~=_")
  assume z_Hlp:"?z_hlp" (is "?z_hfs~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_Hln])
   have z_Hmc: "(?z_hlr=?z_hfq)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hfq)"])
    assume z_Hmd:"(?z_hlr~=?z_hfq)"
    show FALSE
    proof (rule zenon_em [of "(?z_hfq=?z_hfq)"])
     assume z_Hme:"(?z_hfq=?z_hfq)"
     show FALSE
     proof (rule notE [OF z_Hmd])
      have z_Hmf: "(?z_hfq=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hfq=?z_hlr)"])
       assume z_Hmg:"(?z_hfq~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hmh: "((a_VARIABLEunde_storeunde_a[''n3''])=(?z_hbo[?z_hlt]))" (is "?z_heu=?z_hls")
        proof (rule zenon_nnpp [of "(?z_heu=?z_hls)"])
         assume z_Hmi:"(?z_heu~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vvha. (?z_heu~=zenon_Vvha))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hmi])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hev:"(?z_heu~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          proof (rule zenon_noteq [of "?z_hbp"])
           have z_Hew: "(''n3''=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))))" (is "?z_hq=?z_hbq")
           proof (rule zenon_nnpp [of "(?z_hq=?z_hbq)"])
            assume z_Hdf:"(?z_hq~=?z_hbq)"
            show FALSE
            proof (rule notE [OF z_Hlo])
             have z_Hmm: "(?z_hlr=?z_hgf)"
             proof (rule zenon_nnpp [of "(?z_hlr=?z_hgf)"])
              assume z_Hmn:"(?z_hlr~=?z_hgf)"
              show FALSE
              proof (rule zenon_em [of "(?z_hgf=?z_hgf)"])
               assume z_Hmo:"(?z_hgf=?z_hgf)"
               show FALSE
               proof (rule notE [OF z_Hmn])
               have z_Hmp: "(?z_hgf=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hgf=?z_hlr)"])
               assume z_Hmq:"(?z_hgf~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hmr: "((a_VARIABLEunde_storeunde_a[''n2''])=?z_hls)" (is "?z_heq=_")
               proof (rule zenon_nnpp [of "(?z_heq=?z_hls)"])
               assume z_Hms:"(?z_heq~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vmx. (?z_heq~=zenon_Vmx))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hms])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Her:"(?z_heq~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Hes: "(''n2''=?z_hbq)" (is "?z_hp=_")
               proof (rule zenon_nnpp [of "(?z_hp=?z_hbq)"])
               assume z_Hde:"(?z_hp~=?z_hbq)"
               show FALSE
               proof (rule notE [OF z_Hlp])
               have z_Hmw: "(?z_hlr=?z_hfs)"
               proof (rule zenon_nnpp [of "(?z_hlr=?z_hfs)"])
               assume z_Hmx:"(?z_hlr~=?z_hfs)"
               show FALSE
               proof (rule zenon_em [of "(?z_hfs=?z_hfs)"])
               assume z_Hmy:"(?z_hfs=?z_hfs)"
               show FALSE
               proof (rule notE [OF z_Hmx])
               have z_Hmz: "(?z_hfs=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hfs=?z_hlr)"])
               assume z_Hna:"(?z_hfs~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hnb: "((a_VARIABLEunde_storeunde_a[''n1''])=?z_hls)" (is "?z_hem=_")
               proof (rule zenon_nnpp [of "(?z_hem=?z_hls)"])
               assume z_Hnc:"(?z_hem~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vgs. (?z_hem~=zenon_Vgs))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hnc])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hen:"(?z_hem~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Heo: "(''n1''=?z_hbq)" (is "?z_ho=_")
               proof (rule zenon_nnpp [of "(?z_ho=?z_hbq)"])
               assume z_Hdd:"(?z_ho~=?z_hbq)"
               show FALSE
               by (rule zenon_L4_ [OF z_Hcz z_Hh z_Hdd z_Hde z_Hdf])
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Heo], fact z_Hen)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnh:"(?z_hem~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hnb], fact z_Hna)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmw: "(?z_hlr=?z_hfs)"
               by (rule subst [where P="(\<lambda>zenon_Vovd. (zenon_Vovd=?z_hfs))", OF z_Hmz], fact z_Hmy)
               thus "(?z_hlr=?z_hfs)" .
               qed
               next
               assume z_Hns:"(?z_hfs~=?z_hfs)"
               show FALSE
               by (rule zenon_noteq [OF z_Hns])
               qed
               qed
               have z_Hnt: "(?z_hfs=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmw], fact z_Hlq)
               thus "(?z_hfs=0)" .
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hes], fact z_Her)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnx:"(?z_heq~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmr], fact z_Hmq)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmm: "(?z_hlr=?z_hgf)"
               by (rule subst [where P="(\<lambda>zenon_Vsvd. (zenon_Vsvd=?z_hgf))", OF z_Hmp], fact z_Hmo)
               thus "(?z_hlr=?z_hgf)" .
               qed
              next
               assume z_Hob:"(?z_hgf~=?z_hgf)"
               show FALSE
               by (rule zenon_noteq [OF z_Hob])
              qed
             qed
             have z_Hoc: "(?z_hgf=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmm], fact z_Hlq)
             thus "(?z_hgf=0)" .
            qed
           qed
           have z_Hex: "(?z_hbp~=?z_hbp)"
           by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hew], fact z_Hev)
           thus "(?z_hbp~=?z_hbp)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hod:"(?z_heu~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmh], fact z_Hmg)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmc: "(?z_hlr=?z_hfq)"
      by (rule subst [where P="(\<lambda>zenon_Vwvd. (zenon_Vwvd=?z_hfq))", OF z_Hmf], fact z_Hme)
      thus "(?z_hlr=?z_hfq)" .
     qed
    next
     assume z_Hoh:"(?z_hfq~=?z_hfq)"
     show FALSE
     by (rule zenon_noteq [OF z_Hoh])
    qed
   qed
   have z_Hoi: "(?z_hfq=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmc], fact z_Hlq)
   thus "(?z_hfq=0)" .
  qed
 qed
 have zenon_L14_: "((a_VARIABLEunde_storeunde_a[''n1''])~=(a_VARIABLEunde_storeunde_a[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n1'') ==> FALSE" (is "?z_hnh ==> ?z_hoj ==> FALSE")
 proof -
  assume z_Hnh:"?z_hnh" (is "?z_hem~=?z_hni")
  assume z_Hoj:"?z_hoj" (is "?z_hlt=?z_ho")
  show FALSE
  proof (rule zenon_noteq [of "?z_hni"])
   have z_Hok: "(?z_ho=?z_hlt)"
   by (rule sym [OF z_Hoj])
   have z_Hol: "(?z_hni~=?z_hni)"
   by (rule subst [where P="(\<lambda>zenon_Vyvd. ((a_VARIABLEunde_storeunde_a[zenon_Vyvd])~=?z_hni))", OF z_Hok], fact z_Hnh)
   thus "(?z_hni~=?z_hni)" .
  qed
 qed
 have zenon_L15_: "(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n1'') ==> (a_CONSTANTunde_nunde_a~=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> FALSE" (is "?z_hlp ==> ?z_hlq ==> ?z_hma ==> ?z_hoj ==> ?z_hng ==> FALSE")
 proof -
  assume z_Hlp:"?z_hlp" (is "?z_hfs~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Hoj:"?z_hoj" (is "?z_hlt=?z_ho")
  assume z_Hng:"?z_hng"
  show FALSE
  proof (rule notE [OF z_Hlp])
   have z_Hmw: "(?z_hlr=?z_hfs)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hfs)"])
    assume z_Hmx:"(?z_hlr~=?z_hfs)"
    show FALSE
    proof (rule zenon_em [of "(?z_hfs=?z_hfs)"])
     assume z_Hmy:"(?z_hfs=?z_hfs)"
     show FALSE
     proof (rule notE [OF z_Hmx])
      have z_Hmz: "(?z_hfs=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hfs=?z_hlr)"])
       assume z_Hna:"(?z_hfs~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hnb: "((a_VARIABLEunde_storeunde_a[?z_ho])=(?z_hbo[?z_hlt]))" (is "?z_hem=?z_hls")
        proof (rule zenon_nnpp [of "(?z_hem=?z_hls)"])
         assume z_Hnc:"(?z_hem~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vgs. (?z_hem~=zenon_Vgs))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hnc])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
          assume z_Hen:"(?z_hem~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"?z_hng"
          assume z_Hnh:"(?z_hem~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          by (rule zenon_L14_ [OF z_Hnh z_Hoj])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hnb], fact z_Hna)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmw: "(?z_hlr=?z_hfs)"
      by (rule subst [where P="(\<lambda>zenon_Vovd. (zenon_Vovd=?z_hfs))", OF z_Hmz], fact z_Hmy)
      thus "(?z_hlr=?z_hfs)" .
     qed
    next
     assume z_Hns:"(?z_hfs~=?z_hfs)"
     show FALSE
     by (rule zenon_noteq [OF z_Hns])
    qed
   qed
   have z_Hnt: "(?z_hfs=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmw], fact z_Hlq)
   thus "(?z_hfs=0)" .
  qed
 qed
 have zenon_L16_: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ''n3''}) ==> (~((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a))) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in {''n1'', ''n2'', ''n3''}) ==> FALSE" (is "?z_hjl ==> ?z_hnj ==> ?z_hoq ==> FALSE")
 proof -
  assume z_Hjl:"?z_hjl" (is "?z_hjm=?z_hn")
  assume z_Hnj:"?z_hnj" (is "~?z_hma")
  assume z_Hoq:"?z_hoq"
  have z_Hor: "(~?z_hoq)"
  by (rule subst [where P="(\<lambda>zenon_Vwc. (~((CHOOSE x:(~((x \\in ?z_hn)=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in zenon_Vwc)))", OF z_Hjl z_Hnj])
  show FALSE
  by (rule notE [OF z_Hor z_Hoq])
 qed
 have zenon_L17_: "(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hln ==> ?z_hlo ==> ?z_hlq ==> ?z_how ==> ?z_hoy ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hln:"?z_hln" (is "?z_hfq~=_")
  assume z_Hlo:"?z_hlo" (is "?z_hgf~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_Hln])
   have z_Hmc: "(?z_hlr=?z_hfq)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hfq)"])
    assume z_Hmd:"(?z_hlr~=?z_hfq)"
    show FALSE
    proof (rule zenon_em [of "(?z_hfq=?z_hfq)"])
     assume z_Hme:"(?z_hfq=?z_hfq)"
     show FALSE
     proof (rule notE [OF z_Hmd])
      have z_Hmf: "(?z_hfq=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hfq=?z_hlr)"])
       assume z_Hmg:"(?z_hfq~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hmh: "((a_VARIABLEunde_storeunde_a[''n3''])=(?z_hbo[?z_hlt]))" (is "?z_heu=?z_hls")
        proof (rule zenon_nnpp [of "(?z_heu=?z_hls)"])
         assume z_Hmi:"(?z_heu~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vvha. (?z_heu~=zenon_Vvha))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hmi])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hev:"(?z_heu~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          proof (rule zenon_noteq [of "?z_hbp"])
           have z_Hew: "(''n3''=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))))" (is "?z_hq=?z_hbq")
           proof (rule zenon_nnpp [of "(?z_hq=?z_hbq)"])
            assume z_Hdf:"(?z_hq~=?z_hbq)"
            show FALSE
            proof (rule notE [OF z_Hlo])
             have z_Hmm: "(?z_hlr=?z_hgf)"
             proof (rule zenon_nnpp [of "(?z_hlr=?z_hgf)"])
              assume z_Hmn:"(?z_hlr~=?z_hgf)"
              show FALSE
              proof (rule zenon_em [of "(?z_hgf=?z_hgf)"])
               assume z_Hmo:"(?z_hgf=?z_hgf)"
               show FALSE
               proof (rule notE [OF z_Hmn])
               have z_Hmp: "(?z_hgf=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hgf=?z_hlr)"])
               assume z_Hmq:"(?z_hgf~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hmr: "((a_VARIABLEunde_storeunde_a[''n2''])=?z_hls)" (is "?z_heq=_")
               proof (rule zenon_nnpp [of "(?z_heq=?z_hls)"])
               assume z_Hms:"(?z_heq~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vmx. (?z_heq~=zenon_Vmx))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hms])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Her:"(?z_heq~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Hes: "(''n2''=?z_hbq)" (is "?z_hp=_")
               proof (rule zenon_nnpp [of "(?z_hp=?z_hbq)"])
               assume z_Hde:"(?z_hp~=?z_hbq)"
               show FALSE
               proof (rule notE [OF z_How])
               have z_Hpa: "(?z_hoz=?z_hox)"
               proof (rule zenon_nnpp [of "(?z_hoz=?z_hox)"])
               assume z_Hpb:"(?z_hoz~=?z_hox)"
               show FALSE
               proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hpb])
               have z_Hpd: "(?z_hox=?z_hoz)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hoz)"])
               assume z_Hpe:"(?z_hox~=?z_hoz)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hoz"])
               have z_Hpf: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n1'']))" (is "_=?z_hem")
               proof (rule zenon_nnpp [of "(?z_hls=?z_hem)"])
               assume z_Hpg:"(?z_hls~=?z_hem)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vum. (zenon_Vum~=?z_hem))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hpg])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hpk:"(?z_hbp~=?z_hem)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hem"])
               have z_Hdh: "(?z_hbq=''n1'')" (is "_=?z_ho")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_ho)"])
               assume z_Hpl:"(?z_hbq~=?z_ho)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule notE [OF z_Hpl z_Hdh])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdj z_Hde])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdl z_Hdf])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hpm: "(?z_hem~=?z_hem)"
               by (rule subst [where P="(\<lambda>zenon_Vcwd. ((a_VARIABLEunde_storeunde_a[zenon_Vcwd])~=?z_hem))", OF z_Hdh], fact z_Hpk)
               thus "(?z_hem~=?z_hem)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hpr:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_hem)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hps: "(?z_hoz~=?z_hoz)"
               by (rule subst [where P="(\<lambda>zenon_Vxx. ((zenon_Vxx[2])~=?z_hoz))", OF z_Hpf], fact z_Hpe)
               thus "(?z_hoz~=?z_hoz)" .
               qed
               qed
               have z_Hpa: "(?z_hoz=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hpd], fact z_Hpc)
               thus "(?z_hoz=?z_hox)" .
               qed
               next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
               qed
               qed
               have z_Hqb: "(?z_hox=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hpa], fact z_Hoy)
               thus "(?z_hox=0)" .
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hes], fact z_Her)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnx:"(?z_heq~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmr], fact z_Hmq)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmm: "(?z_hlr=?z_hgf)"
               by (rule subst [where P="(\<lambda>zenon_Vsvd. (zenon_Vsvd=?z_hgf))", OF z_Hmp], fact z_Hmo)
               thus "(?z_hlr=?z_hgf)" .
               qed
              next
               assume z_Hob:"(?z_hgf~=?z_hgf)"
               show FALSE
               by (rule zenon_noteq [OF z_Hob])
              qed
             qed
             have z_Hoc: "(?z_hgf=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmm], fact z_Hlq)
             thus "(?z_hgf=0)" .
            qed
           qed
           have z_Hex: "(?z_hbp~=?z_hbp)"
           by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hew], fact z_Hev)
           thus "(?z_hbp~=?z_hbp)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hod:"(?z_heu~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmh], fact z_Hmg)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmc: "(?z_hlr=?z_hfq)"
      by (rule subst [where P="(\<lambda>zenon_Vwvd. (zenon_Vwvd=?z_hfq))", OF z_Hmf], fact z_Hme)
      thus "(?z_hlr=?z_hfq)" .
     qed
    next
     assume z_Hoh:"(?z_hfq~=?z_hfq)"
     show FALSE
     by (rule zenon_noteq [OF z_Hoh])
    qed
   qed
   have z_Hoi: "(?z_hfq=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmc], fact z_Hlq)
   thus "(?z_hfq=0)" .
  qed
 qed
 have zenon_L18_: "((a_VARIABLEunde_storeunde_a[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])~=(a_VARIABLEunde_storeunde_a[''n1''])) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n1'') ==> FALSE" (is "?z_hpr ==> ?z_hoj ==> FALSE")
 proof -
  assume z_Hpr:"?z_hpr" (is "?z_hni~=?z_hem")
  assume z_Hoj:"?z_hoj" (is "?z_hlt=?z_ho")
  show FALSE
  proof (rule zenon_noteq [of "?z_hem"])
   have z_Hpm: "(?z_hem~=?z_hem)"
   by (rule subst [where P="(\<lambda>zenon_Vcwd. ((a_VARIABLEunde_storeunde_a[zenon_Vcwd])~=?z_hem))", OF z_Hoj], fact z_Hpr)
   thus "(?z_hem~=?z_hem)" .
  qed
 qed
 have zenon_L19_: "(((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n1'') ==> (a_CONSTANTunde_nunde_a~=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> FALSE" (is "?z_how ==> ?z_hoy ==> ?z_hma ==> ?z_hoj ==> ?z_hng ==> FALSE")
 proof -
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
  assume z_Hma:"?z_hma"
  assume z_Hoj:"?z_hoj" (is "?z_hlt=?z_ho")
  assume z_Hng:"?z_hng"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hpa: "(?z_hoz=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hoz=?z_hox)"])
    assume z_Hpb:"(?z_hoz~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hpb])
      have z_Hpd: "(?z_hox=?z_hoz)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hoz)"])
       assume z_Hpe:"(?z_hox~=?z_hoz)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hoz"])
        have z_Hpf: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[?z_ho]))" (is "?z_hls=?z_hem")
        proof (rule zenon_nnpp [of "(?z_hls=?z_hem)"])
         assume z_Hpg:"(?z_hls~=?z_hem)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vum. (zenon_Vum~=?z_hem))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hpg])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
          assume z_Hpk:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_hem)" (is "?z_hbp~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"?z_hng"
          assume z_Hpr:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_hem)" (is "?z_hni~=_")
          show FALSE
          by (rule zenon_L18_ [OF z_Hpr z_Hoj])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hps: "(?z_hoz~=?z_hoz)"
        by (rule subst [where P="(\<lambda>zenon_Vxx. ((zenon_Vxx[2])~=?z_hoz))", OF z_Hpf], fact z_Hpe)
        thus "(?z_hoz~=?z_hoz)" .
       qed
      qed
      have z_Hpa: "(?z_hoz=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hpd], fact z_Hpc)
      thus "(?z_hoz=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hpa], fact z_Hoy)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L20_: "(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[2])=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hln ==> ?z_how ==> ?z_hqc ==> ?z_hlp ==> ?z_hlq ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hln:"?z_hln" (is "?z_hfq~=_")
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
  assume z_Hlp:"?z_hlp" (is "?z_hfs~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_Hln])
   have z_Hmc: "(?z_hlr=?z_hfq)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hfq)"])
    assume z_Hmd:"(?z_hlr~=?z_hfq)"
    show FALSE
    proof (rule zenon_em [of "(?z_hfq=?z_hfq)"])
     assume z_Hme:"(?z_hfq=?z_hfq)"
     show FALSE
     proof (rule notE [OF z_Hmd])
      have z_Hmf: "(?z_hfq=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hfq=?z_hlr)"])
       assume z_Hmg:"(?z_hfq~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hmh: "((a_VARIABLEunde_storeunde_a[''n3''])=(?z_hbo[?z_hlt]))" (is "?z_heu=?z_hls")
        proof (rule zenon_nnpp [of "(?z_heu=?z_hls)"])
         assume z_Hmi:"(?z_heu~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vvha. (?z_heu~=zenon_Vvha))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hmi])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hev:"(?z_heu~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          proof (rule zenon_noteq [of "?z_hbp"])
           have z_Hew: "(''n3''=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))))" (is "?z_hq=?z_hbq")
           proof (rule zenon_nnpp [of "(?z_hq=?z_hbq)"])
            assume z_Hdf:"(?z_hq~=?z_hbq)"
            show FALSE
            proof (rule notE [OF z_How])
             have z_Hqe: "(?z_hqd=?z_hox)"
             proof (rule zenon_nnpp [of "(?z_hqd=?z_hox)"])
              assume z_Hqf:"(?z_hqd~=?z_hox)"
              show FALSE
              proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hqf])
               have z_Hqg: "(?z_hox=?z_hqd)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hqd)"])
               assume z_Hqh:"(?z_hox~=?z_hqd)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hqd"])
               have z_Hqi: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n2'']))" (is "_=?z_heq")
               proof (rule zenon_nnpp [of "(?z_hls=?z_heq)"])
               assume z_Hqj:"(?z_hls~=?z_heq)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vzf. (zenon_Vzf~=?z_heq))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hqj])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hqn:"(?z_hbp~=?z_heq)"
               show FALSE
               proof (rule zenon_noteq [of "?z_heq"])
               have z_Hdj: "(?z_hbq=''n2'')" (is "_=?z_hp")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_hp)"])
               assume z_Hqo:"(?z_hbq~=?z_hp)"
               show FALSE
               proof (rule notE [OF z_Hlp])
               have z_Hmw: "(?z_hlr=?z_hfs)"
               proof (rule zenon_nnpp [of "(?z_hlr=?z_hfs)"])
               assume z_Hmx:"(?z_hlr~=?z_hfs)"
               show FALSE
               proof (rule zenon_em [of "(?z_hfs=?z_hfs)"])
               assume z_Hmy:"(?z_hfs=?z_hfs)"
               show FALSE
               proof (rule notE [OF z_Hmx])
               have z_Hmz: "(?z_hfs=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hfs=?z_hlr)"])
               assume z_Hna:"(?z_hfs~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hnb: "((a_VARIABLEunde_storeunde_a[''n1''])=?z_hls)" (is "?z_hem=_")
               proof (rule zenon_nnpp [of "(?z_hem=?z_hls)"])
               assume z_Hnc:"(?z_hem~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vgs. (?z_hem~=zenon_Vgs))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hnc])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hen:"(?z_hem~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Heo: "(''n1''=?z_hbq)" (is "?z_ho=_")
               proof (rule zenon_nnpp [of "(?z_ho=?z_hbq)"])
               assume z_Hdd:"(?z_ho~=?z_hbq)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdh z_Hdd])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule notE [OF z_Hqo z_Hdj])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdl z_Hdf])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Heo], fact z_Hen)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnh:"(?z_hem~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hnb], fact z_Hna)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmw: "(?z_hlr=?z_hfs)"
               by (rule subst [where P="(\<lambda>zenon_Vovd. (zenon_Vovd=?z_hfs))", OF z_Hmz], fact z_Hmy)
               thus "(?z_hlr=?z_hfs)" .
               qed
               next
               assume z_Hns:"(?z_hfs~=?z_hfs)"
               show FALSE
               by (rule zenon_noteq [OF z_Hns])
               qed
               qed
               have z_Hnt: "(?z_hfs=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmw], fact z_Hlq)
               thus "(?z_hfs=0)" .
               qed
               qed
               have z_Hqp: "(?z_heq~=?z_heq)"
               by (rule subst [where P="(\<lambda>zenon_Vwwd. ((a_VARIABLEunde_storeunde_a[zenon_Vwwd])~=?z_heq))", OF z_Hdj], fact z_Hqn)
               thus "(?z_heq~=?z_heq)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hqu:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heq)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hqv: "(?z_hqd~=?z_hqd)"
               by (rule subst [where P="(\<lambda>zenon_Vyf. ((zenon_Vyf[2])~=?z_hqd))", OF z_Hqi], fact z_Hqh)
               thus "(?z_hqd~=?z_hqd)" .
               qed
               qed
               have z_Hqe: "(?z_hqd=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hqg], fact z_Hpc)
               thus "(?z_hqd=?z_hox)" .
               qed
              next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
              qed
             qed
             have z_Hqb: "(?z_hox=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hqe], fact z_Hqc)
             thus "(?z_hox=0)" .
            qed
           qed
           have z_Hex: "(?z_hbp~=?z_hbp)"
           by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hew], fact z_Hev)
           thus "(?z_hbp~=?z_hbp)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hod:"(?z_heu~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmh], fact z_Hmg)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmc: "(?z_hlr=?z_hfq)"
      by (rule subst [where P="(\<lambda>zenon_Vwvd. (zenon_Vwvd=?z_hfq))", OF z_Hmf], fact z_Hme)
      thus "(?z_hlr=?z_hfq)" .
     qed
    next
     assume z_Hoh:"(?z_hfq~=?z_hfq)"
     show FALSE
     by (rule zenon_noteq [OF z_Hoh])
    qed
   qed
   have z_Hoi: "(?z_hfq=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmc], fact z_Hlq)
   thus "(?z_hfq=0)" .
  qed
 qed
 have zenon_L21_: "(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[2])=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hln ==> ?z_hlq ==> ?z_hqc ==> ?z_how ==> ?z_hoy ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hln:"?z_hln" (is "?z_hfq~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_Hln])
   have z_Hmc: "(?z_hlr=?z_hfq)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hfq)"])
    assume z_Hmd:"(?z_hlr~=?z_hfq)"
    show FALSE
    proof (rule zenon_em [of "(?z_hfq=?z_hfq)"])
     assume z_Hme:"(?z_hfq=?z_hfq)"
     show FALSE
     proof (rule notE [OF z_Hmd])
      have z_Hmf: "(?z_hfq=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hfq=?z_hlr)"])
       assume z_Hmg:"(?z_hfq~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hmh: "((a_VARIABLEunde_storeunde_a[''n3''])=(?z_hbo[?z_hlt]))" (is "?z_heu=?z_hls")
        proof (rule zenon_nnpp [of "(?z_heu=?z_hls)"])
         assume z_Hmi:"(?z_heu~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vvha. (?z_heu~=zenon_Vvha))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hmi])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hev:"(?z_heu~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          proof (rule zenon_noteq [of "?z_hbp"])
           have z_Hew: "(''n3''=bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))))" (is "?z_hq=?z_hbq")
           proof (rule zenon_nnpp [of "(?z_hq=?z_hbq)"])
            assume z_Hdf:"(?z_hq~=?z_hbq)"
            show FALSE
            proof (rule notE [OF z_How])
             have z_Hqe: "(?z_hqd=?z_hox)"
             proof (rule zenon_nnpp [of "(?z_hqd=?z_hox)"])
              assume z_Hqf:"(?z_hqd~=?z_hox)"
              show FALSE
              proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hqf])
               have z_Hqg: "(?z_hox=?z_hqd)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hqd)"])
               assume z_Hqh:"(?z_hox~=?z_hqd)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hqd"])
               have z_Hqi: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n2'']))" (is "_=?z_heq")
               proof (rule zenon_nnpp [of "(?z_hls=?z_heq)"])
               assume z_Hqj:"(?z_hls~=?z_heq)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vzf. (zenon_Vzf~=?z_heq))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hqj])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hqn:"(?z_hbp~=?z_heq)"
               show FALSE
               proof (rule zenon_noteq [of "?z_heq"])
               have z_Hdj: "(?z_hbq=''n2'')" (is "_=?z_hp")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_hp)"])
               assume z_Hqo:"(?z_hbq~=?z_hp)"
               show FALSE
               proof (rule notE [OF z_How])
               have z_Hpa: "(?z_hoz=?z_hox)"
               proof (rule zenon_nnpp [of "(?z_hoz=?z_hox)"])
               assume z_Hpb:"(?z_hoz~=?z_hox)"
               show FALSE
               proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hpb])
               have z_Hpd: "(?z_hox=?z_hoz)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hoz)"])
               assume z_Hpe:"(?z_hox~=?z_hoz)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hoz"])
               have z_Hpf: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n1'']))" (is "_=?z_hem")
               proof (rule zenon_nnpp [of "(?z_hls=?z_hem)"])
               assume z_Hpg:"(?z_hls~=?z_hem)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vum. (zenon_Vum~=?z_hem))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hpg])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hpk:"(?z_hbp~=?z_hem)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hem"])
               have z_Hdh: "(?z_hbq=''n1'')" (is "_=?z_ho")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_ho)"])
               assume z_Hpl:"(?z_hbq~=?z_ho)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule notE [OF z_Hpl z_Hdh])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule notE [OF z_Hqo z_Hdj])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdl z_Hdf])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hpm: "(?z_hem~=?z_hem)"
               by (rule subst [where P="(\<lambda>zenon_Vcwd. ((a_VARIABLEunde_storeunde_a[zenon_Vcwd])~=?z_hem))", OF z_Hdh], fact z_Hpk)
               thus "(?z_hem~=?z_hem)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hpr:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_hem)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hps: "(?z_hoz~=?z_hoz)"
               by (rule subst [where P="(\<lambda>zenon_Vxx. ((zenon_Vxx[2])~=?z_hoz))", OF z_Hpf], fact z_Hpe)
               thus "(?z_hoz~=?z_hoz)" .
               qed
               qed
               have z_Hpa: "(?z_hoz=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hpd], fact z_Hpc)
               thus "(?z_hoz=?z_hox)" .
               qed
               next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
               qed
               qed
               have z_Hqb: "(?z_hox=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hpa], fact z_Hoy)
               thus "(?z_hox=0)" .
               qed
               qed
               have z_Hqp: "(?z_heq~=?z_heq)"
               by (rule subst [where P="(\<lambda>zenon_Vwwd. ((a_VARIABLEunde_storeunde_a[zenon_Vwwd])~=?z_heq))", OF z_Hdj], fact z_Hqn)
               thus "(?z_heq~=?z_heq)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hqu:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heq)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hqv: "(?z_hqd~=?z_hqd)"
               by (rule subst [where P="(\<lambda>zenon_Vyf. ((zenon_Vyf[2])~=?z_hqd))", OF z_Hqi], fact z_Hqh)
               thus "(?z_hqd~=?z_hqd)" .
               qed
               qed
               have z_Hqe: "(?z_hqd=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hqg], fact z_Hpc)
               thus "(?z_hqd=?z_hox)" .
               qed
              next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
              qed
             qed
             have z_Hqb: "(?z_hox=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hqe], fact z_Hqc)
             thus "(?z_hox=0)" .
            qed
           qed
           have z_Hex: "(?z_hbp~=?z_hbp)"
           by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hew], fact z_Hev)
           thus "(?z_hbp~=?z_hbp)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hod:"(?z_heu~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmh], fact z_Hmg)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmc: "(?z_hlr=?z_hfq)"
      by (rule subst [where P="(\<lambda>zenon_Vwvd. (zenon_Vwvd=?z_hfq))", OF z_Hmf], fact z_Hme)
      thus "(?z_hlr=?z_hfq)" .
     qed
    next
     assume z_Hoh:"(?z_hfq~=?z_hfq)"
     show FALSE
     by (rule zenon_noteq [OF z_Hoh])
    qed
   qed
   have z_Hoi: "(?z_hfq=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmc], fact z_Hlq)
   thus "(?z_hfq=0)" .
  qed
 qed
 have zenon_L22_: "(((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n3''])[2])=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_how ==> ?z_hra ==> ?z_hlo ==> ?z_hlp ==> ?z_hlq ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hra:"?z_hra" (is "?z_hrb=_")
  assume z_Hlo:"?z_hlo" (is "?z_hgf~=_")
  assume z_Hlp:"?z_hlp" (is "?z_hfs~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hrc: "(?z_hrb=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hrb=?z_hox)"])
    assume z_Hrd:"(?z_hrb~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hrd])
      have z_Hre: "(?z_hox=?z_hrb)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hrb)"])
       assume z_Hrf:"(?z_hox~=?z_hrb)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hrb"])
        have z_Hrg: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[''n3'']))" (is "?z_hls=?z_heu")
        proof (rule zenon_nnpp [of "(?z_hls=?z_heu)"])
         assume z_Hrh:"(?z_hls~=?z_heu)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vyd. (zenon_Vyd~=?z_heu))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hrh])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hrl:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_heu)" (is "?z_hbp~=_")
          show FALSE
          proof (rule zenon_noteq [of "?z_heu"])
           have z_Hdl: "(bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))=''n3'')" (is "?z_hbq=?z_hq")
           proof (rule zenon_nnpp [of "(?z_hbq=?z_hq)"])
            assume z_Hrm:"(?z_hbq~=?z_hq)"
            show FALSE
            proof (rule notE [OF z_Hlo])
             have z_Hmm: "(?z_hlr=?z_hgf)"
             proof (rule zenon_nnpp [of "(?z_hlr=?z_hgf)"])
              assume z_Hmn:"(?z_hlr~=?z_hgf)"
              show FALSE
              proof (rule zenon_em [of "(?z_hgf=?z_hgf)"])
               assume z_Hmo:"(?z_hgf=?z_hgf)"
               show FALSE
               proof (rule notE [OF z_Hmn])
               have z_Hmp: "(?z_hgf=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hgf=?z_hlr)"])
               assume z_Hmq:"(?z_hgf~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hmr: "((a_VARIABLEunde_storeunde_a[''n2''])=?z_hls)" (is "?z_heq=_")
               proof (rule zenon_nnpp [of "(?z_heq=?z_hls)"])
               assume z_Hms:"(?z_heq~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vmx. (?z_heq~=zenon_Vmx))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hms])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Her:"(?z_heq~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Hes: "(''n2''=?z_hbq)" (is "?z_hp=_")
               proof (rule zenon_nnpp [of "(?z_hp=?z_hbq)"])
               assume z_Hde:"(?z_hp~=?z_hbq)"
               show FALSE
               proof (rule notE [OF z_Hlp])
               have z_Hmw: "(?z_hlr=?z_hfs)"
               proof (rule zenon_nnpp [of "(?z_hlr=?z_hfs)"])
               assume z_Hmx:"(?z_hlr~=?z_hfs)"
               show FALSE
               proof (rule zenon_em [of "(?z_hfs=?z_hfs)"])
               assume z_Hmy:"(?z_hfs=?z_hfs)"
               show FALSE
               proof (rule notE [OF z_Hmx])
               have z_Hmz: "(?z_hfs=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hfs=?z_hlr)"])
               assume z_Hna:"(?z_hfs~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hnb: "((a_VARIABLEunde_storeunde_a[''n1''])=?z_hls)" (is "?z_hem=_")
               proof (rule zenon_nnpp [of "(?z_hem=?z_hls)"])
               assume z_Hnc:"(?z_hem~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vgs. (?z_hem~=zenon_Vgs))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hnc])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hen:"(?z_hem~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Heo: "(''n1''=?z_hbq)" (is "?z_ho=_")
               proof (rule zenon_nnpp [of "(?z_ho=?z_hbq)"])
               assume z_Hdd:"(?z_ho~=?z_hbq)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdh z_Hdd])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdj z_Hde])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule notE [OF z_Hrm z_Hdl])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Heo], fact z_Hen)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnh:"(?z_hem~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hnb], fact z_Hna)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmw: "(?z_hlr=?z_hfs)"
               by (rule subst [where P="(\<lambda>zenon_Vovd. (zenon_Vovd=?z_hfs))", OF z_Hmz], fact z_Hmy)
               thus "(?z_hlr=?z_hfs)" .
               qed
               next
               assume z_Hns:"(?z_hfs~=?z_hfs)"
               show FALSE
               by (rule zenon_noteq [OF z_Hns])
               qed
               qed
               have z_Hnt: "(?z_hfs=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmw], fact z_Hlq)
               thus "(?z_hfs=0)" .
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hes], fact z_Her)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnx:"(?z_heq~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmr], fact z_Hmq)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmm: "(?z_hlr=?z_hgf)"
               by (rule subst [where P="(\<lambda>zenon_Vsvd. (zenon_Vsvd=?z_hgf))", OF z_Hmp], fact z_Hmo)
               thus "(?z_hlr=?z_hgf)" .
               qed
              next
               assume z_Hob:"(?z_hgf~=?z_hgf)"
               show FALSE
               by (rule zenon_noteq [OF z_Hob])
              qed
             qed
             have z_Hoc: "(?z_hgf=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmm], fact z_Hlq)
             thus "(?z_hgf=0)" .
            qed
           qed
           have z_Hrn: "(?z_heu~=?z_heu)"
           by (rule subst [where P="(\<lambda>zenon_Vyxd. ((a_VARIABLEunde_storeunde_a[zenon_Vyxd])~=?z_heu))", OF z_Hdl], fact z_Hrl)
           thus "(?z_heu~=?z_heu)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hrs:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heu)" (is "?z_hni~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hrt: "(?z_hrb~=?z_hrb)"
        by (rule subst [where P="(\<lambda>zenon_Vxd. ((zenon_Vxd[2])~=?z_hrb))", OF z_Hrg], fact z_Hrf)
        thus "(?z_hrb~=?z_hrb)" .
       qed
      qed
      have z_Hrc: "(?z_hrb=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hre], fact z_Hpc)
      thus "(?z_hrb=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hrc], fact z_Hra)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L23_: "(((a_VARIABLEunde_storeunde_a[''n3''])[2])=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hra ==> ?z_hlo ==> ?z_hlq ==> ?z_how ==> ?z_hoy ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hra:"?z_hra" (is "?z_hrb=_")
  assume z_Hlo:"?z_hlo" (is "?z_hgf~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hrc: "(?z_hrb=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hrb=?z_hox)"])
    assume z_Hrd:"(?z_hrb~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hrd])
      have z_Hre: "(?z_hox=?z_hrb)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hrb)"])
       assume z_Hrf:"(?z_hox~=?z_hrb)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hrb"])
        have z_Hrg: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[''n3'']))" (is "?z_hls=?z_heu")
        proof (rule zenon_nnpp [of "(?z_hls=?z_heu)"])
         assume z_Hrh:"(?z_hls~=?z_heu)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vyd. (zenon_Vyd~=?z_heu))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hrh])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hrl:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_heu)" (is "?z_hbp~=_")
          show FALSE
          proof (rule zenon_noteq [of "?z_heu"])
           have z_Hdl: "(bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))=''n3'')" (is "?z_hbq=?z_hq")
           proof (rule zenon_nnpp [of "(?z_hbq=?z_hq)"])
            assume z_Hrm:"(?z_hbq~=?z_hq)"
            show FALSE
            proof (rule notE [OF z_Hlo])
             have z_Hmm: "(?z_hlr=?z_hgf)"
             proof (rule zenon_nnpp [of "(?z_hlr=?z_hgf)"])
              assume z_Hmn:"(?z_hlr~=?z_hgf)"
              show FALSE
              proof (rule zenon_em [of "(?z_hgf=?z_hgf)"])
               assume z_Hmo:"(?z_hgf=?z_hgf)"
               show FALSE
               proof (rule notE [OF z_Hmn])
               have z_Hmp: "(?z_hgf=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hgf=?z_hlr)"])
               assume z_Hmq:"(?z_hgf~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hmr: "((a_VARIABLEunde_storeunde_a[''n2''])=?z_hls)" (is "?z_heq=_")
               proof (rule zenon_nnpp [of "(?z_heq=?z_hls)"])
               assume z_Hms:"(?z_heq~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vmx. (?z_heq~=zenon_Vmx))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hms])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Her:"(?z_heq~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Hes: "(''n2''=?z_hbq)" (is "?z_hp=_")
               proof (rule zenon_nnpp [of "(?z_hp=?z_hbq)"])
               assume z_Hde:"(?z_hp~=?z_hbq)"
               show FALSE
               proof (rule notE [OF z_How])
               have z_Hpa: "(?z_hoz=?z_hox)"
               proof (rule zenon_nnpp [of "(?z_hoz=?z_hox)"])
               assume z_Hpb:"(?z_hoz~=?z_hox)"
               show FALSE
               proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hpb])
               have z_Hpd: "(?z_hox=?z_hoz)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hoz)"])
               assume z_Hpe:"(?z_hox~=?z_hoz)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hoz"])
               have z_Hpf: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n1'']))" (is "_=?z_hem")
               proof (rule zenon_nnpp [of "(?z_hls=?z_hem)"])
               assume z_Hpg:"(?z_hls~=?z_hem)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vum. (zenon_Vum~=?z_hem))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hpg])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hpk:"(?z_hbp~=?z_hem)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hem"])
               have z_Hdh: "(?z_hbq=''n1'')" (is "_=?z_ho")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_ho)"])
               assume z_Hpl:"(?z_hbq~=?z_ho)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule notE [OF z_Hpl z_Hdh])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdj z_Hde])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule notE [OF z_Hrm z_Hdl])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hpm: "(?z_hem~=?z_hem)"
               by (rule subst [where P="(\<lambda>zenon_Vcwd. ((a_VARIABLEunde_storeunde_a[zenon_Vcwd])~=?z_hem))", OF z_Hdh], fact z_Hpk)
               thus "(?z_hem~=?z_hem)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hpr:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_hem)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hps: "(?z_hoz~=?z_hoz)"
               by (rule subst [where P="(\<lambda>zenon_Vxx. ((zenon_Vxx[2])~=?z_hoz))", OF z_Hpf], fact z_Hpe)
               thus "(?z_hoz~=?z_hoz)" .
               qed
               qed
               have z_Hpa: "(?z_hoz=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hpd], fact z_Hpc)
               thus "(?z_hoz=?z_hox)" .
               qed
               next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
               qed
               qed
               have z_Hqb: "(?z_hox=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hpa], fact z_Hoy)
               thus "(?z_hox=0)" .
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Hes], fact z_Her)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnx:"(?z_heq~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmr], fact z_Hmq)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmm: "(?z_hlr=?z_hgf)"
               by (rule subst [where P="(\<lambda>zenon_Vsvd. (zenon_Vsvd=?z_hgf))", OF z_Hmp], fact z_Hmo)
               thus "(?z_hlr=?z_hgf)" .
               qed
              next
               assume z_Hob:"(?z_hgf~=?z_hgf)"
               show FALSE
               by (rule zenon_noteq [OF z_Hob])
              qed
             qed
             have z_Hoc: "(?z_hgf=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmm], fact z_Hlq)
             thus "(?z_hgf=0)" .
            qed
           qed
           have z_Hrn: "(?z_heu~=?z_heu)"
           by (rule subst [where P="(\<lambda>zenon_Vyxd. ((a_VARIABLEunde_storeunde_a[zenon_Vyxd])~=?z_heu))", OF z_Hdl], fact z_Hrl)
           thus "(?z_heu~=?z_heu)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hrs:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heu)" (is "?z_hni~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hrt: "(?z_hrb~=?z_hrb)"
        by (rule subst [where P="(\<lambda>zenon_Vxd. ((zenon_Vxd[2])~=?z_hrb))", OF z_Hrg], fact z_Hrf)
        thus "(?z_hrb~=?z_hrb)" .
       qed
      qed
      have z_Hrc: "(?z_hrb=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hre], fact z_Hpc)
      thus "(?z_hrb=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hrc], fact z_Hra)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L24_: "(((a_VARIABLEunde_storeunde_a[''n3''])[2])=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[2])=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hra ==> ?z_how ==> ?z_hqc ==> ?z_hlp ==> ?z_hlq ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hra:"?z_hra" (is "?z_hrb=_")
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
  assume z_Hlp:"?z_hlp" (is "?z_hfs~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hrc: "(?z_hrb=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hrb=?z_hox)"])
    assume z_Hrd:"(?z_hrb~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hrd])
      have z_Hre: "(?z_hox=?z_hrb)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hrb)"])
       assume z_Hrf:"(?z_hox~=?z_hrb)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hrb"])
        have z_Hrg: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[''n3'']))" (is "?z_hls=?z_heu")
        proof (rule zenon_nnpp [of "(?z_hls=?z_heu)"])
         assume z_Hrh:"(?z_hls~=?z_heu)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vyd. (zenon_Vyd~=?z_heu))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hrh])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hrl:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_heu)" (is "?z_hbp~=_")
          show FALSE
          proof (rule zenon_noteq [of "?z_heu"])
           have z_Hdl: "(bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))=''n3'')" (is "?z_hbq=?z_hq")
           proof (rule zenon_nnpp [of "(?z_hbq=?z_hq)"])
            assume z_Hrm:"(?z_hbq~=?z_hq)"
            show FALSE
            proof (rule notE [OF z_How])
             have z_Hqe: "(?z_hqd=?z_hox)"
             proof (rule zenon_nnpp [of "(?z_hqd=?z_hox)"])
              assume z_Hqf:"(?z_hqd~=?z_hox)"
              show FALSE
              proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hqf])
               have z_Hqg: "(?z_hox=?z_hqd)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hqd)"])
               assume z_Hqh:"(?z_hox~=?z_hqd)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hqd"])
               have z_Hqi: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n2'']))" (is "_=?z_heq")
               proof (rule zenon_nnpp [of "(?z_hls=?z_heq)"])
               assume z_Hqj:"(?z_hls~=?z_heq)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vzf. (zenon_Vzf~=?z_heq))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hqj])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hqn:"(?z_hbp~=?z_heq)"
               show FALSE
               proof (rule zenon_noteq [of "?z_heq"])
               have z_Hdj: "(?z_hbq=''n2'')" (is "_=?z_hp")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_hp)"])
               assume z_Hqo:"(?z_hbq~=?z_hp)"
               show FALSE
               proof (rule notE [OF z_Hlp])
               have z_Hmw: "(?z_hlr=?z_hfs)"
               proof (rule zenon_nnpp [of "(?z_hlr=?z_hfs)"])
               assume z_Hmx:"(?z_hlr~=?z_hfs)"
               show FALSE
               proof (rule zenon_em [of "(?z_hfs=?z_hfs)"])
               assume z_Hmy:"(?z_hfs=?z_hfs)"
               show FALSE
               proof (rule notE [OF z_Hmx])
               have z_Hmz: "(?z_hfs=?z_hlr)"
               proof (rule zenon_nnpp [of "(?z_hfs=?z_hlr)"])
               assume z_Hna:"(?z_hfs~=?z_hlr)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hlr"])
               have z_Hnb: "((a_VARIABLEunde_storeunde_a[''n1''])=?z_hls)" (is "?z_hem=_")
               proof (rule zenon_nnpp [of "(?z_hem=?z_hls)"])
               assume z_Hnc:"(?z_hem~=?z_hls)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vgs. (?z_hem~=zenon_Vgs))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hnc])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hen:"(?z_hem~=?z_hbp)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hbp"])
               have z_Heo: "(''n1''=?z_hbq)" (is "?z_ho=_")
               proof (rule zenon_nnpp [of "(?z_ho=?z_hbq)"])
               assume z_Hdd:"(?z_ho~=?z_hbq)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule zenon_eqsym [OF z_Hdh z_Hdd])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule notE [OF z_Hqo z_Hdj])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule notE [OF z_Hrm z_Hdl])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hex: "(?z_hbp~=?z_hbp)"
               by (rule subst [where P="(\<lambda>zenon_Voud. ((a_VARIABLEunde_storeunde_a[zenon_Voud])~=?z_hbp))", OF z_Heo], fact z_Hen)
               thus "(?z_hbp~=?z_hbp)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hnh:"(?z_hem~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hnk: "(?z_hlr~=?z_hlr)"
               by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hnb], fact z_Hna)
               thus "(?z_hlr~=?z_hlr)" .
               qed
               qed
               have z_Hmw: "(?z_hlr=?z_hfs)"
               by (rule subst [where P="(\<lambda>zenon_Vovd. (zenon_Vovd=?z_hfs))", OF z_Hmz], fact z_Hmy)
               thus "(?z_hlr=?z_hfs)" .
               qed
               next
               assume z_Hns:"(?z_hfs~=?z_hfs)"
               show FALSE
               by (rule zenon_noteq [OF z_Hns])
               qed
               qed
               have z_Hnt: "(?z_hfs=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmw], fact z_Hlq)
               thus "(?z_hfs=0)" .
               qed
               qed
               have z_Hqp: "(?z_heq~=?z_heq)"
               by (rule subst [where P="(\<lambda>zenon_Vwwd. ((a_VARIABLEunde_storeunde_a[zenon_Vwwd])~=?z_heq))", OF z_Hdj], fact z_Hqn)
               thus "(?z_heq~=?z_heq)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hqu:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heq)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hqv: "(?z_hqd~=?z_hqd)"
               by (rule subst [where P="(\<lambda>zenon_Vyf. ((zenon_Vyf[2])~=?z_hqd))", OF z_Hqi], fact z_Hqh)
               thus "(?z_hqd~=?z_hqd)" .
               qed
               qed
               have z_Hqe: "(?z_hqd=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hqg], fact z_Hpc)
               thus "(?z_hqd=?z_hox)" .
               qed
              next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
              qed
             qed
             have z_Hqb: "(?z_hox=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hqe], fact z_Hqc)
             thus "(?z_hox=0)" .
            qed
           qed
           have z_Hrn: "(?z_heu~=?z_heu)"
           by (rule subst [where P="(\<lambda>zenon_Vyxd. ((a_VARIABLEunde_storeunde_a[zenon_Vyxd])~=?z_heu))", OF z_Hdl], fact z_Hrl)
           thus "(?z_heu~=?z_heu)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hrs:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heu)" (is "?z_hni~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hrt: "(?z_hrb~=?z_hrb)"
        by (rule subst [where P="(\<lambda>zenon_Vxd. ((zenon_Vxd[2])~=?z_hrb))", OF z_Hrg], fact z_Hrf)
        thus "(?z_hrb~=?z_hrb)" .
       qed
      qed
      have z_Hrc: "(?z_hrb=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hre], fact z_Hpc)
      thus "(?z_hrb=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hrc], fact z_Hra)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L25_: "(((a_VARIABLEunde_storeunde_a[''n3''])[2])=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[2])=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n1''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> (a_CONSTANTunde_nunde_a=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> FALSE" (is "?z_hra ==> ?z_hqc ==> ?z_how ==> ?z_hoy ==> ?z_hma ==> ?z_hmb ==> ?z_hcz ==> _ ==> FALSE")
 proof -
  assume z_Hra:"?z_hra" (is "?z_hrb=_")
  assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
  assume z_Hma:"?z_hma"
  assume z_Hmb:"?z_hmb" (is "_=?z_hlt")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hrc: "(?z_hrb=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hrb=?z_hox)"])
    assume z_Hrd:"(?z_hrb~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hrd])
      have z_Hre: "(?z_hox=?z_hrb)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hrb)"])
       assume z_Hrf:"(?z_hox~=?z_hrb)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hrb"])
        have z_Hrg: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[''n3'']))" (is "?z_hls=?z_heu")
        proof (rule zenon_nnpp [of "(?z_hls=?z_heu)"])
         assume z_Hrh:"(?z_hls~=?z_heu)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vyd. (zenon_Vyd~=?z_heu))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hrh])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"?z_hmb"
          assume z_Hrl:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_heu)" (is "?z_hbp~=_")
          show FALSE
          proof (rule zenon_noteq [of "?z_heu"])
           have z_Hdl: "(bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))=''n3'')" (is "?z_hbq=?z_hq")
           proof (rule zenon_nnpp [of "(?z_hbq=?z_hq)"])
            assume z_Hrm:"(?z_hbq~=?z_hq)"
            show FALSE
            proof (rule notE [OF z_How])
             have z_Hqe: "(?z_hqd=?z_hox)"
             proof (rule zenon_nnpp [of "(?z_hqd=?z_hox)"])
              assume z_Hqf:"(?z_hqd~=?z_hox)"
              show FALSE
              proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hqf])
               have z_Hqg: "(?z_hox=?z_hqd)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hqd)"])
               assume z_Hqh:"(?z_hox~=?z_hqd)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hqd"])
               have z_Hqi: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n2'']))" (is "_=?z_heq")
               proof (rule zenon_nnpp [of "(?z_hls=?z_heq)"])
               assume z_Hqj:"(?z_hls~=?z_heq)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vzf. (zenon_Vzf~=?z_heq))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hqj])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hqn:"(?z_hbp~=?z_heq)"
               show FALSE
               proof (rule zenon_noteq [of "?z_heq"])
               have z_Hdj: "(?z_hbq=''n2'')" (is "_=?z_hp")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_hp)"])
               assume z_Hqo:"(?z_hbq~=?z_hp)"
               show FALSE
               proof (rule notE [OF z_How])
               have z_Hpa: "(?z_hoz=?z_hox)"
               proof (rule zenon_nnpp [of "(?z_hoz=?z_hox)"])
               assume z_Hpb:"(?z_hoz~=?z_hox)"
               show FALSE
               proof (rule zenon_em [of "(?z_hox=?z_hox)"])
               assume z_Hpc:"(?z_hox=?z_hox)"
               show FALSE
               proof (rule notE [OF z_Hpb])
               have z_Hpd: "(?z_hox=?z_hoz)"
               proof (rule zenon_nnpp [of "(?z_hox=?z_hoz)"])
               assume z_Hpe:"(?z_hox~=?z_hoz)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hoz"])
               have z_Hpf: "(?z_hls=(a_VARIABLEunde_storeunde_a[''n1'']))" (is "_=?z_hem")
               proof (rule zenon_nnpp [of "(?z_hls=?z_hem)"])
               assume z_Hpg:"(?z_hls~=?z_hem)"
               show FALSE
               proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vum. (zenon_Vum~=?z_hem))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "?z_hbp" "?z_hlt", OF z_Hpg])
               assume z_Hma:"?z_hma"
               assume z_Hmb:"?z_hmb"
               assume z_Hpk:"(?z_hbp~=?z_hem)"
               show FALSE
               proof (rule zenon_noteq [of "?z_hem"])
               have z_Hdh: "(?z_hbq=''n1'')" (is "_=?z_ho")
               proof (rule zenon_nnpp [of "(?z_hbq=?z_ho)"])
               assume z_Hpl:"(?z_hbq~=?z_ho)"
               have z_Hdg: "(?z_hbq \\in {?z_ho, ?z_hp, ?z_hq})" (is "?z_hdg")
               by (rule zenon_all_in_0 [of "a_CONSTANTunde_Qunde_a" "(\<lambda>zenon_Vn. (zenon_Vn \\in {?z_ho, ?z_hp, ?z_hq}))", OF z_Hcz z_Hh])
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_ho" "{?z_hp, ?z_hq}", OF z_Hdg])
               assume z_Hdh:"(?z_hbq=?z_ho)"
               show FALSE
               by (rule notE [OF z_Hpl z_Hdh])
               next
               assume z_Hdi:"(?z_hbq \\in {?z_hp, ?z_hq})" (is "?z_hdi")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hp" "{?z_hq}", OF z_Hdi])
               assume z_Hdj:"(?z_hbq=?z_hp)"
               show FALSE
               by (rule notE [OF z_Hqo z_Hdj])
               next
               assume z_Hdk:"(?z_hbq \\in {?z_hq})" (is "?z_hdk")
               show FALSE
               proof (rule zenon_in_addElt [of "?z_hbq" "?z_hq" "{}", OF z_Hdk])
               assume z_Hdl:"(?z_hbq=?z_hq)"
               show FALSE
               by (rule notE [OF z_Hrm z_Hdl])
               next
               assume z_Hdm:"(?z_hbq \\in {})" (is "?z_hdm")
               show FALSE
               by (rule zenon_in_emptyset [of "?z_hbq", OF z_Hdm])
               qed
               qed
               qed
               qed
               have z_Hpm: "(?z_hem~=?z_hem)"
               by (rule subst [where P="(\<lambda>zenon_Vcwd. ((a_VARIABLEunde_storeunde_a[zenon_Vcwd])~=?z_hem))", OF z_Hdh], fact z_Hpk)
               thus "(?z_hem~=?z_hem)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hpr:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_hem)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hps: "(?z_hoz~=?z_hoz)"
               by (rule subst [where P="(\<lambda>zenon_Vxx. ((zenon_Vxx[2])~=?z_hoz))", OF z_Hpf], fact z_Hpe)
               thus "(?z_hoz~=?z_hoz)" .
               qed
               qed
               have z_Hpa: "(?z_hoz=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hpd], fact z_Hpc)
               thus "(?z_hoz=?z_hox)" .
               qed
               next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
               qed
               qed
               have z_Hqb: "(?z_hox=0)"
               by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hpa], fact z_Hoy)
               thus "(?z_hox=0)" .
               qed
               qed
               have z_Hqp: "(?z_heq~=?z_heq)"
               by (rule subst [where P="(\<lambda>zenon_Vwwd. ((a_VARIABLEunde_storeunde_a[zenon_Vwwd])~=?z_heq))", OF z_Hdj], fact z_Hqn)
               thus "(?z_heq~=?z_heq)" .
               qed
               next
               assume z_Hma:"?z_hma"
               assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
               assume z_Hqu:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heq)" (is "?z_hni~=_")
               show FALSE
               by (rule notE [OF z_Hng z_Hmb])
               next
               assume z_Hnj:"(~?z_hma)"
               show FALSE
               by (rule notE [OF z_Hnj z_Hma])
               qed
               qed
               have z_Hqv: "(?z_hqd~=?z_hqd)"
               by (rule subst [where P="(\<lambda>zenon_Vyf. ((zenon_Vyf[2])~=?z_hqd))", OF z_Hqi], fact z_Hqh)
               thus "(?z_hqd~=?z_hqd)" .
               qed
               qed
               have z_Hqe: "(?z_hqd=?z_hox)"
               by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hqg], fact z_Hpc)
               thus "(?z_hqd=?z_hox)" .
               qed
              next
               assume z_Hqa:"(?z_hox~=?z_hox)"
               show FALSE
               by (rule zenon_noteq [OF z_Hqa])
              qed
             qed
             have z_Hqb: "(?z_hox=0)"
             by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hqe], fact z_Hqc)
             thus "(?z_hox=0)" .
            qed
           qed
           have z_Hrn: "(?z_heu~=?z_heu)"
           by (rule subst [where P="(\<lambda>zenon_Vyxd. ((a_VARIABLEunde_storeunde_a[zenon_Vyxd])~=?z_heu))", OF z_Hdl], fact z_Hrl)
           thus "(?z_heu~=?z_heu)" .
          qed
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
          assume z_Hrs:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heu)" (is "?z_hni~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hrt: "(?z_hrb~=?z_hrb)"
        by (rule subst [where P="(\<lambda>zenon_Vxd. ((zenon_Vxd[2])~=?z_hrb))", OF z_Hrg], fact z_Hrf)
        thus "(?z_hrb~=?z_hrb)" .
       qed
      qed
      have z_Hrc: "(?z_hrb=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hre], fact z_Hpc)
      thus "(?z_hrb=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hrc], fact z_Hra)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L26_: "((a_VARIABLEunde_storeunde_a[''n2''])~=(a_VARIABLEunde_storeunde_a[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n2'') ==> FALSE" (is "?z_hnx ==> ?z_hry ==> FALSE")
 proof -
  assume z_Hnx:"?z_hnx" (is "?z_heq~=?z_hni")
  assume z_Hry:"?z_hry" (is "?z_hlt=?z_hp")
  show FALSE
  proof (rule zenon_noteq [of "?z_hni"])
   have z_Hrz: "(?z_hp=?z_hlt)"
   by (rule sym [OF z_Hry])
   have z_Hol: "(?z_hni~=?z_hni)"
   by (rule subst [where P="(\<lambda>zenon_Vyvd. ((a_VARIABLEunde_storeunde_a[zenon_Vyvd])~=?z_hni))", OF z_Hrz], fact z_Hnx)
   thus "(?z_hni~=?z_hni)" .
  qed
 qed
 have zenon_L27_: "(((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n2'') ==> (a_CONSTANTunde_nunde_a~=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> FALSE" (is "?z_hlo ==> ?z_hlq ==> ?z_hma ==> ?z_hry ==> ?z_hng ==> FALSE")
 proof -
  assume z_Hlo:"?z_hlo" (is "?z_hgf~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Hry:"?z_hry" (is "?z_hlt=?z_hp")
  assume z_Hng:"?z_hng"
  show FALSE
  proof (rule notE [OF z_Hlo])
   have z_Hmm: "(?z_hlr=?z_hgf)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hgf)"])
    assume z_Hmn:"(?z_hlr~=?z_hgf)"
    show FALSE
    proof (rule zenon_em [of "(?z_hgf=?z_hgf)"])
     assume z_Hmo:"(?z_hgf=?z_hgf)"
     show FALSE
     proof (rule notE [OF z_Hmn])
      have z_Hmp: "(?z_hgf=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hgf=?z_hlr)"])
       assume z_Hmq:"(?z_hgf~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hmr: "((a_VARIABLEunde_storeunde_a[?z_hp])=(?z_hbo[?z_hlt]))" (is "?z_heq=?z_hls")
        proof (rule zenon_nnpp [of "(?z_heq=?z_hls)"])
         assume z_Hms:"(?z_heq~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vmx. (?z_heq~=zenon_Vmx))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hms])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
          assume z_Her:"(?z_heq~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"?z_hng"
          assume z_Hnx:"(?z_heq~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          by (rule zenon_L26_ [OF z_Hnx z_Hry])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmr], fact z_Hmq)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmm: "(?z_hlr=?z_hgf)"
      by (rule subst [where P="(\<lambda>zenon_Vsvd. (zenon_Vsvd=?z_hgf))", OF z_Hmp], fact z_Hmo)
      thus "(?z_hlr=?z_hgf)" .
     qed
    next
     assume z_Hob:"(?z_hgf~=?z_hgf)"
     show FALSE
     by (rule zenon_noteq [OF z_Hob])
    qed
   qed
   have z_Hoc: "(?z_hgf=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmm], fact z_Hlq)
   thus "(?z_hgf=0)" .
  qed
 qed
 have zenon_L28_: "((a_VARIABLEunde_storeunde_a[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])~=(a_VARIABLEunde_storeunde_a[''n2''])) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n2'') ==> FALSE" (is "?z_hqu ==> ?z_hry ==> FALSE")
 proof -
  assume z_Hqu:"?z_hqu" (is "?z_hni~=?z_heq")
  assume z_Hry:"?z_hry" (is "?z_hlt=?z_hp")
  show FALSE
  proof (rule zenon_noteq [of "?z_heq"])
   have z_Hqp: "(?z_heq~=?z_heq)"
   by (rule subst [where P="(\<lambda>zenon_Vwwd. ((a_VARIABLEunde_storeunde_a[zenon_Vwwd])~=?z_heq))", OF z_Hry], fact z_Hqu)
   thus "(?z_heq~=?z_heq)" .
  qed
 qed
 have zenon_L29_: "(((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n2''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n2'') ==> (a_CONSTANTunde_nunde_a~=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> FALSE" (is "?z_how ==> ?z_hqc ==> ?z_hma ==> ?z_hry ==> ?z_hng ==> FALSE")
 proof -
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
  assume z_Hma:"?z_hma"
  assume z_Hry:"?z_hry" (is "?z_hlt=?z_hp")
  assume z_Hng:"?z_hng"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hqe: "(?z_hqd=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hqd=?z_hox)"])
    assume z_Hqf:"(?z_hqd~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hqf])
      have z_Hqg: "(?z_hox=?z_hqd)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hqd)"])
       assume z_Hqh:"(?z_hox~=?z_hqd)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hqd"])
        have z_Hqi: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[?z_hp]))" (is "?z_hls=?z_heq")
        proof (rule zenon_nnpp [of "(?z_hls=?z_heq)"])
         assume z_Hqj:"(?z_hls~=?z_heq)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vzf. (zenon_Vzf~=?z_heq))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hqj])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
          assume z_Hqn:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_heq)" (is "?z_hbp~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"?z_hng"
          assume z_Hqu:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heq)" (is "?z_hni~=_")
          show FALSE
          by (rule zenon_L28_ [OF z_Hqu z_Hry])
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hqv: "(?z_hqd~=?z_hqd)"
        by (rule subst [where P="(\<lambda>zenon_Vyf. ((zenon_Vyf[2])~=?z_hqd))", OF z_Hqi], fact z_Hqh)
        thus "(?z_hqd~=?z_hqd)" .
       qed
      qed
      have z_Hqe: "(?z_hqd=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hqg], fact z_Hpc)
      thus "(?z_hqd=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hqe], fact z_Hqc)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L30_: "(a_VARIABLEunde_storeunde_hash_primea=?z_hbo) ==> (((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> (((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n2'') ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in {''n1'', ''n2'', ''n3''}) ==> ?z_hk ==> (\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_a[x])[1])=0)=>(((a_VARIABLEunde_storeunde_a[x])[2])=0)))) ==> FALSE" (is "?z_he ==> ?z_hsa ==> ?z_hsd ==> ?z_hcz ==> _ ==> ?z_hry ==> ?z_hoq ==> _ ==> ?z_hsf ==> FALSE")
 proof -
  assume z_He:"?z_he"
  assume z_Hsa:"?z_hsa" (is "?z_hsb=_")
  assume z_Hsd:"?z_hsd" (is "?z_hse~=_")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  assume z_Hry:"?z_hry" (is "?z_hlt=?z_hp")
  assume z_Hoq:"?z_hoq"
  assume z_Hk:"?z_hk"
  assume z_Hsf:"?z_hsf" (is "\\A x : ?z_hsl(x)")
  have z_Hlq: "(((?z_hbo[?z_hlt])[1])=0)" (is "?z_hlr=_")
  by (rule subst [where P="(\<lambda>zenon_Vdud. (((zenon_Vdud[?z_hlt])[1])=0))", OF z_He z_Hsa])
  have z_How: "(((?z_hbo[?z_hlt])[2])~=0)" (is "?z_hox~=_")
  by (rule subst [where P="(\<lambda>zenon_Vnjd. (((zenon_Vnjd[?z_hlt])[2])~=0))", OF z_He z_Hsd])
  have z_Hsw: "?z_hsl(''n3'')" (is "?z_hci=>?z_hsx")
  by (rule zenon_all_0 [of "?z_hsl" "''n3''", OF z_Hsf])
  show FALSE
  proof (rule zenon_imply [OF z_Hsw])
   assume z_Hch:"(~?z_hci)"
   show FALSE
   by (rule zenon_L1_ [OF z_Hch])
  next
   assume z_Hsx:"?z_hsx" (is "?z_hoi=>?z_hra")
   show FALSE
   proof (rule zenon_imply [OF z_Hsx])
    assume z_Hln:"(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0)" (is "?z_hfq~=_")
    have z_Hsy: "?z_hsl(?z_hp)" (is "?z_hcs=>?z_hsz")
    by (rule zenon_all_0 [of "?z_hsl" "?z_hp", OF z_Hsf])
    show FALSE
    proof (rule zenon_imply [OF z_Hsy])
     assume z_Hcr:"(~?z_hcs)"
     show FALSE
     by (rule zenon_L2_ [OF z_Hcr])
    next
     assume z_Hsz:"?z_hsz" (is "?z_hoc=>?z_hqc")
     show FALSE
     proof (rule zenon_imply [OF z_Hsz])
      assume z_Hlo:"(((a_VARIABLEunde_storeunde_a[?z_hp])[1])~=0)" (is "?z_hgf~=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L13_ [OF z_Hln z_Hlo z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L27_ [OF z_Hlo z_Hlq z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L17_ [OF z_Hln z_Hlo z_Hlq z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L27_ [OF z_Hlo z_Hlq z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     next
      assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L20_ [OF z_Hln z_How z_Hqc z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L29_ [OF z_How z_Hqc z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L21_ [OF z_Hln z_Hlq z_Hqc z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L29_ [OF z_How z_Hqc z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     qed
    qed
   next
    assume z_Hra:"?z_hra" (is "?z_hrb=_")
    have z_Hsy: "?z_hsl(?z_hp)" (is "?z_hcs=>?z_hsz")
    by (rule zenon_all_0 [of "?z_hsl" "?z_hp", OF z_Hsf])
    show FALSE
    proof (rule zenon_imply [OF z_Hsy])
     assume z_Hcr:"(~?z_hcs)"
     show FALSE
     by (rule zenon_L2_ [OF z_Hcr])
    next
     assume z_Hsz:"?z_hsz" (is "?z_hoc=>?z_hqc")
     show FALSE
     proof (rule zenon_imply [OF z_Hsz])
      assume z_Hlo:"(((a_VARIABLEunde_storeunde_a[?z_hp])[1])~=0)" (is "?z_hgf~=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L22_ [OF z_How z_Hra z_Hlo z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L27_ [OF z_Hlo z_Hlq z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L23_ [OF z_Hra z_Hlo z_Hlq z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L27_ [OF z_Hlo z_Hlq z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     next
      assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L24_ [OF z_Hra z_How z_Hqc z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L29_ [OF z_How z_Hqc z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ?z_hp, ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ?z_hp, ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L25_ [OF z_Hra z_Hqc z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L29_ [OF z_How z_Hqc z_Hma z_Hry z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     qed
    qed
   qed
  qed
 qed
 have zenon_L31_: "(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0) ==> (((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n3'') ==> (a_CONSTANTunde_nunde_a~=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> FALSE" (is "?z_hln ==> ?z_hlq ==> ?z_hma ==> ?z_htk ==> ?z_hng ==> FALSE")
 proof -
  assume z_Hln:"?z_hln" (is "?z_hfq~=_")
  assume z_Hlq:"?z_hlq" (is "?z_hlr=_")
  assume z_Hma:"?z_hma"
  assume z_Htk:"?z_htk" (is "?z_hlt=?z_hq")
  assume z_Hng:"?z_hng"
  show FALSE
  proof (rule notE [OF z_Hln])
   have z_Hmc: "(?z_hlr=?z_hfq)"
   proof (rule zenon_nnpp [of "(?z_hlr=?z_hfq)"])
    assume z_Hmd:"(?z_hlr~=?z_hfq)"
    show FALSE
    proof (rule zenon_em [of "(?z_hfq=?z_hfq)"])
     assume z_Hme:"(?z_hfq=?z_hfq)"
     show FALSE
     proof (rule notE [OF z_Hmd])
      have z_Hmf: "(?z_hfq=?z_hlr)"
      proof (rule zenon_nnpp [of "(?z_hfq=?z_hlr)"])
       assume z_Hmg:"(?z_hfq~=?z_hlr)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hlr"])
        have z_Hmh: "((a_VARIABLEunde_storeunde_a[?z_hq])=(?z_hbo[?z_hlt]))" (is "?z_heu=?z_hls")
        proof (rule zenon_nnpp [of "(?z_heu=?z_hls)"])
         assume z_Hmi:"(?z_heu~=?z_hls)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vvha. (?z_heu~=zenon_Vvha))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hmi])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
          assume z_Hev:"(?z_heu~=(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))]))" (is "_~=?z_hbp")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"?z_hng"
          assume z_Hod:"(?z_heu~=(a_VARIABLEunde_storeunde_a[?z_hlt]))" (is "_~=?z_hni")
          show FALSE
          proof (rule zenon_noteq [of "?z_hni"])
           have z_Htl: "(?z_hq=?z_hlt)"
           by (rule sym [OF z_Htk])
           have z_Hol: "(?z_hni~=?z_hni)"
           by (rule subst [where P="(\<lambda>zenon_Vyvd. ((a_VARIABLEunde_storeunde_a[zenon_Vyvd])~=?z_hni))", OF z_Htl], fact z_Hod)
           thus "(?z_hni~=?z_hni)" .
          qed
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hnk: "(?z_hlr~=?z_hlr)"
        by (rule subst [where P="(\<lambda>zenon_Vnvd. ((zenon_Vnvd[1])~=?z_hlr))", OF z_Hmh], fact z_Hmg)
        thus "(?z_hlr~=?z_hlr)" .
       qed
      qed
      have z_Hmc: "(?z_hlr=?z_hfq)"
      by (rule subst [where P="(\<lambda>zenon_Vwvd. (zenon_Vwvd=?z_hfq))", OF z_Hmf], fact z_Hme)
      thus "(?z_hlr=?z_hfq)" .
     qed
    next
     assume z_Hoh:"(?z_hfq~=?z_hfq)"
     show FALSE
     by (rule zenon_noteq [OF z_Hoh])
    qed
   qed
   have z_Hoi: "(?z_hfq=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hmc], fact z_Hlq)
   thus "(?z_hfq=0)" .
  qed
 qed
 have zenon_L32_: "(((?z_hbo[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> (((a_VARIABLEunde_storeunde_a[''n3''])[2])=0) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in DOMAIN(a_VARIABLEunde_storeunde_a)) ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n3'') ==> (a_CONSTANTunde_nunde_a~=(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))) ==> FALSE" (is "?z_how ==> ?z_hra ==> ?z_hma ==> ?z_htk ==> ?z_hng ==> FALSE")
 proof -
  assume z_How:"?z_how" (is "?z_hox~=_")
  assume z_Hra:"?z_hra" (is "?z_hrb=_")
  assume z_Hma:"?z_hma"
  assume z_Htk:"?z_htk" (is "?z_hlt=?z_hq")
  assume z_Hng:"?z_hng"
  show FALSE
  proof (rule notE [OF z_How])
   have z_Hrc: "(?z_hrb=?z_hox)"
   proof (rule zenon_nnpp [of "(?z_hrb=?z_hox)"])
    assume z_Hrd:"(?z_hrb~=?z_hox)"
    show FALSE
    proof (rule zenon_em [of "(?z_hox=?z_hox)"])
     assume z_Hpc:"(?z_hox=?z_hox)"
     show FALSE
     proof (rule notE [OF z_Hrd])
      have z_Hre: "(?z_hox=?z_hrb)"
      proof (rule zenon_nnpp [of "(?z_hox=?z_hrb)"])
       assume z_Hrf:"(?z_hox~=?z_hrb)"
       show FALSE
       proof (rule zenon_noteq [of "?z_hrb"])
        have z_Hrg: "((?z_hbo[?z_hlt])=(a_VARIABLEunde_storeunde_a[?z_hq]))" (is "?z_hls=?z_heu")
        proof (rule zenon_nnpp [of "(?z_hls=?z_heu)"])
         assume z_Hrh:"(?z_hls~=?z_heu)"
         show FALSE
         proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vyd. (zenon_Vyd~=?z_heu))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_Hrh])
          assume z_Hma:"?z_hma"
          assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
          assume z_Hrl:"((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])~=?z_heu)" (is "?z_hbp~=_")
          show FALSE
          by (rule notE [OF z_Hng z_Hmb])
         next
          assume z_Hma:"?z_hma"
          assume z_Hng:"?z_hng"
          assume z_Hrs:"((a_VARIABLEunde_storeunde_a[?z_hlt])~=?z_heu)" (is "?z_hni~=_")
          show FALSE
          proof (rule zenon_noteq [of "?z_heu"])
           have z_Hrn: "(?z_heu~=?z_heu)"
           by (rule subst [where P="(\<lambda>zenon_Vyxd. ((a_VARIABLEunde_storeunde_a[zenon_Vyxd])~=?z_heu))", OF z_Htk], fact z_Hrs)
           thus "(?z_heu~=?z_heu)" .
          qed
         next
          assume z_Hnj:"(~?z_hma)"
          show FALSE
          by (rule notE [OF z_Hnj z_Hma])
         qed
        qed
        have z_Hrt: "(?z_hrb~=?z_hrb)"
        by (rule subst [where P="(\<lambda>zenon_Vxd. ((zenon_Vxd[2])~=?z_hrb))", OF z_Hrg], fact z_Hrf)
        thus "(?z_hrb~=?z_hrb)" .
       qed
      qed
      have z_Hrc: "(?z_hrb=?z_hox)"
      by (rule subst [where P="(\<lambda>zenon_Vewd. (zenon_Vewd=?z_hox))", OF z_Hre], fact z_Hpc)
      thus "(?z_hrb=?z_hox)" .
     qed
    next
     assume z_Hqa:"(?z_hox~=?z_hox)"
     show FALSE
     by (rule zenon_noteq [OF z_Hqa])
    qed
   qed
   have z_Hqb: "(?z_hox=0)"
   by (rule subst [where P="(\<lambda>zenon_Vpvd. (zenon_Vpvd=0))", OF z_Hrc], fact z_Hra)
   thus "(?z_hox=0)" .
  qed
 qed
 have zenon_L33_: "(a_VARIABLEunde_storeunde_hash_primea=?z_hbo) ==> (((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[1])=0) ==> (((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0) ==> bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) ==> ?z_hh ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n3'') ==> ((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in {''n1'', ''n2'', ''n3''}) ==> ?z_hk ==> (\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_a[x])[1])=0)=>(((a_VARIABLEunde_storeunde_a[x])[2])=0)))) ==> FALSE" (is "?z_he ==> ?z_hsa ==> ?z_hsd ==> ?z_hcz ==> _ ==> ?z_htk ==> ?z_hoq ==> _ ==> ?z_hsf ==> FALSE")
 proof -
  assume z_He:"?z_he"
  assume z_Hsa:"?z_hsa" (is "?z_hsb=_")
  assume z_Hsd:"?z_hsd" (is "?z_hse~=_")
  assume z_Hcz:"?z_hcz"
  assume z_Hh:"?z_hh"
  assume z_Htk:"?z_htk" (is "?z_hlt=?z_hq")
  assume z_Hoq:"?z_hoq"
  assume z_Hk:"?z_hk"
  assume z_Hsf:"?z_hsf" (is "\\A x : ?z_hsl(x)")
  have z_Hlq: "(((?z_hbo[?z_hlt])[1])=0)" (is "?z_hlr=_")
  by (rule subst [where P="(\<lambda>zenon_Vdud. (((zenon_Vdud[?z_hlt])[1])=0))", OF z_He z_Hsa])
  have z_How: "(((?z_hbo[?z_hlt])[2])~=0)" (is "?z_hox~=_")
  by (rule subst [where P="(\<lambda>zenon_Vnjd. (((zenon_Vnjd[?z_hlt])[2])~=0))", OF z_He z_Hsd])
  have z_Hsw: "?z_hsl(?z_hq)" (is "?z_hci=>?z_hsx")
  by (rule zenon_all_0 [of "?z_hsl" "?z_hq", OF z_Hsf])
  show FALSE
  proof (rule zenon_imply [OF z_Hsw])
   assume z_Hch:"(~?z_hci)"
   show FALSE
   by (rule zenon_L1_ [OF z_Hch])
  next
   assume z_Hsx:"?z_hsx" (is "?z_hoi=>?z_hra")
   show FALSE
   proof (rule zenon_imply [OF z_Hsx])
    assume z_Hln:"(((a_VARIABLEunde_storeunde_a[?z_hq])[1])~=0)" (is "?z_hfq~=_")
    have z_Hsy: "?z_hsl(''n2'')" (is "?z_hcs=>?z_hsz")
    by (rule zenon_all_0 [of "?z_hsl" "''n2''", OF z_Hsf])
    show FALSE
    proof (rule zenon_imply [OF z_Hsy])
     assume z_Hcr:"(~?z_hcs)"
     show FALSE
     by (rule zenon_L2_ [OF z_Hcr])
    next
     assume z_Hsz:"?z_hsz" (is "?z_hoc=>?z_hqc")
     show FALSE
     proof (rule zenon_imply [OF z_Hsz])
      assume z_Hlo:"(((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0)" (is "?z_hgf~=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L13_ [OF z_Hln z_Hlo z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L31_ [OF z_Hln z_Hlq z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L17_ [OF z_Hln z_Hlo z_Hlq z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L31_ [OF z_Hln z_Hlq z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     next
      assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L20_ [OF z_Hln z_How z_Hqc z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L31_ [OF z_Hln z_Hlq z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L21_ [OF z_Hln z_Hlq z_Hqc z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L31_ [OF z_Hln z_Hlq z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     qed
    qed
   next
    assume z_Hra:"?z_hra" (is "?z_hrb=_")
    have z_Hsy: "?z_hsl(''n2'')" (is "?z_hcs=>?z_hsz")
    by (rule zenon_all_0 [of "?z_hsl" "''n2''", OF z_Hsf])
    show FALSE
    proof (rule zenon_imply [OF z_Hsy])
     assume z_Hcr:"(~?z_hcs)"
     show FALSE
     by (rule zenon_L2_ [OF z_Hcr])
    next
     assume z_Hsz:"?z_hsz" (is "?z_hoc=>?z_hqc")
     show FALSE
     proof (rule zenon_imply [OF z_Hsz])
      assume z_Hlo:"(((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0)" (is "?z_hgf~=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L22_ [OF z_How z_Hra z_Hlo z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L32_ [OF z_How z_Hra z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L23_ [OF z_Hra z_Hlo z_Hlq z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L32_ [OF z_How z_Hra z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     next
      assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
      have z_Hta: "?z_hsl(''n1'')" (is "?z_hcx=>?z_htb")
      by (rule zenon_all_0 [of "?z_hsl" "''n1''", OF z_Hsf])
      show FALSE
      proof (rule zenon_imply [OF z_Hta])
       assume z_Hcw:"(~?z_hcx)"
       show FALSE
       by (rule zenon_L3_ [OF z_Hcw])
      next
       assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
       show FALSE
       proof (rule zenon_imply [OF z_Htb])
        assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[''n1''])[1])~=0)" (is "?z_hfs~=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L24_ [OF z_Hra z_How z_Hqc z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L32_ [OF z_How z_Hra z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       next
        assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({''n1'', ''n2'', ?z_hq}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={''n1'', ''n2'', ?z_hq})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
         assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
         show FALSE
         by (rule zenon_L25_ [OF z_Hra z_Hqc z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
        next
         assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
         assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
         assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
         show FALSE
         by (rule zenon_L32_ [OF z_How z_Hra z_Hma z_Htk z_Hng])
        next
         assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
         show FALSE
         by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
        qed
       qed
      qed
     qed
    qed
   qed
  qed
 qed
 assume z_Hj:"(~((a_VARIABLEunde_storeunde_hash_primea \\in FuncSet({''n1'', ''n2'', ''n3''}, prod(isa'dotdot(0, 2), {0, 1})))&((a_VARIABLEunde_writeTsunde_hash_primea \\in isa'dotdot(0, 2))&(bAll({''n1'', ''n2'', ''n3''}, (\<lambda>a_CONSTANTunde_nunde_a_1. (((a_VARIABLEunde_storeunde_hash_primea[a_CONSTANTunde_nunde_a_1])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))&bAll({''n1'', ''n2'', ''n3''}, (\<lambda>a_CONSTANTunde_nunde_a_1. ((((a_VARIABLEunde_storeunde_hash_primea[a_CONSTANTunde_nunde_a_1])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[a_CONSTANTunde_nunde_a_1])[2])=0))))))))" (is "~(?z_hdo&?z_htn)")
 have z_Hk: "?z_hk"
 by (rule zenon_and_0 [OF z_Ha])
 have z_Hx: "?z_hx" (is "?z_hy&?z_hba")
 by (rule zenon_and_1 [OF z_Ha])
 have z_Hy: "?z_hy"
 by (rule zenon_and_0 [OF z_Hx])
 have z_Hba: "?z_hba" (is "?z_hbb&?z_hbh")
 by (rule zenon_and_1 [OF z_Hx])
 have z_Hbb: "?z_hbb"
 by (rule zenon_and_0 [OF z_Hba])
 have z_Hbh: "?z_hbh"
 by (rule zenon_and_1 [OF z_Hba])
 have z_Hkf_z_Hbb: "(\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_a[x])[1]) <= a_VARIABLEunde_writeTsunde_a))) == ?z_hbb" (is "?z_hkf == _")
 by (unfold bAll_def)
 have z_Hkf: "?z_hkf" (is "\\A x : ?z_hki(x)")
 by (unfold z_Hkf_z_Hbb, fact z_Hbb)
 have z_Hsf_z_Hbh: "(\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_a[x])[1])=0)=>(((a_VARIABLEunde_storeunde_a[x])[2])=0)))) == ?z_hbh" (is "?z_hsf == _")
 by (unfold bAll_def)
 have z_Hsf: "?z_hsf" (is "\\A x : ?z_hsl(x)")
 by (unfold z_Hsf_z_Hbh, fact z_Hbh)
 have z_Hub: "(a_CONSTANTunde_Qunde_a \\subseteq {''n1'', ''n2'', ''n3''})" (is "?z_hub")
 by (rule zenon_in_SUBSET_0 [of "a_CONSTANTunde_Qunde_a" "{''n1'', ''n2'', ''n3''}", OF z_Hc])
 have z_Hcz_z_Hub: "bAll(a_CONSTANTunde_Qunde_a, (\<lambda>zenon_Vn. (zenon_Vn \\in {''n1'', ''n2'', ''n3''}))) == ?z_hub" (is "?z_hcz == _")
 by (unfold subset_def)
 have z_Hcz: "?z_hcz"
 by (unfold z_Hcz_z_Hub, fact z_Hub)
 have z_Hgb_z_Hcz: "(\\A x:((x \\in a_CONSTANTunde_Qunde_a)=>(x \\in {''n1'', ''n2'', ''n3''}))) == ?z_hcz" (is "?z_hgb == _")
 by (unfold bAll_def)
 have z_Hgb: "?z_hgb" (is "\\A x : ?z_hgg(x)")
 by (unfold z_Hgb_z_Hcz, fact z_Hcz)
 show FALSE
 proof (rule zenon_notand [OF z_Hj])
  assume z_Hdn:"(~?z_hdo)"
  show FALSE
  by (rule zenon_L5_ [OF z_He z_Hdn z_Hcz z_Hh z_Hk])
 next
  assume z_Huc:"(~?z_htn)" (is "~(?z_hfg&?z_hto)")
  show FALSE
  proof (rule zenon_notand [OF z_Huc])
   assume z_Hff:"(~?z_hfg)"
   show FALSE
   by (rule zenon_L6_ [OF z_Hf z_Hff z_Hy])
  next
   assume z_Hud:"(~?z_hto)" (is "~(?z_htp&?z_htv)")
   show FALSE
   proof (rule zenon_notand [OF z_Hud])
    assume z_Hue:"(~?z_htp)"
    have z_Huf_z_Hue: "(~(\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) == (~?z_htp)" (is "?z_huf == ?z_hue")
    by (unfold bAll_def)
    have z_Huf: "?z_huf" (is "~(\\A x : ?z_huh(x))")
    by (unfold z_Huf_z_Hue, fact z_Hue)
    have z_Hui: "(\\E x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))" (is "\\E x : ?z_huj(x)")
    by (rule zenon_notallex_0 [of "?z_huh", OF z_Huf])
    have z_Huk: "?z_huj((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))))" (is "~(?z_hjp=>?z_hkc)")
    by (rule zenon_ex_choose_0 [of "?z_huj", OF z_Hui])
    have z_Hjp: "?z_hjp"
    by (rule zenon_notimply_0 [OF z_Huk])
    have z_Hkb: "(~?z_hkc)"
    by (rule zenon_notimply_1 [OF z_Huk])
    show FALSE
    proof (rule zenon_in_addElt [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))" "''n1''" "{''n2'', ''n3''}", OF z_Hjp])
     assume z_Hip:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n1'')" (is "?z_hij=?z_ho")
     have z_Hkj: "(~(((?z_hbo[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hkk")
     by (rule subst [where P="(\<lambda>zenon_Vnqd. (~(((zenon_Vnqd[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))", OF z_He z_Hkb])
     have z_Hkt: "?z_hki(''n3'')" (is "?z_hci=>?z_hfp")
     by (rule zenon_all_0 [of "?z_hki" "''n3''", OF z_Hkf])
     show FALSE
     proof (rule zenon_imply [OF z_Hkt])
      assume z_Hch:"(~?z_hci)"
      show FALSE
      by (rule zenon_L1_ [OF z_Hch])
     next
      assume z_Hfp:"?z_hfp"
      have z_Hku: "?z_hki(''n2'')" (is "?z_hcs=>?z_hge")
      by (rule zenon_all_0 [of "?z_hki" "''n2''", OF z_Hkf])
      show FALSE
      proof (rule zenon_imply [OF z_Hku])
       assume z_Hcr:"(~?z_hcs)"
       show FALSE
       by (rule zenon_L2_ [OF z_Hcr])
      next
       assume z_Hge:"?z_hge"
       have z_Hkv: "?z_hki(?z_ho)" (is "?z_hcx=>?z_hfr")
       by (rule zenon_all_0 [of "?z_hki" "?z_ho", OF z_Hkf])
       show FALSE
       proof (rule zenon_imply [OF z_Hkv])
        assume z_Hcw:"(~?z_hcx)"
        show FALSE
        by (rule zenon_L3_ [OF z_Hcw])
       next
        assume z_Hfr:"?z_hfr"
        have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
        by (unfold prod_def)
        have z_Hkw: "?z_hkw"
        by (unfold z_Hkw_z_Hk, fact z_Hk)
        have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
        by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
        have z_Hft_z_Hh: "((CHOOSE x:((x \\in a_CONSTANTunde_Qunde_a)&(((a_VARIABLEunde_storeunde_a[x])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a)))))))) \\in a_CONSTANTunde_Qunde_a) == ?z_hh" (is "?z_hft == _")
        by (unfold bChoose_def)
        have z_Hft: "?z_hft"
        by (unfold z_Hft_z_Hh, fact z_Hh)
        show FALSE
        proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Veqb. (~((zenon_Veqb[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hij", OF z_Hkj])
         assume z_Hjo:"(?z_hij \\in ?z_hjm)" (is "?z_hjo")
         assume z_Hlf:"(a_CONSTANTunde_nunde_a=?z_hij)"
         assume z_Hfm:"(~(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hfn")
         show FALSE
         by (rule zenon_L7_ [OF z_Hf z_Hfm z_Hfp z_Hfr z_Hft z_Hgb z_Hge])
        next
         assume z_Hjo:"(?z_hij \\in ?z_hjm)" (is "?z_hjo")
         assume z_Hlg:"(a_CONSTANTunde_nunde_a~=?z_hij)"
         assume z_Hif:"(~(((a_VARIABLEunde_storeunde_a[?z_hij])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))" (is "~?z_hig")
         show FALSE
         by (rule zenon_L8_ [OF z_Hf z_Hif z_Hfr z_Hip])
        next
         assume z_Hjn:"(~(?z_hij \\in ?z_hjm))" (is "~?z_hjo")
         show FALSE
         by (rule zenon_L9_ [OF z_Hjl z_Hjn z_Hjp])
        qed
       qed
      qed
     qed
    next
     assume z_Hul:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in {''n2'', ''n3''})" (is "?z_hul")
     show FALSE
     proof (rule zenon_in_addElt [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))" "''n2''" "{''n3''}", OF z_Hul])
      assume z_Hjv:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n2'')" (is "?z_hij=?z_hp")
      show FALSE
      by (rule zenon_L11_ [OF z_Hf z_He z_Hkb z_Hkf z_Hk z_Hh z_Hgb z_Hjv z_Hjp])
     next
      assume z_Hum:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in {''n3''})" (is "?z_hum")
      show FALSE
      proof (rule zenon_in_addElt [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))" "''n3''" "{}", OF z_Hum])
       assume z_Hlh:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))=''n3'')" (is "?z_hij=?z_hq")
       show FALSE
       by (rule zenon_L12_ [OF z_Hf z_He z_Hkb z_Hkf z_Hk z_Hh z_Hgb z_Hlh z_Hjp])
      next
       assume z_Hun:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea)))) \\in {})" (is "?z_hun")
       show FALSE
       by (rule zenon_in_emptyset [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>(((a_VARIABLEunde_storeunde_hash_primea[x])[1]) <= a_VARIABLEunde_writeTsunde_hash_primea))))", OF z_Hun])
      qed
     qed
    qed
   next
    assume z_Huo:"(~?z_htv)"
    have z_Hup_z_Huo: "(~(\\A x:((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) == (~?z_htv)" (is "?z_hup == ?z_huo")
    by (unfold bAll_def)
    have z_Hup: "?z_hup" (is "~(\\A x : ?z_hur(x))")
    by (unfold z_Hup_z_Huo, fact z_Huo)
    have z_Hus: "(\\E x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))" (is "\\E x : ?z_hut(x)")
    by (rule zenon_notallex_0 [of "?z_hur", OF z_Hup])
    have z_Huu: "?z_hut((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))))" (is "~(?z_hoq=>?z_huv)")
    by (rule zenon_ex_choose_0 [of "?z_hut", OF z_Hus])
    have z_Hoq: "?z_hoq"
    by (rule zenon_notimply_0 [OF z_Huu])
    have z_Huw: "(~?z_huv)" (is "~(?z_hsa=>?z_hux)")
    by (rule zenon_notimply_1 [OF z_Huu])
    have z_Hsa: "?z_hsa" (is "?z_hsb=_")
    by (rule zenon_notimply_0 [OF z_Huw])
    have z_Hsd: "(((a_VARIABLEunde_storeunde_hash_primea[(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))])[2])~=0)" (is "?z_hse~=_")
    by (rule zenon_notimply_1 [OF z_Huw])
    show FALSE
    proof (rule zenon_in_addElt [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))" "''n1''" "{''n2'', ''n3''}", OF z_Hoq])
     assume z_Hoj:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n1'')" (is "?z_hlt=?z_ho")
     have z_Hlq: "(((?z_hbo[?z_hlt])[1])=0)" (is "?z_hlr=_")
     by (rule subst [where P="(\<lambda>zenon_Vdud. (((zenon_Vdud[?z_hlt])[1])=0))", OF z_He z_Hsa])
     have z_How: "(((?z_hbo[?z_hlt])[2])~=0)" (is "?z_hox~=_")
     by (rule subst [where P="(\<lambda>zenon_Vnjd. (((zenon_Vnjd[?z_hlt])[2])~=0))", OF z_He z_Hsd])
     have z_Hsw: "?z_hsl(''n3'')" (is "?z_hci=>?z_hsx")
     by (rule zenon_all_0 [of "?z_hsl" "''n3''", OF z_Hsf])
     show FALSE
     proof (rule zenon_imply [OF z_Hsw])
      assume z_Hch:"(~?z_hci)"
      show FALSE
      by (rule zenon_L1_ [OF z_Hch])
     next
      assume z_Hsx:"?z_hsx" (is "?z_hoi=>?z_hra")
      show FALSE
      proof (rule zenon_imply [OF z_Hsx])
       assume z_Hln:"(((a_VARIABLEunde_storeunde_a[''n3''])[1])~=0)" (is "?z_hfq~=_")
       have z_Hsy: "?z_hsl(''n2'')" (is "?z_hcs=>?z_hsz")
       by (rule zenon_all_0 [of "?z_hsl" "''n2''", OF z_Hsf])
       show FALSE
       proof (rule zenon_imply [OF z_Hsy])
        assume z_Hcr:"(~?z_hcs)"
        show FALSE
        by (rule zenon_L2_ [OF z_Hcr])
       next
        assume z_Hsz:"?z_hsz" (is "?z_hoc=>?z_hqc")
        show FALSE
        proof (rule zenon_imply [OF z_Hsz])
         assume z_Hlo:"(((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0)" (is "?z_hgf~=_")
         have z_Hta: "?z_hsl(?z_ho)" (is "?z_hcx=>?z_htb")
         by (rule zenon_all_0 [of "?z_hsl" "?z_ho", OF z_Hsf])
         show FALSE
         proof (rule zenon_imply [OF z_Hta])
          assume z_Hcw:"(~?z_hcx)"
          show FALSE
          by (rule zenon_L3_ [OF z_Hcw])
         next
          assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
          show FALSE
          proof (rule zenon_imply [OF z_Htb])
           assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[?z_ho])[1])~=0)" (is "?z_hfs~=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L13_ [OF z_Hln z_Hlo z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L15_ [OF z_Hlp z_Hlq z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          next
           assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L17_ [OF z_Hln z_Hlo z_Hlq z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L19_ [OF z_How z_Hoy z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          qed
         qed
        next
         assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
         have z_Hta: "?z_hsl(?z_ho)" (is "?z_hcx=>?z_htb")
         by (rule zenon_all_0 [of "?z_hsl" "?z_ho", OF z_Hsf])
         show FALSE
         proof (rule zenon_imply [OF z_Hta])
          assume z_Hcw:"(~?z_hcx)"
          show FALSE
          by (rule zenon_L3_ [OF z_Hcw])
         next
          assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
          show FALSE
          proof (rule zenon_imply [OF z_Htb])
           assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[?z_ho])[1])~=0)" (is "?z_hfs~=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L20_ [OF z_Hln z_How z_Hqc z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L15_ [OF z_Hlp z_Hlq z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          next
           assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L21_ [OF z_Hln z_Hlq z_Hqc z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L19_ [OF z_How z_Hoy z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          qed
         qed
        qed
       qed
      next
       assume z_Hra:"?z_hra" (is "?z_hrb=_")
       have z_Hsy: "?z_hsl(''n2'')" (is "?z_hcs=>?z_hsz")
       by (rule zenon_all_0 [of "?z_hsl" "''n2''", OF z_Hsf])
       show FALSE
       proof (rule zenon_imply [OF z_Hsy])
        assume z_Hcr:"(~?z_hcs)"
        show FALSE
        by (rule zenon_L2_ [OF z_Hcr])
       next
        assume z_Hsz:"?z_hsz" (is "?z_hoc=>?z_hqc")
        show FALSE
        proof (rule zenon_imply [OF z_Hsz])
         assume z_Hlo:"(((a_VARIABLEunde_storeunde_a[''n2''])[1])~=0)" (is "?z_hgf~=_")
         have z_Hta: "?z_hsl(?z_ho)" (is "?z_hcx=>?z_htb")
         by (rule zenon_all_0 [of "?z_hsl" "?z_ho", OF z_Hsf])
         show FALSE
         proof (rule zenon_imply [OF z_Hta])
          assume z_Hcw:"(~?z_hcx)"
          show FALSE
          by (rule zenon_L3_ [OF z_Hcw])
         next
          assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
          show FALSE
          proof (rule zenon_imply [OF z_Htb])
           assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[?z_ho])[1])~=0)" (is "?z_hfs~=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L22_ [OF z_How z_Hra z_Hlo z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L15_ [OF z_Hlp z_Hlq z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          next
           assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L23_ [OF z_Hra z_Hlo z_Hlq z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L19_ [OF z_How z_Hoy z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          qed
         qed
        next
         assume z_Hqc:"?z_hqc" (is "?z_hqd=_")
         have z_Hta: "?z_hsl(?z_ho)" (is "?z_hcx=>?z_htb")
         by (rule zenon_all_0 [of "?z_hsl" "?z_ho", OF z_Hsf])
         show FALSE
         proof (rule zenon_imply [OF z_Hta])
          assume z_Hcw:"(~?z_hcx)"
          show FALSE
          by (rule zenon_L3_ [OF z_Hcw])
         next
          assume z_Htb:"?z_htb" (is "?z_hnt=>?z_hoy")
          show FALSE
          proof (rule zenon_imply [OF z_Htb])
           assume z_Hlp:"(((a_VARIABLEunde_storeunde_a[?z_ho])[1])~=0)" (is "?z_hfs~=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L24_ [OF z_Hra z_How z_Hqc z_Hlp z_Hlq z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L15_ [OF z_Hlp z_Hlq z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          next
           assume z_Hoy:"?z_hoy" (is "?z_hoz=_")
           have z_Hkw_z_Hk: "(a_VARIABLEunde_storeunde_a \\in FuncSet({?z_ho, ''n2'', ''n3''}, Product(<<isa'dotdot(0, 2), {0, 1}>>))) == ?z_hk" (is "?z_hkw == _")
           by (unfold prod_def)
           have z_Hkw: "?z_hkw"
           by (unfold z_Hkw_z_Hk, fact z_Hk)
           have z_Hjl: "(DOMAIN(a_VARIABLEunde_storeunde_a)={?z_ho, ''n2'', ''n3''})" (is "?z_hjm=?z_hn")
           by (rule zenon_in_funcset_1 [of "a_VARIABLEunde_storeunde_a" "?z_hn" "Product(<<isa'dotdot(0, 2), {0, 1}>>)", OF z_Hkw])
           show FALSE
           proof (rule zenon_fapplyexcept [of "(\<lambda>zenon_Vpa. ((zenon_Vpa[2])~=0))" "a_VARIABLEunde_storeunde_a" "a_CONSTANTunde_nunde_a" "(a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])" "?z_hlt", OF z_How])
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hmb:"(a_CONSTANTunde_nunde_a=?z_hlt)"
            assume z_Htg:"(((a_VARIABLEunde_storeunde_a[bChoice(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1])=bChoice(setOfAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. ((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]))), (\<lambda>a_CONSTANTunde_tunde_a. bAll(a_CONSTANTunde_Qunde_a, (\<lambda>a_CONSTANTunde_munde_a. (((a_VARIABLEunde_storeunde_a[a_CONSTANTunde_munde_a])[1]) <= a_CONSTANTunde_tunde_a))))))))])[2])~=0)" (is "?z_hth~=_")
            show FALSE
            by (rule zenon_L25_ [OF z_Hra z_Hqc z_How z_Hoy z_Hma z_Hmb z_Hcz z_Hh])
           next
            assume z_Hma:"(?z_hlt \\in ?z_hjm)" (is "?z_hma")
            assume z_Hng:"(a_CONSTANTunde_nunde_a~=?z_hlt)"
            assume z_Hti:"(((a_VARIABLEunde_storeunde_a[?z_hlt])[2])~=0)" (is "?z_htj~=_")
            show FALSE
            by (rule zenon_L19_ [OF z_How z_Hoy z_Hma z_Hoj z_Hng])
           next
            assume z_Hnj:"(~(?z_hlt \\in ?z_hjm))" (is "~?z_hma")
            show FALSE
            by (rule zenon_L16_ [OF z_Hjl z_Hnj z_Hoq])
           qed
          qed
         qed
        qed
       qed
      qed
     qed
    next
     assume z_Huy:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in {''n2'', ''n3''})" (is "?z_huy")
     show FALSE
     proof (rule zenon_in_addElt [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))" "''n2''" "{''n3''}", OF z_Huy])
      assume z_Hry:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n2'')" (is "?z_hlt=?z_hp")
      show FALSE
      by (rule zenon_L30_ [OF z_He z_Hsa z_Hsd z_Hcz z_Hh z_Hry z_Hoq z_Hk z_Hsf])
     next
      assume z_Huz:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in {''n3''})" (is "?z_huz")
      show FALSE
      proof (rule zenon_in_addElt [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))" "''n3''" "{}", OF z_Huz])
       assume z_Htk:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))=''n3'')" (is "?z_hlt=?z_hq")
       show FALSE
       by (rule zenon_L33_ [OF z_He z_Hsa z_Hsd z_Hcz z_Hh z_Htk z_Hoq z_Hk z_Hsf])
      next
       assume z_Hva:"((CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0))))) \\in {})" (is "?z_hva")
       show FALSE
       by (rule zenon_in_emptyset [of "(CHOOSE x:(~((x \\in {''n1'', ''n2'', ''n3''})=>((((a_VARIABLEunde_storeunde_hash_primea[x])[1])=0)=>(((a_VARIABLEunde_storeunde_hash_primea[x])[2])=0)))))", OF z_Hva])
      qed
     qed
    qed
   qed
  qed
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 76"; *} qed
end
