(* automatically generated -- do not edit manually *)
theory CircuitBreaker imports Constant Zenon begin
ML_command {* writeln ("*** TLAPS PARSED\n"); *}
consts
  "isReal" :: c
  "isa_slas_a" :: "[c,c] => c"
  "isa_bksl_diva" :: "[c,c] => c"
  "isa_perc_a" :: "[c,c] => c"
  "isa_peri_peri_a" :: "[c,c] => c"
  "isInfinity" :: c
  "isa_lbrk_rbrk_a" :: "[c] => c"
  "isa_less_more_a" :: "[c] => c"

lemma ob'5:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
fixes a_VARIABLEunde_cbStateunde_a a_VARIABLEunde_cbStateunde_a'
fixes a_VARIABLEunde_failuresunde_a a_VARIABLEunde_failuresunde_a'
fixes a_VARIABLEunde_probeInFlightunde_a a_VARIABLEunde_probeInFlightunde_a'
(* usable definition ACTION_ClosedSuccess_ suppressed *)
(* usable definition ACTION_ClosedFailure_ suppressed *)
(* usable definition ACTION_TimeoutToHalfOpen_ suppressed *)
(* usable definition ACTION_StartProbe_ suppressed *)
(* usable definition ACTION_ProbeSuccess_ suppressed *)
(* usable definition ACTION_ProbeFailure_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
assumes v'16: "(((''closed'') \<in> ({(''closed''), (''open''), (''half_open'')})))"
assumes v'17: "(((FALSE) \<in> (BOOLEAN)))"
assumes v'18: "((((0)) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]])))))))"
assumes v'19: "((less (((0)), ((Succ[Succ[0]])))))"
assumes v'20: "(((FALSE) \<noteq> (TRUE)))"
shows "((((((a_VARIABLEunde_cbStateunde_a) = (''closed''))) & (((a_VARIABLEunde_failuresunde_a) = ((0)))) & (((a_VARIABLEunde_probeInFlightunde_a) = (FALSE)))) \<Rightarrow> ((((a_VARIABLEunde_cbStateunde_a) \<in> ({(''closed''), (''open''), (''half_open'')}))) & (((a_VARIABLEunde_failuresunde_a) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & (((a_VARIABLEunde_probeInFlightunde_a) \<in> (BOOLEAN))) & (((((a_VARIABLEunde_probeInFlightunde_a) = (TRUE))) \<Rightarrow> (((a_VARIABLEunde_cbStateunde_a) = (''half_open''))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''closed''))) \<Rightarrow> ((less ((a_VARIABLEunde_failuresunde_a), ((Succ[Succ[0]]))))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''open''))) \<Rightarrow> (((a_VARIABLEunde_failuresunde_a) = ((0)))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''half_open''))) \<Rightarrow> (((a_VARIABLEunde_failuresunde_a) = ((0)))))))))"(is "PROP ?ob'5")
proof -
ML_command {* writeln "*** TLAPS ENTER 5"; *}
show "PROP ?ob'5"

(* BEGIN ZENON INPUT
;; file=.tlacache/CircuitBreaker.tlaps/tlapm_595e97.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/CircuitBreaker.tlaps/tlapm_595e97.znn.out
;; obligation #5
$hyp "v'16" (TLA.in "closed"
(TLA.set "closed" "open" "half_open"))
$hyp "v'17" (TLA.in F. (TLA.set T. F.))
$hyp "v'18" (TLA.in 0 (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
$hyp "v'19" (arith.lt 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0)))
$hyp "v'20" (-. (= F. T.))
$goal (=> (/\ (= a_VARIABLEunde_cbStateunde_a "closed")
(= a_VARIABLEunde_failuresunde_a 0) (= a_VARIABLEunde_probeInFlightunde_a
F.)) (/\ (TLA.in a_VARIABLEunde_cbStateunde_a
(TLA.set "closed" "open" "half_open")) (TLA.in a_VARIABLEunde_failuresunde_a
(arith.intrange 0 (TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.in a_VARIABLEunde_probeInFlightunde_a (TLA.set T. F.))
(=> (= a_VARIABLEunde_probeInFlightunde_a T.) (= a_VARIABLEunde_cbStateunde_a
"half_open")) (=> (= a_VARIABLEunde_cbStateunde_a "closed")
(arith.lt a_VARIABLEunde_failuresunde_a
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(=> (= a_VARIABLEunde_cbStateunde_a "open") (= a_VARIABLEunde_failuresunde_a
0)) (=> (= a_VARIABLEunde_cbStateunde_a "half_open")
(= a_VARIABLEunde_failuresunde_a
0))))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have z_Hc:"(0 \\in isa'dotdot(0, 2))" (is "?z_hc")
 using v'18 by blast
 have z_Hd:"(0 < 2)" (is "?z_hd")
 using v'19 by blast
 assume z_Hf:"(~(((a_VARIABLEunde_cbStateunde_a=''closed'')&((a_VARIABLEunde_failuresunde_a=0)&(a_VARIABLEunde_probeInFlightunde_a=FALSE)))=>((a_VARIABLEunde_cbStateunde_a \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_a \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_a \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_a=TRUE)=>(a_VARIABLEunde_cbStateunde_a=''half_open''))&(((a_VARIABLEunde_cbStateunde_a=''closed'')=>(a_VARIABLEunde_failuresunde_a < 2))&(((a_VARIABLEunde_cbStateunde_a=''open'')=>(a_VARIABLEunde_failuresunde_a=0))&((a_VARIABLEunde_cbStateunde_a=''half_open'')=>(a_VARIABLEunde_failuresunde_a=0))))))))))" (is "~(?z_hk=>?z_hu)")
 have z_Hk: "?z_hk" (is "?z_hl&?z_ho")
 by (rule zenon_notimply_0 [OF z_Hf])
 have z_Hbq: "(~?z_hu)" (is "~(?z_hv&?z_hz)")
 by (rule zenon_notimply_1 [OF z_Hf])
 have z_Hl: "?z_hl" (is "_=?z_hn")
 by (rule zenon_and_0 [OF z_Hk])
 have z_Ho: "?z_ho" (is "?z_hp&?z_hr")
 by (rule zenon_and_1 [OF z_Hk])
 have z_Hp: "?z_hp"
 by (rule zenon_and_0 [OF z_Ho])
 have z_Hr: "?z_hr" (is "_=?z_ht")
 by (rule zenon_and_1 [OF z_Ho])
 have z_Hbr: "(~a_VARIABLEunde_probeInFlightunde_a)"
 by (rule zenon_eq_x_false_0 [of "a_VARIABLEunde_probeInFlightunde_a", OF z_Hr])
 show FALSE
 proof (rule zenon_notand [OF z_Hbq])
  assume z_Hbs:"(~?z_hv)"
  have z_Hbt: "(a_VARIABLEunde_cbStateunde_a~=?z_hn)"
  by (rule zenon_notin_addElt_0 [of "a_VARIABLEunde_cbStateunde_a" "?z_hn" "{''open'', ''half_open''}", OF z_Hbs])
  show FALSE
  by (rule notE [OF z_Hbt z_Hl])
 next
  assume z_Hbv:"(~?z_hz)" (is "~(?z_hba&?z_hbb)")
  show FALSE
  proof (rule zenon_notand [OF z_Hbv])
   assume z_Hbw:"(~?z_hba)"
   show FALSE
   proof (rule notE [OF z_Hbw])
    have z_Hbx: "(0=a_VARIABLEunde_failuresunde_a)"
    by (rule sym [OF z_Hp])
    have z_Hba: "?z_hba"
    by (rule subst [where P="(\<lambda>zenon_Vi. (zenon_Vi \\in isa'dotdot(0, 2)))", OF z_Hbx], fact z_Hc)
    thus "?z_hba" .
   qed
  next
   assume z_Hcb:"(~?z_hbb)" (is "~(?z_hbc&?z_hbf)")
   show FALSE
   proof (rule zenon_notand [OF z_Hcb])
    assume z_Hcc:"(~?z_hbc)"
    have z_Hcd: "(~(a_VARIABLEunde_probeInFlightunde_a \\in {?z_ht}))" (is "~?z_hce")
    by (rule zenon_notin_addElt_1 [of "a_VARIABLEunde_probeInFlightunde_a" "TRUE" "{?z_ht}", OF z_Hcc])
    have z_Hcg: "(a_VARIABLEunde_probeInFlightunde_a~=?z_ht)"
    by (rule zenon_notin_addElt_0 [of "a_VARIABLEunde_probeInFlightunde_a" "?z_ht" "{}", OF z_Hcd])
    show FALSE
    by (rule notE [OF z_Hcg z_Hr])
   next
    assume z_Hci:"(~?z_hbf)" (is "~(?z_hbg&?z_hbj)")
    show FALSE
    proof (rule zenon_notand [OF z_Hci])
     assume z_Hcj:"(~?z_hbg)" (is "~(?z_hbh=>?z_hbi)")
     have z_Hbh: "?z_hbh" (is "_=?z_hbe")
     by (rule zenon_notimply_0 [OF z_Hcj])
     have z_Hs: "a_VARIABLEunde_probeInFlightunde_a"
     by (rule zenon_eq_x_true_0 [of "a_VARIABLEunde_probeInFlightunde_a", OF z_Hbh])
     show FALSE
     by (rule notE [OF z_Hbr z_Hs])
    next
     assume z_Hck:"(~?z_hbj)" (is "~(?z_hbk&?z_hbm)")
     show FALSE
     proof (rule zenon_notand [OF z_Hck])
      assume z_Hcl:"(~?z_hbk)" (is "~(_=>?z_hbl)")
      have z_Hcm: "(~?z_hbl)"
      by (rule zenon_notimply_1 [OF z_Hcl])
      show FALSE
      proof (rule notE [OF z_Hcm])
       have z_Hbx: "(0=a_VARIABLEunde_failuresunde_a)"
       by (rule sym [OF z_Hp])
       have z_Hbl: "?z_hbl"
       by (rule subst [where P="(\<lambda>zenon_Vh. (zenon_Vh < 2))", OF z_Hbx], fact z_Hd)
       thus "?z_hbl" .
      qed
     next
      assume z_Hcq:"(~?z_hbm)" (is "~(?z_hbn&?z_hbp)")
      show FALSE
      proof (rule zenon_notand [OF z_Hcq])
       assume z_Hcr:"(~?z_hbn)" (is "~(?z_hbo=>_)")
       have z_Hbo: "?z_hbo" (is "_=?z_hx")
       by (rule zenon_notimply_0 [OF z_Hcr])
       have z_Hcs: "(?z_hx~=?z_hn)"
       by auto
       have z_Hct: "(a_VARIABLEunde_cbStateunde_a~=a_VARIABLEunde_cbStateunde_a)"
       by (rule zenon_stringdiffll [OF z_Hcs z_Hbo z_Hl])
        show FALSE
        by (rule zenon_noteq [OF z_Hct])
      next
       assume z_Hcu:"(~?z_hbp)" (is "~(?z_hbi=>_)")
       have z_Hbi: "?z_hbi" (is "_=?z_hy")
       by (rule zenon_notimply_0 [OF z_Hcu])
       have z_Hcv: "(?z_hy~=?z_hn)"
       by auto
       have z_Hct: "(a_VARIABLEunde_cbStateunde_a~=a_VARIABLEunde_cbStateunde_a)"
       by (rule zenon_stringdiffll [OF z_Hcv z_Hbi z_Hl])
        show FALSE
        by (rule zenon_noteq [OF z_Hct])
      qed
     qed
    qed
   qed
  qed
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 5"; *} qed
lemma ob'19:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
fixes a_VARIABLEunde_cbStateunde_a a_VARIABLEunde_cbStateunde_a'
fixes a_VARIABLEunde_failuresunde_a a_VARIABLEunde_failuresunde_a'
fixes a_VARIABLEunde_probeInFlightunde_a a_VARIABLEunde_probeInFlightunde_a'
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_ClosedSuccess_ suppressed *)
(* usable definition ACTION_ClosedFailure_ suppressed *)
(* usable definition ACTION_TimeoutToHalfOpen_ suppressed *)
(* usable definition ACTION_StartProbe_ suppressed *)
(* usable definition ACTION_ProbeFailure_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
assumes v'16: "(((''closed'') \<in> ({(''closed''), (''open''), (''half_open'')})))"
assumes v'17: "(((FALSE) \<in> (BOOLEAN)))"
assumes v'18: "((((0)) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]])))))))"
assumes v'19: "((less (((0)), ((Succ[Succ[0]])))))"
assumes v'20: "(((FALSE) \<noteq> (TRUE)))"
shows "((((((((a_VARIABLEunde_cbStateunde_a) \<in> ({(''closed''), (''open''), (''half_open'')}))) & (((a_VARIABLEunde_failuresunde_a) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & (((a_VARIABLEunde_probeInFlightunde_a) \<in> (BOOLEAN))) & (((((a_VARIABLEunde_probeInFlightunde_a) = (TRUE))) \<Rightarrow> (((a_VARIABLEunde_cbStateunde_a) = (''half_open''))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''closed''))) \<Rightarrow> ((less ((a_VARIABLEunde_failuresunde_a), ((Succ[Succ[0]]))))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''open''))) \<Rightarrow> (((a_VARIABLEunde_failuresunde_a) = ((0)))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''half_open''))) \<Rightarrow> (((a_VARIABLEunde_failuresunde_a) = ((0))))))) \<and> ((((a_VARIABLEunde_cbStateunde_a) = (''half_open''))) & (((a_VARIABLEunde_probeInFlightunde_a) = (TRUE))) & ((((a_VARIABLEunde_probeInFlightunde_hash_primea :: c)) = (FALSE))) & ((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''closed''))) & ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) = ((0))))))) \<Rightarrow> (((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) \<in> ({(''closed''), (''open''), (''half_open'')}))) & ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & ((((a_VARIABLEunde_probeInFlightunde_hash_primea :: c)) \<in> (BOOLEAN))) & ((((((a_VARIABLEunde_probeInFlightunde_hash_primea :: c)) = (TRUE))) \<Rightarrow> ((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''half_open''))))) & ((((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''closed''))) \<Rightarrow> ((less (((a_VARIABLEunde_failuresunde_hash_primea :: c)), ((Succ[Succ[0]]))))))) & ((((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''open''))) \<Rightarrow> ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) = ((0)))))) & ((((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''half_open''))) \<Rightarrow> ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) = ((0)))))))))"(is "PROP ?ob'19")
proof -
ML_command {* writeln "*** TLAPS ENTER 19"; *}
show "PROP ?ob'19"

(* BEGIN ZENON INPUT
;; file=.tlacache/CircuitBreaker.tlaps/tlapm_f5cf89.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/CircuitBreaker.tlaps/tlapm_f5cf89.znn.out
;; obligation #19
$hyp "v'16" (TLA.in "closed"
(TLA.set "closed" "open" "half_open"))
$hyp "v'17" (TLA.in F. (TLA.set T. F.))
$hyp "v'18" (TLA.in 0 (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
$hyp "v'19" (arith.lt 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0)))
$hyp "v'20" (-. (= F.
T.))
$goal (=> (/\ (/\ (TLA.in a_VARIABLEunde_cbStateunde_a
(TLA.set "closed" "open" "half_open")) (TLA.in a_VARIABLEunde_failuresunde_a
(arith.intrange 0 (TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.in a_VARIABLEunde_probeInFlightunde_a (TLA.set T. F.))
(=> (= a_VARIABLEunde_probeInFlightunde_a T.) (= a_VARIABLEunde_cbStateunde_a
"half_open")) (=> (= a_VARIABLEunde_cbStateunde_a "closed")
(arith.lt a_VARIABLEunde_failuresunde_a
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(=> (= a_VARIABLEunde_cbStateunde_a "open") (= a_VARIABLEunde_failuresunde_a
0)) (=> (= a_VARIABLEunde_cbStateunde_a "half_open")
(= a_VARIABLEunde_failuresunde_a 0))) (/\ (= a_VARIABLEunde_cbStateunde_a
"half_open") (= a_VARIABLEunde_probeInFlightunde_a T.)
(= a_VARIABLEunde_probeInFlightunde_hash_primea F.)
(= a_VARIABLEunde_cbStateunde_hash_primea "closed")
(= a_VARIABLEunde_failuresunde_hash_primea 0)))
(/\ (TLA.in a_VARIABLEunde_cbStateunde_hash_primea
(TLA.set "closed" "open" "half_open"))
(TLA.in a_VARIABLEunde_failuresunde_hash_primea (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.in a_VARIABLEunde_probeInFlightunde_hash_primea (TLA.set T. F.))
(=> (= a_VARIABLEunde_probeInFlightunde_hash_primea T.)
(= a_VARIABLEunde_cbStateunde_hash_primea "half_open"))
(=> (= a_VARIABLEunde_cbStateunde_hash_primea "closed")
(arith.lt a_VARIABLEunde_failuresunde_hash_primea
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(=> (= a_VARIABLEunde_cbStateunde_hash_primea "open")
(= a_VARIABLEunde_failuresunde_hash_primea 0))
(=> (= a_VARIABLEunde_cbStateunde_hash_primea "half_open")
(= a_VARIABLEunde_failuresunde_hash_primea
0))))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have z_Hd:"(0 < 2)" (is "?z_hd")
 using v'19 by blast
 have zenon_L1_: "(~(a_VARIABLEunde_cbStateunde_hash_primea \\in {''closed'', ''open'', ''half_open''})) ==> (a_VARIABLEunde_cbStateunde_hash_primea=''closed'') ==> FALSE" (is "?z_hi ==> ?z_hp ==> FALSE")
 proof -
  assume z_Hi:"?z_hi" (is "~?z_hj")
  assume z_Hp:"?z_hp" (is "_=?z_hm")
  have z_Hq: "(a_VARIABLEunde_cbStateunde_hash_primea~=?z_hm)"
  by (rule zenon_notin_addElt_0 [of "a_VARIABLEunde_cbStateunde_hash_primea" "?z_hm" "{''open'', ''half_open''}", OF z_Hi])
  show FALSE
  by (rule notE [OF z_Hq z_Hp])
 qed
 have zenon_L2_: "(a_VARIABLEunde_failuresunde_a~=a_VARIABLEunde_failuresunde_hash_primea) ==> (a_VARIABLEunde_failuresunde_a=0) ==> (a_VARIABLEunde_failuresunde_hash_primea=0) ==> FALSE" (is "?z_hs ==> ?z_hv ==> ?z_hw ==> FALSE")
 proof -
  assume z_Hs:"?z_hs"
  assume z_Hv:"?z_hv"
  assume z_Hw:"?z_hw"
  show FALSE
  proof (rule notE [OF z_Hs])
   have z_Hx: "(0=a_VARIABLEunde_failuresunde_hash_primea)"
   by (rule sym [OF z_Hw])
   have z_Hy: "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)"
   by (rule subst [where P="(\<lambda>zenon_Via. (a_VARIABLEunde_failuresunde_a=zenon_Via))", OF z_Hx], fact z_Hv)
   thus "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)" .
  qed
 qed
 have zenon_L3_: "(~(a_VARIABLEunde_failuresunde_hash_primea \\in isa'dotdot(0, 2))) ==> (a_VARIABLEunde_failuresunde_a \\in isa'dotdot(0, 2)) ==> (a_VARIABLEunde_failuresunde_hash_primea=0) ==> (a_VARIABLEunde_failuresunde_a=0) ==> FALSE" (is "?z_hbc ==> ?z_hbf ==> ?z_hw ==> ?z_hv ==> FALSE")
 proof -
  assume z_Hbc:"?z_hbc" (is "~?z_hbd")
  assume z_Hbf:"?z_hbf"
  assume z_Hw:"?z_hw"
  assume z_Hv:"?z_hv"
  show FALSE
  proof (rule notE [OF z_Hbc])
   have z_Hy: "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)"
   proof (rule zenon_nnpp [of "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)"])
    assume z_Hs:"(a_VARIABLEunde_failuresunde_a~=a_VARIABLEunde_failuresunde_hash_primea)"
    show FALSE
    by (rule zenon_L2_ [OF z_Hs z_Hv z_Hw])
   qed
   have z_Hbd: "?z_hbd"
   by (rule subst [where P="(\<lambda>zenon_Vi. (zenon_Vi \\in isa'dotdot(0, 2)))", OF z_Hy], fact z_Hbf)
   thus "?z_hbd" .
  qed
 qed
 have zenon_L4_: "(~(a_VARIABLEunde_probeInFlightunde_hash_primea \\in {TRUE, FALSE})) ==> (a_VARIABLEunde_probeInFlightunde_hash_primea=FALSE) ==> FALSE" (is "?z_hbj ==> ?z_hbp ==> FALSE")
 proof -
  assume z_Hbj:"?z_hbj" (is "~?z_hbk")
  assume z_Hbp:"?z_hbp" (is "_=?z_hbo")
  have z_Hbq: "(~(a_VARIABLEunde_probeInFlightunde_hash_primea \\in {?z_hbo}))" (is "~?z_hbr")
  by (rule zenon_notin_addElt_1 [of "a_VARIABLEunde_probeInFlightunde_hash_primea" "TRUE" "{?z_hbo}", OF z_Hbj])
  have z_Hbt: "(a_VARIABLEunde_probeInFlightunde_hash_primea~=?z_hbo)"
  by (rule zenon_notin_addElt_0 [of "a_VARIABLEunde_probeInFlightunde_hash_primea" "?z_hbo" "{}", OF z_Hbq])
  show FALSE
  by (rule notE [OF z_Hbt z_Hbp])
 qed
 have zenon_L5_: "(~((a_VARIABLEunde_probeInFlightunde_hash_primea=TRUE)=>(a_VARIABLEunde_cbStateunde_hash_primea=''half_open''))) ==> (~a_VARIABLEunde_probeInFlightunde_hash_primea) ==> FALSE" (is "?z_hbv ==> ?z_hbz ==> FALSE")
 proof -
  assume z_Hbv:"?z_hbv" (is "~(?z_hbx=>?z_hby)")
  assume z_Hbz:"?z_hbz"
  have z_Hbx: "?z_hbx" (is "_=?z_hbn")
  by (rule zenon_notimply_0 [OF z_Hbv])
  have z_Hbl: "a_VARIABLEunde_probeInFlightunde_hash_primea"
  by (rule zenon_eq_x_true_0 [of "a_VARIABLEunde_probeInFlightunde_hash_primea", OF z_Hbx])
  show FALSE
  by (rule notE [OF z_Hbz z_Hbl])
 qed
 have zenon_L6_: "(~((a_VARIABLEunde_cbStateunde_hash_primea=''open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))) ==> (a_VARIABLEunde_cbStateunde_hash_primea=''closed'') ==> FALSE" (is "?z_hca ==> ?z_hp ==> FALSE")
 proof -
  assume z_Hca:"?z_hca" (is "~(?z_hcc=>?z_hw)")
  assume z_Hp:"?z_hp" (is "_=?z_hm")
  have z_Hcc: "?z_hcc" (is "_=?z_hn")
  by (rule zenon_notimply_0 [OF z_Hca])
  have z_Hcd: "(?z_hn~=?z_hm)"
  by auto
  have z_Hce: "(a_VARIABLEunde_cbStateunde_hash_primea~=a_VARIABLEunde_cbStateunde_hash_primea)"
  by (rule zenon_stringdiffll [OF z_Hcd z_Hcc z_Hp])
   show FALSE
   by (rule zenon_noteq [OF z_Hce])
 qed
 have zenon_L7_: "(~((a_VARIABLEunde_cbStateunde_hash_primea=''half_open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))) ==> (a_VARIABLEunde_cbStateunde_hash_primea=''closed'') ==> FALSE" (is "?z_hcf ==> ?z_hp ==> FALSE")
 proof -
  assume z_Hcf:"?z_hcf" (is "~(?z_hby=>?z_hw)")
  assume z_Hp:"?z_hp" (is "_=?z_hm")
  have z_Hby: "?z_hby" (is "_=?z_ho")
  by (rule zenon_notimply_0 [OF z_Hcf])
  have z_Hch: "(?z_ho~=?z_hm)"
  by auto
  have z_Hce: "(a_VARIABLEunde_cbStateunde_hash_primea~=a_VARIABLEunde_cbStateunde_hash_primea)"
  by (rule zenon_stringdiffll [OF z_Hch z_Hby z_Hp])
   show FALSE
   by (rule zenon_noteq [OF z_Hce])
 qed
 have zenon_L8_: "(~((a_VARIABLEunde_cbStateunde_hash_primea \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_hash_primea \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_hash_primea \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_hash_primea=TRUE)=>(a_VARIABLEunde_cbStateunde_hash_primea=''half_open''))&(((a_VARIABLEunde_cbStateunde_hash_primea=''closed'')=>(a_VARIABLEunde_failuresunde_hash_primea < 2))&(((a_VARIABLEunde_cbStateunde_hash_primea=''open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))&((a_VARIABLEunde_cbStateunde_hash_primea=''half_open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))))))))) ==> (a_VARIABLEunde_failuresunde_a=0) ==> (a_VARIABLEunde_failuresunde_a \\in isa'dotdot(0, 2)) ==> (a_VARIABLEunde_probeInFlightunde_hash_primea=FALSE) ==> (~a_VARIABLEunde_probeInFlightunde_hash_primea) ==> ?z_hd ==> (a_VARIABLEunde_failuresunde_hash_primea=0) ==> (a_VARIABLEunde_cbStateunde_hash_primea=''closed'') ==> FALSE" (is "?z_hci ==> ?z_hv ==> ?z_hbf ==> ?z_hbp ==> ?z_hbz ==> _ ==> ?z_hw ==> ?z_hp ==> FALSE")
 proof -
  assume z_Hci:"?z_hci" (is "~(?z_hj&?z_hck)")
  assume z_Hv:"?z_hv"
  assume z_Hbf:"?z_hbf"
  assume z_Hbp:"?z_hbp" (is "_=?z_hbo")
  assume z_Hbz:"?z_hbz"
  assume z_Hd:"?z_hd"
  assume z_Hw:"?z_hw"
  assume z_Hp:"?z_hp" (is "_=?z_hm")
  show FALSE
  proof (rule zenon_notand [OF z_Hci])
   assume z_Hi:"(~?z_hj)"
   show FALSE
   by (rule zenon_L1_ [OF z_Hi z_Hp])
  next
   assume z_Hcr:"(~?z_hck)" (is "~(?z_hbd&?z_hcl)")
   show FALSE
   proof (rule zenon_notand [OF z_Hcr])
    assume z_Hbc:"(~?z_hbd)"
    show FALSE
    by (rule zenon_L3_ [OF z_Hbc z_Hbf z_Hw z_Hv])
   next
    assume z_Hcs:"(~?z_hcl)" (is "~(?z_hbk&?z_hcm)")
    show FALSE
    proof (rule zenon_notand [OF z_Hcs])
     assume z_Hbj:"(~?z_hbk)"
     show FALSE
     by (rule zenon_L4_ [OF z_Hbj z_Hbp])
    next
     assume z_Hct:"(~?z_hcm)" (is "~(?z_hbw&?z_hcn)")
     show FALSE
     proof (rule zenon_notand [OF z_Hct])
      assume z_Hbv:"(~?z_hbw)" (is "~(?z_hbx=>?z_hby)")
      show FALSE
      by (rule zenon_L5_ [OF z_Hbv z_Hbz])
     next
      assume z_Hcu:"(~?z_hcn)" (is "~(?z_hco&?z_hcq)")
      show FALSE
      proof (rule zenon_notand [OF z_Hcu])
       assume z_Hcv:"(~?z_hco)" (is "~(_=>?z_hcp)")
       have z_Hcw: "(~?z_hcp)"
       by (rule zenon_notimply_1 [OF z_Hcv])
       show FALSE
       proof (rule notE [OF z_Hcw])
        have z_Hx: "(0=a_VARIABLEunde_failuresunde_hash_primea)"
        by (rule sym [OF z_Hw])
        have z_Hcp: "?z_hcp"
        by (rule subst [where P="(\<lambda>zenon_Vh. (zenon_Vh < 2))", OF z_Hx], fact z_Hd)
        thus "?z_hcp" .
       qed
      next
       assume z_Hda:"(~?z_hcq)" (is "~(?z_hcb&?z_hcg)")
       show FALSE
       proof (rule zenon_notand [OF z_Hda])
        assume z_Hca:"(~?z_hcb)" (is "~(?z_hcc=>_)")
        show FALSE
        by (rule zenon_L6_ [OF z_Hca z_Hp])
       next
        assume z_Hcf:"(~?z_hcg)" (is "~(?z_hby=>_)")
        show FALSE
        by (rule zenon_L7_ [OF z_Hcf z_Hp])
       qed
      qed
     qed
    qed
   qed
  qed
 qed
 assume z_Hf:"(~((((a_VARIABLEunde_cbStateunde_a \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_a \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_a \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_a=TRUE)=>(a_VARIABLEunde_cbStateunde_a=''half_open''))&(((a_VARIABLEunde_cbStateunde_a=''closed'')=>(a_VARIABLEunde_failuresunde_a < 2))&(((a_VARIABLEunde_cbStateunde_a=''open'')=>(a_VARIABLEunde_failuresunde_a=0))&((a_VARIABLEunde_cbStateunde_a=''half_open'')=>(a_VARIABLEunde_failuresunde_a=0))))))))&((a_VARIABLEunde_cbStateunde_a=''half_open'')&((a_VARIABLEunde_probeInFlightunde_a=TRUE)&((a_VARIABLEunde_probeInFlightunde_hash_primea=FALSE)&((a_VARIABLEunde_cbStateunde_hash_primea=''closed'')&(a_VARIABLEunde_failuresunde_hash_primea=0))))))=>((a_VARIABLEunde_cbStateunde_hash_primea \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_hash_primea \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_hash_primea \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_hash_primea=TRUE)=>(a_VARIABLEunde_cbStateunde_hash_primea=''half_open''))&(((a_VARIABLEunde_cbStateunde_hash_primea=''closed'')=>(a_VARIABLEunde_failuresunde_hash_primea < 2))&(((a_VARIABLEunde_cbStateunde_hash_primea=''open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))&((a_VARIABLEunde_cbStateunde_hash_primea=''half_open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))))))))))" (is "~(?z_hdc=>?z_hcj)")
 have z_Hdc: "?z_hdc" (is "?z_hdd&?z_hdw")
 by (rule zenon_notimply_0 [OF z_Hf])
 have z_Hci: "(~?z_hcj)" (is "~(?z_hj&?z_hck)")
 by (rule zenon_notimply_1 [OF z_Hf])
 have z_Hdd: "?z_hdd" (is "?z_hde&?z_hdg")
 by (rule zenon_and_0 [OF z_Hdc])
 have z_Hdw: "?z_hdw" (is "?z_hdn&?z_hdx")
 by (rule zenon_and_1 [OF z_Hdc])
 have z_Hdn: "?z_hdn" (is "_=?z_ho")
 by (rule zenon_and_0 [OF z_Hdw])
 have z_Hdx: "?z_hdx" (is "?z_hdm&?z_hdy")
 by (rule zenon_and_1 [OF z_Hdw])
 have z_Hdy: "?z_hdy" (is "?z_hbp&?z_hdz")
 by (rule zenon_and_1 [OF z_Hdx])
 have z_Hbp: "?z_hbp" (is "_=?z_hbo")
 by (rule zenon_and_0 [OF z_Hdy])
 have z_Hdz: "?z_hdz" (is "?z_hp&?z_hw")
 by (rule zenon_and_1 [OF z_Hdy])
 have z_Hp: "?z_hp" (is "_=?z_hm")
 by (rule zenon_and_0 [OF z_Hdz])
 have z_Hw: "?z_hw"
 by (rule zenon_and_1 [OF z_Hdz])
 have z_Hdg: "?z_hdg" (is "?z_hbf&?z_hdh")
 by (rule zenon_and_1 [OF z_Hdd])
 have z_Hbf: "?z_hbf"
 by (rule zenon_and_0 [OF z_Hdg])
 have z_Hdh: "?z_hdh" (is "?z_hdi&?z_hdk")
 by (rule zenon_and_1 [OF z_Hdg])
 have z_Hdk: "?z_hdk" (is "?z_hdl&?z_hdo")
 by (rule zenon_and_1 [OF z_Hdh])
 have z_Hdo: "?z_hdo" (is "?z_hdp&?z_hds")
 by (rule zenon_and_1 [OF z_Hdk])
 have z_Hds: "?z_hds" (is "?z_hdt&?z_hdv")
 by (rule zenon_and_1 [OF z_Hdo])
 have z_Hdv: "?z_hdv" (is "_=>?z_hv")
 by (rule zenon_and_1 [OF z_Hds])
 have z_Hbz: "(~a_VARIABLEunde_probeInFlightunde_hash_primea)"
 by (rule zenon_eq_x_false_0 [of "a_VARIABLEunde_probeInFlightunde_hash_primea", OF z_Hbp])
 show FALSE
 proof (rule zenon_imply [OF z_Hdv])
  assume z_Hea:"(a_VARIABLEunde_cbStateunde_a~=?z_ho)"
  show FALSE
  by (rule notE [OF z_Hea z_Hdn])
 next
  assume z_Hv:"?z_hv"
  show FALSE
  by (rule zenon_L8_ [OF z_Hci z_Hv z_Hbf z_Hbp z_Hbz z_Hd z_Hw z_Hp])
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 19"; *} qed
lemma ob'20:
(* usable definition CONSTANT_EnabledWrapper_ suppressed *)
(* usable definition CONSTANT_CdotWrapper_ suppressed *)
fixes a_VARIABLEunde_cbStateunde_a a_VARIABLEunde_cbStateunde_a'
fixes a_VARIABLEunde_failuresunde_a a_VARIABLEunde_failuresunde_a'
fixes a_VARIABLEunde_probeInFlightunde_a a_VARIABLEunde_probeInFlightunde_a'
(* usable definition STATE_Init_ suppressed *)
(* usable definition ACTION_ClosedSuccess_ suppressed *)
(* usable definition ACTION_ClosedFailure_ suppressed *)
(* usable definition ACTION_TimeoutToHalfOpen_ suppressed *)
(* usable definition ACTION_StartProbe_ suppressed *)
(* usable definition ACTION_ProbeSuccess_ suppressed *)
(* usable definition STATE_Done_ suppressed *)
(* usable definition ACTION_Next_ suppressed *)
(* usable definition TEMPORAL_Spec_ suppressed *)
assumes v'16: "(((''closed'') \<in> ({(''closed''), (''open''), (''half_open'')})))"
assumes v'17: "(((FALSE) \<in> (BOOLEAN)))"
assumes v'18: "((((0)) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]])))))))"
assumes v'19: "((less (((0)), ((Succ[Succ[0]])))))"
assumes v'20: "(((FALSE) \<noteq> (TRUE)))"
shows "((((((((a_VARIABLEunde_cbStateunde_a) \<in> ({(''closed''), (''open''), (''half_open'')}))) & (((a_VARIABLEunde_failuresunde_a) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & (((a_VARIABLEunde_probeInFlightunde_a) \<in> (BOOLEAN))) & (((((a_VARIABLEunde_probeInFlightunde_a) = (TRUE))) \<Rightarrow> (((a_VARIABLEunde_cbStateunde_a) = (''half_open''))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''closed''))) \<Rightarrow> ((less ((a_VARIABLEunde_failuresunde_a), ((Succ[Succ[0]]))))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''open''))) \<Rightarrow> (((a_VARIABLEunde_failuresunde_a) = ((0)))))) & (((((a_VARIABLEunde_cbStateunde_a) = (''half_open''))) \<Rightarrow> (((a_VARIABLEunde_failuresunde_a) = ((0))))))) \<and> ((((a_VARIABLEunde_cbStateunde_a) = (''half_open''))) & (((a_VARIABLEunde_probeInFlightunde_a) = (TRUE))) & ((((a_VARIABLEunde_probeInFlightunde_hash_primea :: c)) = (FALSE))) & ((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''open''))) & ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) = ((0))))))) \<Rightarrow> (((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) \<in> ({(''closed''), (''open''), (''half_open'')}))) & ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) \<in> ((isa_peri_peri_a (((0)), ((Succ[Succ[0]]))))))) & ((((a_VARIABLEunde_probeInFlightunde_hash_primea :: c)) \<in> (BOOLEAN))) & ((((((a_VARIABLEunde_probeInFlightunde_hash_primea :: c)) = (TRUE))) \<Rightarrow> ((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''half_open''))))) & ((((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''closed''))) \<Rightarrow> ((less (((a_VARIABLEunde_failuresunde_hash_primea :: c)), ((Succ[Succ[0]]))))))) & ((((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''open''))) \<Rightarrow> ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) = ((0)))))) & ((((((a_VARIABLEunde_cbStateunde_hash_primea :: c)) = (''half_open''))) \<Rightarrow> ((((a_VARIABLEunde_failuresunde_hash_primea :: c)) = ((0)))))))))"(is "PROP ?ob'20")
proof -
ML_command {* writeln "*** TLAPS ENTER 20"; *}
show "PROP ?ob'20"

(* BEGIN ZENON INPUT
;; file=.tlacache/CircuitBreaker.tlaps/tlapm_ab0720.znn; PATH='/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/usr/local/cuda/bin:/opt/bin/:/bin:/usr/bin:/usr/local/sbin:/usr/sbin:/opt/pbs/bin:/home/eric-spencer/.local/bin:/home/eric-spencer/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/bin:/lus/grand/projects/EVITA/eric-spencer/tools/tlaps-1.5.0/lib/tlaps/bin'; zenon -p0 -x tla -oisar -max-time 1d "$file" >.tlacache/CircuitBreaker.tlaps/tlapm_ab0720.znn.out
;; obligation #20
$hyp "v'16" (TLA.in "closed"
(TLA.set "closed" "open" "half_open"))
$hyp "v'17" (TLA.in F. (TLA.set T. F.))
$hyp "v'18" (TLA.in 0 (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
$hyp "v'19" (arith.lt 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0)))
$hyp "v'20" (-. (= F.
T.))
$goal (=> (/\ (/\ (TLA.in a_VARIABLEunde_cbStateunde_a
(TLA.set "closed" "open" "half_open")) (TLA.in a_VARIABLEunde_failuresunde_a
(arith.intrange 0 (TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.in a_VARIABLEunde_probeInFlightunde_a (TLA.set T. F.))
(=> (= a_VARIABLEunde_probeInFlightunde_a T.) (= a_VARIABLEunde_cbStateunde_a
"half_open")) (=> (= a_VARIABLEunde_cbStateunde_a "closed")
(arith.lt a_VARIABLEunde_failuresunde_a
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(=> (= a_VARIABLEunde_cbStateunde_a "open") (= a_VARIABLEunde_failuresunde_a
0)) (=> (= a_VARIABLEunde_cbStateunde_a "half_open")
(= a_VARIABLEunde_failuresunde_a 0))) (/\ (= a_VARIABLEunde_cbStateunde_a
"half_open") (= a_VARIABLEunde_probeInFlightunde_a T.)
(= a_VARIABLEunde_probeInFlightunde_hash_primea F.)
(= a_VARIABLEunde_cbStateunde_hash_primea "open")
(= a_VARIABLEunde_failuresunde_hash_primea 0)))
(/\ (TLA.in a_VARIABLEunde_cbStateunde_hash_primea
(TLA.set "closed" "open" "half_open"))
(TLA.in a_VARIABLEunde_failuresunde_hash_primea (arith.intrange 0
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(TLA.in a_VARIABLEunde_probeInFlightunde_hash_primea (TLA.set T. F.))
(=> (= a_VARIABLEunde_probeInFlightunde_hash_primea T.)
(= a_VARIABLEunde_cbStateunde_hash_primea "half_open"))
(=> (= a_VARIABLEunde_cbStateunde_hash_primea "closed")
(arith.lt a_VARIABLEunde_failuresunde_hash_primea
(TLA.fapply TLA.Succ (TLA.fapply TLA.Succ 0))))
(=> (= a_VARIABLEunde_cbStateunde_hash_primea "open")
(= a_VARIABLEunde_failuresunde_hash_primea 0))
(=> (= a_VARIABLEunde_cbStateunde_hash_primea "half_open")
(= a_VARIABLEunde_failuresunde_hash_primea
0))))
END ZENON  INPUT *)
(* PROOF-FOUND *)
(* BEGIN-PROOF *)
proof (rule zenon_nnpp)
 have zenon_L1_: "(~((a_VARIABLEunde_cbStateunde_hash_primea \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_hash_primea \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_hash_primea \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_hash_primea=TRUE)=>(a_VARIABLEunde_cbStateunde_hash_primea=''half_open''))&(((a_VARIABLEunde_cbStateunde_hash_primea=''closed'')=>(a_VARIABLEunde_failuresunde_hash_primea < 2))&(((a_VARIABLEunde_cbStateunde_hash_primea=''open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))&((a_VARIABLEunde_cbStateunde_hash_primea=''half_open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))))))))) ==> (a_VARIABLEunde_failuresunde_a=0) ==> (a_VARIABLEunde_failuresunde_a \\in isa'dotdot(0, 2)) ==> (a_VARIABLEunde_probeInFlightunde_hash_primea=FALSE) ==> (~a_VARIABLEunde_probeInFlightunde_hash_primea) ==> (a_VARIABLEunde_failuresunde_hash_primea=0) ==> (a_VARIABLEunde_cbStateunde_hash_primea=''open'') ==> FALSE" (is "?z_hg ==> ?z_hbn ==> ?z_hbp ==> ?z_hbq ==> ?z_hbr ==> ?z_hbl ==> ?z_hbk ==> FALSE")
 proof -
  assume z_Hg:"?z_hg" (is "~(?z_hi&?z_ho)")
  assume z_Hbn:"?z_hbn"
  assume z_Hbp:"?z_hbp"
  assume z_Hbq:"?z_hbq" (is "_=?z_hz")
  assume z_Hbr:"?z_hbr"
  assume z_Hbl:"?z_hbl"
  assume z_Hbk:"?z_hbk" (is "_=?z_hm")
  show FALSE
  proof (rule zenon_notand [OF z_Hg])
   assume z_Hbs:"(~?z_hi)"
   have z_Hbt: "(~(a_VARIABLEunde_cbStateunde_hash_primea \\in {?z_hm, ''half_open''}))" (is "~?z_hbu")
   by (rule zenon_notin_addElt_1 [of "a_VARIABLEunde_cbStateunde_hash_primea" "''closed''" "{?z_hm, ''half_open''}", OF z_Hbs])
   have z_Hbw: "(a_VARIABLEunde_cbStateunde_hash_primea~=?z_hm)"
   by (rule zenon_notin_addElt_0 [of "a_VARIABLEunde_cbStateunde_hash_primea" "?z_hm" "{''half_open''}", OF z_Hbt])
   show FALSE
   by (rule notE [OF z_Hbw z_Hbk])
  next
   assume z_Hby:"(~?z_ho)" (is "~(?z_hp&?z_hu)")
   show FALSE
   proof (rule zenon_notand [OF z_Hby])
    assume z_Hbz:"(~?z_hp)"
    show FALSE
    proof (rule notE [OF z_Hbz])
     have z_Hca: "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)"
     proof (rule zenon_nnpp [of "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)"])
      assume z_Hcb:"(a_VARIABLEunde_failuresunde_a~=a_VARIABLEunde_failuresunde_hash_primea)"
      show FALSE
      proof (rule notE [OF z_Hcb])
       have z_Hcc: "(0=a_VARIABLEunde_failuresunde_hash_primea)"
       by (rule sym [OF z_Hbl])
       have z_Hca: "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)"
       by (rule subst [where P="(\<lambda>zenon_Via. (a_VARIABLEunde_failuresunde_a=zenon_Via))", OF z_Hcc], fact z_Hbn)
       thus "(a_VARIABLEunde_failuresunde_a=a_VARIABLEunde_failuresunde_hash_primea)" .
      qed
     qed
     have z_Hp: "?z_hp"
     by (rule subst [where P="(\<lambda>zenon_Vi. (zenon_Vi \\in isa'dotdot(0, 2)))", OF z_Hca], fact z_Hbp)
     thus "?z_hp" .
    qed
   next
    assume z_Hcj:"(~?z_hu)" (is "~(?z_hv&?z_hba)")
    show FALSE
    proof (rule zenon_notand [OF z_Hcj])
     assume z_Hck:"(~?z_hv)"
     have z_Hcl: "(~(a_VARIABLEunde_probeInFlightunde_hash_primea \\in {?z_hz}))" (is "~?z_hcm")
     by (rule zenon_notin_addElt_1 [of "a_VARIABLEunde_probeInFlightunde_hash_primea" "TRUE" "{?z_hz}", OF z_Hck])
     have z_Hco: "(a_VARIABLEunde_probeInFlightunde_hash_primea~=?z_hz)"
     by (rule zenon_notin_addElt_0 [of "a_VARIABLEunde_probeInFlightunde_hash_primea" "?z_hz" "{}", OF z_Hcl])
     show FALSE
     by (rule notE [OF z_Hco z_Hbq])
    next
     assume z_Hcq:"(~?z_hba)" (is "~(?z_hbb&?z_hbe)")
     show FALSE
     proof (rule zenon_notand [OF z_Hcq])
      assume z_Hcr:"(~?z_hbb)" (is "~(?z_hbc=>?z_hbd)")
      have z_Hbc: "?z_hbc" (is "_=?z_hy")
      by (rule zenon_notimply_0 [OF z_Hcr])
      have z_Hw: "a_VARIABLEunde_probeInFlightunde_hash_primea"
      by (rule zenon_eq_x_true_0 [of "a_VARIABLEunde_probeInFlightunde_hash_primea", OF z_Hbc])
      show FALSE
      by (rule notE [OF z_Hbr z_Hw])
     next
      assume z_Hcs:"(~?z_hbe)" (is "~(?z_hbf&?z_hbi)")
      show FALSE
      proof (rule zenon_notand [OF z_Hcs])
       assume z_Hct:"(~?z_hbf)" (is "~(?z_hbg=>?z_hbh)")
       have z_Hbg: "?z_hbg" (is "_=?z_hl")
       by (rule zenon_notimply_0 [OF z_Hct])
       have z_Hcu: "(?z_hl~=?z_hm)"
       by auto
       have z_Hcv: "(a_VARIABLEunde_cbStateunde_hash_primea~=a_VARIABLEunde_cbStateunde_hash_primea)"
       by (rule zenon_stringdiffll [OF z_Hcu z_Hbg z_Hbk])
        show FALSE
        by (rule zenon_noteq [OF z_Hcv])
      next
       assume z_Hcw:"(~?z_hbi)" (is "~(?z_hbj&?z_hbm)")
       show FALSE
       proof (rule zenon_notand [OF z_Hcw])
        assume z_Hcx:"(~?z_hbj)"
        have z_Hcy: "(a_VARIABLEunde_failuresunde_hash_primea~=0)"
        by (rule zenon_notimply_1 [OF z_Hcx])
        show FALSE
        by (rule notE [OF z_Hcy z_Hbl])
       next
        assume z_Hcz:"(~?z_hbm)" (is "~(?z_hbd=>_)")
        have z_Hbd: "?z_hbd" (is "_=?z_hn")
        by (rule zenon_notimply_0 [OF z_Hcz])
        have z_Hda: "(?z_hn~=?z_hm)"
        by auto
        have z_Hcv: "(a_VARIABLEunde_cbStateunde_hash_primea~=a_VARIABLEunde_cbStateunde_hash_primea)"
        by (rule zenon_stringdiffll [OF z_Hda z_Hbd z_Hbk])
         show FALSE
         by (rule zenon_noteq [OF z_Hcv])
       qed
      qed
     qed
    qed
   qed
  qed
 qed
 assume z_Hf:"(~((((a_VARIABLEunde_cbStateunde_a \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_a \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_a \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_a=TRUE)=>(a_VARIABLEunde_cbStateunde_a=''half_open''))&(((a_VARIABLEunde_cbStateunde_a=''closed'')=>(a_VARIABLEunde_failuresunde_a < 2))&(((a_VARIABLEunde_cbStateunde_a=''open'')=>(a_VARIABLEunde_failuresunde_a=0))&((a_VARIABLEunde_cbStateunde_a=''half_open'')=>(a_VARIABLEunde_failuresunde_a=0))))))))&((a_VARIABLEunde_cbStateunde_a=''half_open'')&((a_VARIABLEunde_probeInFlightunde_a=TRUE)&((a_VARIABLEunde_probeInFlightunde_hash_primea=FALSE)&((a_VARIABLEunde_cbStateunde_hash_primea=''open'')&(a_VARIABLEunde_failuresunde_hash_primea=0))))))=>((a_VARIABLEunde_cbStateunde_hash_primea \\in {''closed'', ''open'', ''half_open''})&((a_VARIABLEunde_failuresunde_hash_primea \\in isa'dotdot(0, 2))&((a_VARIABLEunde_probeInFlightunde_hash_primea \\in {TRUE, FALSE})&(((a_VARIABLEunde_probeInFlightunde_hash_primea=TRUE)=>(a_VARIABLEunde_cbStateunde_hash_primea=''half_open''))&(((a_VARIABLEunde_cbStateunde_hash_primea=''closed'')=>(a_VARIABLEunde_failuresunde_hash_primea < 2))&(((a_VARIABLEunde_cbStateunde_hash_primea=''open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))&((a_VARIABLEunde_cbStateunde_hash_primea=''half_open'')=>(a_VARIABLEunde_failuresunde_hash_primea=0))))))))))" (is "~(?z_hdc=>?z_hh)")
 have z_Hdc: "?z_hdc" (is "?z_hdd&?z_hdw")
 by (rule zenon_notimply_0 [OF z_Hf])
 have z_Hg: "(~?z_hh)" (is "~(?z_hi&?z_ho)")
 by (rule zenon_notimply_1 [OF z_Hf])
 have z_Hdd: "?z_hdd" (is "?z_hde&?z_hdg")
 by (rule zenon_and_0 [OF z_Hdc])
 have z_Hdw: "?z_hdw" (is "?z_hdn&?z_hdx")
 by (rule zenon_and_1 [OF z_Hdc])
 have z_Hdn: "?z_hdn" (is "_=?z_hn")
 by (rule zenon_and_0 [OF z_Hdw])
 have z_Hdx: "?z_hdx" (is "?z_hdm&?z_hdy")
 by (rule zenon_and_1 [OF z_Hdw])
 have z_Hdy: "?z_hdy" (is "?z_hbq&?z_hdz")
 by (rule zenon_and_1 [OF z_Hdx])
 have z_Hbq: "?z_hbq" (is "_=?z_hz")
 by (rule zenon_and_0 [OF z_Hdy])
 have z_Hdz: "?z_hdz" (is "?z_hbk&?z_hbl")
 by (rule zenon_and_1 [OF z_Hdy])
 have z_Hbk: "?z_hbk" (is "_=?z_hm")
 by (rule zenon_and_0 [OF z_Hdz])
 have z_Hbl: "?z_hbl"
 by (rule zenon_and_1 [OF z_Hdz])
 have z_Hdg: "?z_hdg" (is "?z_hbp&?z_hdh")
 by (rule zenon_and_1 [OF z_Hdd])
 have z_Hbp: "?z_hbp"
 by (rule zenon_and_0 [OF z_Hdg])
 have z_Hdh: "?z_hdh" (is "?z_hdi&?z_hdk")
 by (rule zenon_and_1 [OF z_Hdg])
 have z_Hdk: "?z_hdk" (is "?z_hdl&?z_hdo")
 by (rule zenon_and_1 [OF z_Hdh])
 have z_Hdo: "?z_hdo" (is "?z_hdp&?z_hds")
 by (rule zenon_and_1 [OF z_Hdk])
 have z_Hds: "?z_hds" (is "?z_hdt&?z_hdv")
 by (rule zenon_and_1 [OF z_Hdo])
 have z_Hdv: "?z_hdv" (is "_=>?z_hbn")
 by (rule zenon_and_1 [OF z_Hds])
 have z_Hbr: "(~a_VARIABLEunde_probeInFlightunde_hash_primea)"
 by (rule zenon_eq_x_false_0 [of "a_VARIABLEunde_probeInFlightunde_hash_primea", OF z_Hbq])
 show FALSE
 proof (rule zenon_imply [OF z_Hdv])
  assume z_Hea:"(a_VARIABLEunde_cbStateunde_a~=?z_hn)"
  show FALSE
  by (rule notE [OF z_Hea z_Hdn])
 next
  assume z_Hbn:"?z_hbn"
  show FALSE
  by (rule zenon_L1_ [OF z_Hg z_Hbn z_Hbp z_Hbq z_Hbr z_Hbl z_Hbk])
 qed
qed
(* END-PROOF *)
ML_command {* writeln "*** TLAPS EXIT 20"; *} qed
end
